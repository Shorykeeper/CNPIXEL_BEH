# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 110 238 77
summon minecrafts:diamond_spawner "" 146 238 113
summon minecrafts:diamond_spawner "" 110 238 149
summon minecrafts:diamond_spawner "" 74 238 113
