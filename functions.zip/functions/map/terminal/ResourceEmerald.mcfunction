# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 110 236 113
summon minecrafts:emerald_spawner "" 110 244 113
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
