# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 110 235 197
summon bedwars:text "§b" 26 235 113
summon bedwars:text "§b" 194 235 113
summon bedwars:text "§b" 110 235 29

