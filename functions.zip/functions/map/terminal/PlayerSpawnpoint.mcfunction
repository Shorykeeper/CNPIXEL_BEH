# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 110 236 191
spawnpoint @s[scores={A1T12P=2}] 32 236 113
spawnpoint @s[scores={A1T12P=3}] 188 236 113
spawnpoint @s[scores={A1T12P=4}] 110 236 35
