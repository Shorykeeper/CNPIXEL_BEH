# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 114 236 197

summon template:npc 26 236 117
summon template:npc 194 236 109
summon template:npc 114 236 29