# 1. 潮起亚细亚 (HangZhou)
execute if score mapp B7O14L matches 1 as @s run function map/HangZhou/PlayerVisit

# 2. 水族馆 (aquarium)
execute if score mapp B7O14L matches 2 as @s run function map/aquarium/PlayerVisit

# 3. 入侵 (invasion)
execute if score mapp B7O14L matches 3 as @s run function map/invasion/PlayerVisit

# 4. 通讯站 (notify)
execute if score mapp B7O14L matches 4 as @s run function map/notify/PlayerVisit

# 5. 圣诞 (christmas)
execute if score mapp B7O14L matches 5 as @s run function map/christmas/PlayerVisit

# 6. 菌落 (boletum)
execute if score mapp B7O14L matches 6 as @s run function map/boletum/PlayerVisit

# 7. 冰淇淋 (iceCream)
execute if score mapp B7O14L matches 7 as @s run function map/iceCream/PlayerVisit

# 8. 灯笼节 (dengLoong)
execute if score mapp B7O14L matches 8 as @s run function map/dengLoong/PlayerVisit



# 9. 刀龙 (DaoLong)
execute if score mapp B7O14L matches 9 as @s run function map/DaoLong/PlayerVisit

# 10. 城堡 (castle)
execute if score mapp B7O14L matches 10 as @s run function map/castle/PlayerVisit

# 11. 胜津城 (katsu)
execute if score mapp B7O14L matches 11 as @s run function map/katsu/PlayerVisit

# 12. 壳 (carapace)
execute if score mapp B7O14L matches 12 as @s run function map/carapace/PlayerVisit

# 13. 阿尔忒弥斯 (artemis)
execute if score mapp B7O14L matches 13 as @s run function map/artemis/PlayerVisit

# 14. 斗拱 (archway)
execute if score mapp B7O14L matches 14 as @s run function map/archway/PlayerVisit

# 15. 建筑工地 (buildSite)
execute if score mapp B7O14L matches 15 as @s run function map/buildSite/PlayerVisit

# 16. 庇护营地 (shelter)
execute if score mapp B7O14L matches 16 as @s run function map/shelter/PlayerVisit

# 17. 岸滨 (ashore)
execute if score mapp B7O14L matches 17 as @s run function map/ashore/PlayerVisit

# 18. 方碑 (obelisk)
execute if score mapp B7O14L matches 18 as @s run function map/obelisk/PlayerVisit

# 19. 大庙 (temple)
execute if score mapp B7O14L matches 19 as @s run function map/temple/PlayerVisit

# 20. 伊斯特伍德 (eastwood)
execute if score mapp B7O14L matches 20 as @s run function map/eastwood/PlayerVisit

# 21. 航空站 (terminal)
execute if score mapp B7O14L matches 21 as @s run function map/terminal/PlayerVisit

# 22. 幽兰花 (orchid)
execute if score mapp B7O14L matches 22 as @s run function map/orchid/PlayerVisit

# 23. 铁索连环 (chained)
execute if score mapp B7O14L matches 23 as @s run function map/chained/PlayerVisit

# 24. Rise (rise)
execute if score mapp B7O14L matches 24 as @s run function map/rise/PlayerVisit

# 25. 万圣海盗船 (ship)
execute if score mapp B7O14L matches 25 as @s run function map/ship/PlayerVisit

# 26. 复活节 (easter)
execute if score mapp B7O14L matches 26 as @s run function map/easter/PlayerVisit

# 27. 梦幻林 (dreamGrove)
execute if score mapp B7O14L matches 27 as @s run function map/dreamGrove/PlayerVisit