# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 47 247 111

summon template:npc 105 247 47
summon template:npc 111 247 169
summon template:npc 169 247 105