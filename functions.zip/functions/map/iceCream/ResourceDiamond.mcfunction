# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 84 252 84
summon minecrafts:diamond_spawner "" 132 252 84
summon minecrafts:diamond_spawner "" 132 252 132
summon minecrafts:diamond_spawner "" 84 252 132
