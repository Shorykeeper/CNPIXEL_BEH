# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s 100 248 116

