# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 100 251 116
summon minecrafts:emerald_spawner "" 116 251 100
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
