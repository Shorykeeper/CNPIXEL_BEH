# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 45 247 108
spawnpoint @s[scores={A1T12P=2}] 108 247 45
spawnpoint @s[scores={A1T12P=3}] 108 247 171
spawnpoint @s[scores={A1T12P=4}] 171 247 108
