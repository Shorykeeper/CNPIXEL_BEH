# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 42 247 108
summon bedwars:text "§b" 108 247 42
summon bedwars:text "§b" 108 247 174
summon bedwars:text "§b" 174 247 108

