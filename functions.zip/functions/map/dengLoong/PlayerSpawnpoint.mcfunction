# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 100 231 27
spawnpoint @s[scores={A1T12P=2}] 176 231 103
spawnpoint @s[scores={A1T12P=3}] 24 231 103
spawnpoint @s[scores={A1T12P=4}] 100 231 179
