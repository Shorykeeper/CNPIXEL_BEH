# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 100 232 137
summon minecrafts:diamond_spawner "" 66 232 103
summon minecrafts:diamond_spawner "" 100 232 69
summon minecrafts:diamond_spawner "" 134 232 103
