# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 106 231 29


summon template:npc 174 231 109
summon template:npc 26 231 97
summon template:npc 94 231 177