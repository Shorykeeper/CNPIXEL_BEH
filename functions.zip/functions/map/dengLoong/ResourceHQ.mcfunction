# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 100 230 20
summon bedwars:text "§b" 183 230 103
summon bedwars:text "§b" 17 230 103
summon bedwars:text "§b" 100 230 186

