# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 95 235 27

summon template:npc 180 235 100
summon template:npc 22 235 112
summon template:npc 107 235 185