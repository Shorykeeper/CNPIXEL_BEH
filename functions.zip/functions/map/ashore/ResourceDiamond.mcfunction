# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 148 239 150
summon minecrafts:diamond_spawner "" 145 239 59
summon minecrafts:diamond_spawner "" 54 239 62
summon minecrafts:diamond_spawner "" 57 239 153
