# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 101 240 106
summon minecrafts:emerald_spawner "" 101 259 106
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
