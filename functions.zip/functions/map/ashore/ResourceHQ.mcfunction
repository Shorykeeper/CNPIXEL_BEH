# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 101 234 23
summon bedwars:text "§b" 184 234 106
summon bedwars:text "§b" 18 234 106
summon bedwars:text "§b" 101 234 189

