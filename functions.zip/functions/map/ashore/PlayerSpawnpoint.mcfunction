# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 101 235 28
spawnpoint @s[scores={A1T12P=2}] 180 235 106
spawnpoint @s[scores={A1T12P=3}] 23 235 106
spawnpoint @s[scores={A1T12P=4}] 101 235 184
