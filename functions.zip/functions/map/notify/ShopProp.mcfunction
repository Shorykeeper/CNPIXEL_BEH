# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 96 237 196


summon template:npc 193 237 111
summon template:npc 11 237 99
summon template:npc 108 237 14