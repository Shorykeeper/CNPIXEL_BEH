# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 122 241 85
summon minecrafts:emerald_spawner "" 82 241 125
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
