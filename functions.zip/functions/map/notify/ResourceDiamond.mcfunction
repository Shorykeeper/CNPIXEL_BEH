# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 163 242 44
summon minecrafts:diamond_spawner "" 163 242 166
summon minecrafts:diamond_spawner "" 41 242 166
summon minecrafts:diamond_spawner "" 41 242 44
