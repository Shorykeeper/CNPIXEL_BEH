# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 102 237 195
tp @s[scores={A1T12P=2}] 192 237 105
tp @s[scores={A1T12P=3}] 12 237 105
tp @s[scores={A1T12P=4}] 102 237 15
