# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 102 236 200
summon bedwars:text "§b" 197 236 105
summon bedwars:text "§b" 7 236 105
summon bedwars:text "§b" 102 236 10

