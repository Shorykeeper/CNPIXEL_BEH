# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 102 237 195
spawnpoint @s[scores={A1T12P=2}] 192 237 105
spawnpoint @s[scores={A1T12P=3}] 12 237 105
spawnpoint @s[scores={A1T12P=4}] 102 237 15
