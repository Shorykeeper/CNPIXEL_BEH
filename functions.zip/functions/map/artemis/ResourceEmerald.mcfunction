# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 81 240 120
summon minecrafts:emerald_spawner "" 123 240 78
#summon minecrafts:emerald_spawner "" 
#summon minecrafts:emerald_spawner "" 
