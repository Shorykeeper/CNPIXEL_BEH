# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 102 231 9
summon bedwars:text "§b" 192 231 99
summon bedwars:text "§b" 12 231 99
summon bedwars:text "§b" 102 231 189

