# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 55 232 146
summon minecrafts:diamond_spawner "" 55 232 52
summon minecrafts:diamond_spawner "" 149 232 52
summon minecrafts:diamond_spawner "" 149 232 146
