# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 96 232 16

summon template:npc 185 232 93
summon template:npc 19 232 105
summon template:npc 108 232 182