# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 102 232 14
spawnpoint @s[scores={A1T12P=2}] 187 232 99
spawnpoint @s[scores={A1T12P=3}] 17 232 99
spawnpoint @s[scores={A1T12P=4}] 102 232 184
