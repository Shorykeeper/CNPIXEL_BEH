# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 118 234 37


summon template:npc 171 234 100
summon template:npc 55 234 90
summon template:npc 108 234 153