# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 82 237 125
summon minecrafts:diamond_spawner "" 83 237 64
summon minecrafts:diamond_spawner "" 144 237 65
summon minecrafts:diamond_spawner "" 143 237 126
