# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 113 234 36
spawnpoint @s[scores={A1T12P=2}] 172 234 95
spawnpoint @s[scores={A1T12P=3}] 54 234 95
spawnpoint @s[scores={A1T12P=4}] 113 234 154
