# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 113 233 30
summon bedwars:text "§b" 178 233 95
summon bedwars:text "§b" 48 233 95
summon bedwars:text "§b" 113 233 160

