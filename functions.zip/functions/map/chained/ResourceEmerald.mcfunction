# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 111 242 106
summon minecrafts:emerald_spawner "" 89 242 106
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
