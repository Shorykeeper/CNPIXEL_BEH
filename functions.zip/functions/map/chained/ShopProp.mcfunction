# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 183 237 114


summon template:npc 17 237 98
summon template:npc 108 237 23
summon template:npc 92 237 189