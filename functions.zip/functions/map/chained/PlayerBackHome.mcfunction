# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 181 237 106
tp @s[scores={A1T12P=2}] 19 237 106
tp @s[scores={A1T12P=3}] 100 237 25
tp @s[scores={A1T12P=4}] 100 237 187
