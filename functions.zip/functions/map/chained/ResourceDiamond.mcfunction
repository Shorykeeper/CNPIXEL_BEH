# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 66 242 142
summon minecrafts:diamond_spawner "" 64 242 72
summon minecrafts:diamond_spawner "" 134 242 70
summon minecrafts:diamond_spawner "" 136 242 140
