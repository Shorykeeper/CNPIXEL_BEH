# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 187 236 106
summon bedwars:text "§b" 13 236 106
summon bedwars:text "§b" 100 236 19
summon bedwars:text "§b" 100 236 193

