# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 113 245 18


summon template:npc 193 245 110
summon template:npc 21 245 98
summon template:npc 101 245 190