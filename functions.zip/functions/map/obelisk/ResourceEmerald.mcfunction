# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 107 244 104
summon minecrafts:emerald_spawner "" 101 252 110
summon minecrafts:emerald_spawner "" 113 252 98
#summon minecrafts:diamond_spawner "" 
