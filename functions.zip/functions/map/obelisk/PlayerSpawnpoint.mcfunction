# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 107 245 20
spawnpoint @s[scores={A1T12P=2}] 191 245 104
spawnpoint @s[scores={A1T12P=3}] 23 245 104
spawnpoint @s[scores={A1T12P=4}] 107 245 188
