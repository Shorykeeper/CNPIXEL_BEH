# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 107 244 15
summon bedwars:text "§b" 196 244 104
summon bedwars:text "§b" 18 244 104
summon bedwars:text "§b" 107 244 193

