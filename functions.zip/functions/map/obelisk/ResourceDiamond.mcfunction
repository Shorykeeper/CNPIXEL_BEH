# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 72 245 139
summon minecrafts:diamond_spawner "" 72 245 69
summon minecrafts:diamond_spawner "" 142 245 69
summon minecrafts:diamond_spawner "" 142 245 139
