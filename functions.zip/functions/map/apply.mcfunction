# Coding = UTF-8
# designer: Shorykeeper
# Create by Qwen 
# CreateTime: 26/6/18

# 1. 潮起亚细亚 (HangZhou)
execute if score mapp B7O14L matches 1 as @a[scores={A1T12P=1..}] run function map/HangZhou/PlayerBackHome
execute if score mapp B7O14L matches 1 as @a[scores={A1T12P=1..}] run function map/HangZhou/PlayerSpawnpoint
execute if score mapp B7O14L matches 1 run function map/HangZhou/ResourceDiamond
execute if score mapp B7O14L matches 1 run function map/HangZhou/ResourceEmerald
execute if score mapp B7O14L matches 1 run function map/HangZhou/ResourceHQ
execute if score mapp B7O14L matches 1 run function map/HangZhou/ShopProp

# 2. 水族馆 (aquarium)
execute if score mapp B7O14L matches 2 as @a[scores={A1T12P=1..}] run function map/aquarium/PlayerBackHome
execute if score mapp B7O14L matches 2 as @a[scores={A1T12P=1..}] run function map/aquarium/PlayerSpawnpoint
execute if score mapp B7O14L matches 2 run function map/aquarium/ResourceDiamond
execute if score mapp B7O14L matches 2 run function map/aquarium/ResourceEmerald
execute if score mapp B7O14L matches 2 run function map/aquarium/ResourceHQ
execute if score mapp B7O14L matches 2 run function map/aquarium/ShopProp

# 3. 入侵 (invasion)
execute if score mapp B7O14L matches 3 as @a[scores={A1T12P=1..}] run function map/invasion/PlayerBackHome
execute if score mapp B7O14L matches 3 as @a[scores={A1T12P=1..}] run function map/invasion/PlayerSpawnpoint
execute if score mapp B7O14L matches 3 run function map/invasion/ResourceDiamond
execute if score mapp B7O14L matches 3 run function map/invasion/ResourceEmerald
execute if score mapp B7O14L matches 3 run function map/invasion/ResourceHQ
execute if score mapp B7O14L matches 3 run function map/invasion/ShopProp

# 4. 通讯站 (notify)
execute if score mapp B7O14L matches 4 as @a[scores={A1T12P=1..}] run function map/notify/PlayerBackHome
execute if score mapp B7O14L matches 4 as @a[scores={A1T12P=1..}] run function map/notify/PlayerSpawnpoint
execute if score mapp B7O14L matches 4 run function map/notify/ResourceDiamond
execute if score mapp B7O14L matches 4 run function map/notify/ResourceEmerald
execute if score mapp B7O14L matches 4 run function map/notify/ResourceHQ
execute if score mapp B7O14L matches 4 run function map/notify/ShopProp

# 5. 圣诞 (christmas)
execute if score mapp B7O14L matches 5 as @a[scores={A1T12P=1..}] run function map/christmas/PlayerBackHome
execute if score mapp B7O14L matches 5 as @a[scores={A1T12P=1..}] run function map/christmas/PlayerSpawnpoint
execute if score mapp B7O14L matches 5 run function map/christmas/ResourceDiamond
execute if score mapp B7O14L matches 5 run function map/christmas/ResourceEmerald
execute if score mapp B7O14L matches 5 run function map/christmas/ResourceHQ
execute if score mapp B7O14L matches 5 run function map/christmas/ShopProp

# 6. 菌落 (boletum)
execute if score mapp B7O14L matches 6 as @a[scores={A1T12P=1..}] run function map/boletum/PlayerBackHome
execute if score mapp B7O14L matches 6 as @a[scores={A1T12P=1..}] run function map/boletum/PlayerSpawnpoint
execute if score mapp B7O14L matches 6 run function map/boletum/ResourceDiamond
execute if score mapp B7O14L matches 6 run function map/boletum/ResourceEmerald
execute if score mapp B7O14L matches 6 run function map/boletum/ResourceHQ
execute if score mapp B7O14L matches 6 run function map/boletum/ShopProp

# 7. 冰淇淋 (iceCream)
execute if score mapp B7O14L matches 7 as @a[scores={A1T12P=1..}] run function map/iceCream/PlayerBackHome
execute if score mapp B7O14L matches 7 as @a[scores={A1T12P=1..}] run function map/iceCream/PlayerSpawnpoint
execute if score mapp B7O14L matches 7 run function map/iceCream/ResourceDiamond
execute if score mapp B7O14L matches 7 run function map/iceCream/ResourceEmerald
execute if score mapp B7O14L matches 7 run function map/iceCream/ResourceHQ
execute if score mapp B7O14L matches 7 run function map/iceCream/ShopProp

# 8. 灯笼节 (dengLoong)
execute if score mapp B7O14L matches 8 as @a[scores={A1T12P=1..}] run function map/dengLoong/PlayerBackHome
execute if score mapp B7O14L matches 8 as @a[scores={A1T12P=1..}] run function map/dengLoong/PlayerSpawnpoint
execute if score mapp B7O14L matches 8 run function map/dengLoong/ResourceDiamond
execute if score mapp B7O14L matches 8 run function map/dengLoong/ResourceEmerald
execute if score mapp B7O14L matches 8 run function map/dengLoong/ResourceHQ
execute if score mapp B7O14L matches 8 run function map/dengLoong/ShopProp

# 9. 刀龙 (DaoLong)
execute if score mapp B7O14L matches 9 as @a[scores={A1T12P=1..}] run function map/DaoLong/PlayerBackHome
execute if score mapp B7O14L matches 9 as @a[scores={A1T12P=1..}] run function map/DaoLong/PlayerSpawnpoint
execute if score mapp B7O14L matches 9 run function map/DaoLong/ResourceDiamond
execute if score mapp B7O14L matches 9 run function map/DaoLong/ResourceEmerald
execute if score mapp B7O14L matches 9 run function map/DaoLong/ResourceHQ
execute if score mapp B7O14L matches 9 run function map/DaoLong/ShopProp

# 10. 城堡 (castle)
execute if score mapp B7O14L matches 10 as @a[scores={A1T12P=1..}] run function map/castle/PlayerBackHome
execute if score mapp B7O14L matches 10 as @a[scores={A1T12P=1..}] run function map/castle/PlayerSpawnpoint
execute if score mapp B7O14L matches 10 run function map/castle/ResourceDiamond
execute if score mapp B7O14L matches 10 run function map/castle/ResourceEmerald
execute if score mapp B7O14L matches 10 run function map/castle/ResourceHQ
execute if score mapp B7O14L matches 10 run function map/castle/ShopProp

# 11. 胜津城 (katsu)
execute if score mapp B7O14L matches 11 as @a[scores={A1T12P=1..}] run function map/katsu/PlayerBackHome
execute if score mapp B7O14L matches 11 as @a[scores={A1T12P=1..}] run function map/katsu/PlayerSpawnpoint
execute if score mapp B7O14L matches 11 run function map/katsu/ResourceDiamond
execute if score mapp B7O14L matches 11 run function map/katsu/ResourceEmerald
execute if score mapp B7O14L matches 11 run function map/katsu/ResourceHQ
execute if score mapp B7O14L matches 11 run function map/katsu/ShopProp

# 12. 壳 (carapace)
execute if score mapp B7O14L matches 12 as @a[scores={A1T12P=1..}] run function map/carapace/PlayerBackHome
execute if score mapp B7O14L matches 12 as @a[scores={A1T12P=1..}] run function map/carapace/PlayerSpawnpoint
execute if score mapp B7O14L matches 12 run function map/carapace/ResourceDiamond
execute if score mapp B7O14L matches 12 run function map/carapace/ResourceEmerald
execute if score mapp B7O14L matches 12 run function map/carapace/ResourceHQ
execute if score mapp B7O14L matches 12 run function map/carapace/ShopProp

# 13. 阿尔忒弥斯 (artemis)
execute if score mapp B7O14L matches 13 as @a[scores={A1T12P=1..}] run function map/artemis/PlayerBackHome
execute if score mapp B7O14L matches 13 as @a[scores={A1T12P=1..}] run function map/artemis/PlayerSpawnpoint
execute if score mapp B7O14L matches 13 run function map/artemis/ResourceDiamond
execute if score mapp B7O14L matches 13 run function map/artemis/ResourceEmerald
execute if score mapp B7O14L matches 13 run function map/artemis/ResourceHQ
execute if score mapp B7O14L matches 13 run function map/artemis/ShopProp

# 14. 斗拱 (archway)
execute if score mapp B7O14L matches 14 as @a[scores={A1T12P=1..}] run function map/archway/PlayerBackHome
execute if score mapp B7O14L matches 14 as @a[scores={A1T12P=1..}] run function map/archway/PlayerSpawnpoint
execute if score mapp B7O14L matches 14 run function map/archway/ResourceDiamond
execute if score mapp B7O14L matches 14 run function map/archway/ResourceEmerald
execute if score mapp B7O14L matches 14 run function map/archway/ResourceHQ
execute if score mapp B7O14L matches 14 run function map/archway/ShopProp

# 15. 建筑工地 (buildSite)
execute if score mapp B7O14L matches 15 as @a[scores={A1T12P=1..}] run function map/buildSite/PlayerBackHome
execute if score mapp B7O14L matches 15 as @a[scores={A1T12P=1..}] run function map/buildSite/PlayerSpawnpoint
execute if score mapp B7O14L matches 15 run function map/buildSite/ResourceDiamond
execute if score mapp B7O14L matches 15 run function map/buildSite/ResourceEmerald
execute if score mapp B7O14L matches 15 run function map/buildSite/ResourceHQ
execute if score mapp B7O14L matches 15 run function map/buildSite/ShopProp

# 16. 庇护营地 (shelter)
execute if score mapp B7O14L matches 16 as @a[scores={A1T12P=1..}] run function map/shelter/PlayerBackHome
execute if score mapp B7O14L matches 16 as @a[scores={A1T12P=1..}] run function map/shelter/PlayerSpawnpoint
execute if score mapp B7O14L matches 16 run function map/shelter/ResourceDiamond
execute if score mapp B7O14L matches 16 run function map/shelter/ResourceEmerald
execute if score mapp B7O14L matches 16 run function map/shelter/ResourceHQ
execute if score mapp B7O14L matches 16 run function map/shelter/ShopProp

# 17. 岸滨 (ashore)
execute if score mapp B7O14L matches 17 as @a[scores={A1T12P=1..}] run function map/ashore/PlayerBackHome
execute if score mapp B7O14L matches 17 as @a[scores={A1T12P=1..}] run function map/ashore/PlayerSpawnpoint
execute if score mapp B7O14L matches 17 run function map/ashore/ResourceDiamond
execute if score mapp B7O14L matches 17 run function map/ashore/ResourceEmerald
execute if score mapp B7O14L matches 17 run function map/ashore/ResourceHQ
execute if score mapp B7O14L matches 17 run function map/ashore/ShopProp

# 18. 方碑 (obelisk)
execute if score mapp B7O14L matches 18 as @a[scores={A1T12P=1..}] run function map/obelisk/PlayerBackHome
execute if score mapp B7O14L matches 18 as @a[scores={A1T12P=1..}] run function map/obelisk/PlayerSpawnpoint
execute if score mapp B7O14L matches 18 run function map/obelisk/ResourceDiamond
execute if score mapp B7O14L matches 18 run function map/obelisk/ResourceEmerald
execute if score mapp B7O14L matches 18 run function map/obelisk/ResourceHQ
execute if score mapp B7O14L matches 18 run function map/obelisk/ShopProp

# 19. 大庙 (temple)
execute if score mapp B7O14L matches 19 as @a[scores={A1T12P=1..}] run function map/temple/PlayerBackHome
execute if score mapp B7O14L matches 19 as @a[scores={A1T12P=1..}] run function map/temple/PlayerSpawnpoint
execute if score mapp B7O14L matches 19 run function map/temple/ResourceDiamond
execute if score mapp B7O14L matches 19 run function map/temple/ResourceEmerald
execute if score mapp B7O14L matches 19 run function map/temple/ResourceHQ
execute if score mapp B7O14L matches 19 run function map/temple/ShopProp

# 20. 伊斯特伍德 (eastwood)
execute if score mapp B7O14L matches 20 as @a[scores={A1T12P=1..}] run function map/eastwood/PlayerBackHome
execute if score mapp B7O14L matches 20 as @a[scores={A1T12P=1..}] run function map/eastwood/PlayerSpawnpoint
execute if score mapp B7O14L matches 20 run function map/eastwood/ResourceDiamond
execute if score mapp B7O14L matches 20 run function map/eastwood/ResourceEmerald
execute if score mapp B7O14L matches 20 run function map/eastwood/ResourceHQ
execute if score mapp B7O14L matches 20 run function map/eastwood/ShopProp

# 21. 航空站 (terminal)
execute if score mapp B7O14L matches 21 as @a[scores={A1T12P=1..}] run function map/terminal/PlayerBackHome
execute if score mapp B7O14L matches 21 as @a[scores={A1T12P=1..}] run function map/terminal/PlayerSpawnpoint
execute if score mapp B7O14L matches 21 run function map/terminal/ResourceDiamond
execute if score mapp B7O14L matches 21 run function map/terminal/ResourceEmerald
execute if score mapp B7O14L matches 21 run function map/terminal/ResourceHQ
execute if score mapp B7O14L matches 21 run function map/terminal/ShopProp

# 22. 幽兰花 (orchid)
execute if score mapp B7O14L matches 22 as @a[scores={A1T12P=1..}] run function map/orchid/PlayerBackHome
execute if score mapp B7O14L matches 22 as @a[scores={A1T12P=1..}] run function map/orchid/PlayerSpawnpoint
execute if score mapp B7O14L matches 22 run function map/orchid/ResourceDiamond
execute if score mapp B7O14L matches 22 run function map/orchid/ResourceEmerald
execute if score mapp B7O14L matches 22 run function map/orchid/ResourceHQ
execute if score mapp B7O14L matches 22 run function map/orchid/ShopProp

# 23. 铁索连环 (chained)
execute if score mapp B7O14L matches 23 as @a[scores={A1T12P=1..}] run function map/chained/PlayerBackHome
execute if score mapp B7O14L matches 23 as @a[scores={A1T12P=1..}] run function map/chained/PlayerSpawnpoint
execute if score mapp B7O14L matches 23 run function map/chained/ResourceDiamond
execute if score mapp B7O14L matches 23 run function map/chained/ResourceEmerald
execute if score mapp B7O14L matches 23 run function map/chained/ResourceHQ
execute if score mapp B7O14L matches 23 run function map/chained/ShopProp

# 24. Rise (rise)
execute if score mapp B7O14L matches 24 as @a[scores={A1T12P=1..}] run function map/rise/PlayerBackHome
execute if score mapp B7O14L matches 24 as @a[scores={A1T12P=1..}] run function map/rise/PlayerSpawnpoint
execute if score mapp B7O14L matches 24 run function map/rise/ResourceDiamond
execute if score mapp B7O14L matches 24 run function map/rise/ResourceEmerald
execute if score mapp B7O14L matches 24 run function map/rise/ResourceHQ
execute if score mapp B7O14L matches 24 run function map/rise/ShopProp

# 25. 万圣海盗船 (ship)
execute if score mapp B7O14L matches 25 as @a[scores={A1T12P=1..}] run function map/ship/PlayerBackHome
execute if score mapp B7O14L matches 25 as @a[scores={A1T12P=1..}] run function map/ship/PlayerSpawnpoint
execute if score mapp B7O14L matches 25 run function map/ship/ResourceDiamond
execute if score mapp B7O14L matches 25 run function map/ship/ResourceEmerald
execute if score mapp B7O14L matches 25 run function map/ship/ResourceHQ
execute if score mapp B7O14L matches 25 run function map/ship/ShopProp

# 26. 复活节 (easter)
execute if score mapp B7O14L matches 26 as @a[scores={A1T12P=1..}] run function map/easter/PlayerBackHome
execute if score mapp B7O14L matches 26 as @a[scores={A1T12P=1..}] run function map/easter/PlayerSpawnpoint
execute if score mapp B7O14L matches 26 run function map/easter/ResourceDiamond
execute if score mapp B7O14L matches 26 run function map/easter/ResourceEmerald
execute if score mapp B7O14L matches 26 run function map/easter/ResourceHQ
execute if score mapp B7O14L matches 26 run function map/easter/ShopProp

# 27. 梦幻林 (dreamGrove)
execute if score mapp B7O14L matches 27 as @a[scores={A1T12P=1..}] run function map/dreamGrove/PlayerBackHome
execute if score mapp B7O14L matches 27 as @a[scores={A1T12P=1..}] run function map/dreamGrove/PlayerSpawnpoint
execute if score mapp B7O14L matches 27 run function map/dreamGrove/ResourceDiamond
execute if score mapp B7O14L matches 27 run function map/dreamGrove/ResourceEmerald
execute if score mapp B7O14L matches 27 run function map/dreamGrove/ResourceHQ
execute if score mapp B7O14L matches 27 run function map/dreamGrove/ShopProp


execute positioned 111 230 104 as @e[type=template:npc,r=350] run tag @s add 道具商店

# 先统一生成点击
execute as @e[tag=道具商店] at @s run summon bedwars:text "§e§l右键点击" ~~1.6~

# 视情况生成什么商店名
execute unless score mode O8P02W matches 1 as @e[rm=100,type=template:npc,tag=道具商店] at @s run summon bedwars:text "§b道具商店" ~~2.0~
execute if score mode O8P02W matches 1 as @e[rm=100,type=template:npc,tag=道具商店] at @s run summon bedwars:text "§b切床装备补充" ~~2.0~


# ShopUpgrade 集中部分
execute if score mapp B7O14L matches 1 run function map/HangZhou/ShopUpgrade
execute if score mapp B7O14L matches 2 run function map/aquarium/ShopUpgrade
execute if score mapp B7O14L matches 3 run function map/invasion/ShopUpgrade
execute if score mapp B7O14L matches 4 run function map/notify/ShopUpgrade
execute if score mapp B7O14L matches 5 run function map/christmas/ShopUpgrade
execute if score mapp B7O14L matches 6 run function map/boletum/ShopUpgrade
execute if score mapp B7O14L matches 7 run function map/iceCream/ShopUpgrade
execute if score mapp B7O14L matches 8 run function map/dengLoong/ShopUpgrade
execute if score mapp B7O14L matches 9 run function map/DaoLong/ShopUpgrade
execute if score mapp B7O14L matches 10 run function map/castle/ShopUpgrade
execute if score mapp B7O14L matches 11 run function map/katsu/ShopUpgrade
execute if score mapp B7O14L matches 12 run function map/carapace/ShopUpgrade
execute if score mapp B7O14L matches 13 run function map/artemis/ShopUpgrade
execute if score mapp B7O14L matches 14 run function map/archway/ShopUpgrade
execute if score mapp B7O14L matches 15 run function map/buildSite/ShopUpgrade
execute if score mapp B7O14L matches 16 run function map/shelter/ShopUpgrade
execute if score mapp B7O14L matches 17 run function map/ashore/ShopUpgrade
execute if score mapp B7O14L matches 18 run function map/obelisk/ShopUpgrade
execute if score mapp B7O14L matches 19 run function map/temple/ShopUpgrade
execute if score mapp B7O14L matches 20 run function map/eastwood/ShopUpgrade
execute if score mapp B7O14L matches 21 run function map/terminal/ShopUpgrade
execute if score mapp B7O14L matches 22 run function map/orchid/ShopUpgrade
execute if score mapp B7O14L matches 23 run function map/chained/ShopUpgrade
execute if score mapp B7O14L matches 24 run function map/rise/ShopUpgrade
execute if score mapp B7O14L matches 25 run function map/ship/ShopUpgrade
execute if score mapp B7O14L matches 26 run function map/easter/ShopUpgrade
execute if score mapp B7O14L matches 27 run function map/dreamGrove/ShopUpgrade

execute positioned 2315 240 2285 as @e[rm=200,type=template:npc,tag=!道具商店] at @s run summon bedwars:text "§e§l右键点击" ~~1.6~

execute positioned 2315 240 2285 as @e[rm=200,type=template:npc,tag=!道具商店] at @s run summon bedwars:text "§b升级" ~~2.0~
execute positioned 2315 240 2285 as @e[rm=200,type=template:npc,tag=!道具商店] at @s run summon bedwars:text "§b团队模式" ~~2.4~
