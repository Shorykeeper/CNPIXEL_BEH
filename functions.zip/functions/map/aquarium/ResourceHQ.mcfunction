# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 104 239 42
summon bedwars:text "§b" 168 239 106
summon bedwars:text "§b" 40 239 106
summon bedwars:text "§b" 104 239 171

