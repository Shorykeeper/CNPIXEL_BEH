# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 104 239 46
tp @s[scores={A1T12P=2}] 164 239 106
tp @s[scores={A1T12P=3}] 44 239 106
tp @s[scores={A1T12P=4}] 104 239 166
