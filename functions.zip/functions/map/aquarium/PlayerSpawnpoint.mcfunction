# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 104 239 13
spawnpoint @s[scores={A1T12P=2}] 104 239 106
spawnpoint @s[scores={A1T12P=3}] 44 239 106
spawnpoint @s[scores={A1T12P=4}] 104 239 166
