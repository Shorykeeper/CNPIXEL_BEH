# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 63 238 67
summon minecrafts:diamond_spawner "" 65 237 147
summon minecrafts:diamond_spawner "" 145 237 145
summon minecrafts:diamond_spawner "" 143 237 65
