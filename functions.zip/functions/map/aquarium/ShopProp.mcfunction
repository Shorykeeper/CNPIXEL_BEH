# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 109 239 46
summon template:npc 164 239 111
summon template:npc 44 239 101
summon template:npc 99 239 166
