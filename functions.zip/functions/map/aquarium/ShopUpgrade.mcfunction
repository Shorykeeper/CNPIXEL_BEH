# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 109 239 49
summon template:npc 161 239 111
summon template:npc 47 239 101 
summon template:npc 99 239 163