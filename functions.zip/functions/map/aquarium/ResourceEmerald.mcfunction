# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 112 250 117
summon minecrafts:emerald_spawner "" 94 250 95
