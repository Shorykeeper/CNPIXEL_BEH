# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 108 232 187

summon template:npc 94 232 27
summon template:npc 21 232 114
summon template:npc 181 232 100