# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 97 232 187


summon template:npc 105 232 27
summon template:npc 21 232 103
summon template:npc 181 232 111