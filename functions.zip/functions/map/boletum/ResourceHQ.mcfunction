# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 102 231 191
summon bedwars:text "§b" 100 231 23
summon bedwars:text "§b" 17 231 108
summon bedwars:text "§b" 185 231 106

