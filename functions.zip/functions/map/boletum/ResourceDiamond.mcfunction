# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 145 236 151
summon minecrafts:diamond_spawner "" 59 236 151
summon minecrafts:diamond_spawner "" 59 236 65
summon minecrafts:diamond_spawner "" 145 236 65
