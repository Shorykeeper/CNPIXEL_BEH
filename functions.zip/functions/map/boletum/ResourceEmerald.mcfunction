# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 111 240 120
summon minecrafts:emerald_spawner "" 91 240 96
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
