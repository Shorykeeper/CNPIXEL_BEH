# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 102 232 186
tp @s[scores={A1T12P=2}] 100 232 28
tp @s[scores={A1T12P=3}] 22 232 108
tp @s[scores={A1T12P=4}] 180 232 106
