# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 102 232 186
spawnpoint @s[scores={A1T12P=2}] 100 232 28
spawnpoint @s[scores={A1T12P=3}] 22 232 108
spawnpoint @s[scores={A1T12P=4}] 180 232 106
