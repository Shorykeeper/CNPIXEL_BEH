# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 111 234 34
tp @s[scores={A1T12P=2}] 181 234 104
tp @s[scores={A1T12P=3}] 41 234 104
tp @s[scores={A1T12P=4}] 111 234 174
