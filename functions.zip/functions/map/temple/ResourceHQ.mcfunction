# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 111 233 29
summon bedwars:text "§b" 186 233 104
summon bedwars:text "§b" 36 233 104
summon bedwars:text "§b" 111 233 179

