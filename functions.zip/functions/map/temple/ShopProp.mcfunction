# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 107 234 32


summon template:npc 183 234 100
summon template:npc 39 234 108
summon template:npc 115 234 176