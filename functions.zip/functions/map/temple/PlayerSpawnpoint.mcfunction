# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 111 234 34
spawnpoint @s[scores={A1T12P=2}] 181 234 104
spawnpoint @s[scores={A1T12P=3}] 41 234 104
spawnpoint @s[scores={A1T12P=4}] 111 234 174
