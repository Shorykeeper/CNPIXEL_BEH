# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 107 234 36

summon template:npc 179 234 100
summon template:npc 43 234 108
summon template:npc 115 234 172