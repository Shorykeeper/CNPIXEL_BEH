# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 101 236 43
tp @s[scores={A1T12P=2}] 169 236 111
tp @s[scores={A1T12P=3}] 33 236 111
tp @s[scores={A1T12P=4}] 101 236 179
