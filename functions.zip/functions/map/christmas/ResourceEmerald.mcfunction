# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 101 238 111
summon minecrafts:emerald_spawner "" 101 248 111
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
