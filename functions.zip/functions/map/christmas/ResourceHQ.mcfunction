# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 101 235 39
summon bedwars:text "§b" 173 235 111
summon bedwars:text "§b" 29 235 111
summon bedwars:text "§b" 101 235 183

