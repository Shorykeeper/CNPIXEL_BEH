# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 106 236 43


summon template:npc 169 236 116
summon template:npc 33 236 106
summon template:npc 96 236 179