# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 64 238 148
summon minecrafts:diamond_spawner "" 64 238 74
summon minecrafts:diamond_spawner "" 138 238 74
summon minecrafts:diamond_spawner "" 138 238 148
