# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 9 236 93
summon template:npc 112 236 9
summon template:npc 94 236 196
summon template:npc 197 236 111
