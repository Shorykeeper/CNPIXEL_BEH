# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 7 236 95
summon template:npc 110 236 7
summon template:npc 96 236 198
summon template:npc 199 236 109
