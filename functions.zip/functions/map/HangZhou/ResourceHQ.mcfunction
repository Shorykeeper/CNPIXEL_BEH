# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 3 235 102
summon bedwars:text "§b" 103 235 3
summon bedwars:text "§b" 104 235 202
summon bedwars:text "§b" 203 235 101

