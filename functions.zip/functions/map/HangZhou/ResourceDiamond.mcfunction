# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 105 234 130
summon minecrafts:diamond_spawner "" 77 234 102
summon minecrafts:diamond_spawner "" 105 234 74
summon minecrafts:diamond_spawner "" 134 234 102
