# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 10 236 102
tp @s[scores={A1T12P=2}] 103 236 10
tp @s[scores={A1T12P=3}] 103 236 195
tp @s[scores={A1T12P=4}] 196 236 102
