# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 105 236 102
summon minecrafts:emerald_spawner "" 118 237 79
summon minecrafts:emerald_spawner "" 93 237 128
