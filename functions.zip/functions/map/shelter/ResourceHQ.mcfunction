# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 15 240 103
summon bedwars:text "§b" 103 240 15
summon bedwars:text "§b" 103 240 191
summon bedwars:text "§b" 191 240 103

