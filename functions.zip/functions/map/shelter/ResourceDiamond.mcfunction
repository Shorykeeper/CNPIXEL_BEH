# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 154 248 154
summon minecrafts:diamond_spawner "" 52 248 154
summon minecrafts:diamond_spawner "" 52 248 52
summon minecrafts:diamond_spawner "" 154 248 52
