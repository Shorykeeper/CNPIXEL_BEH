# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 19 241 108

summon template:npc 98 241 19
summon template:npc 108 241 187
summon template:npc 187 241 98