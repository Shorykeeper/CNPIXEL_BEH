# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 103 242 103
summon minecrafts:emerald_spawner "" 115 243 115
summon minecrafts:emerald_spawner "" 91 243 91
#summon minecrafts:diamond_spawner "" 
