# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 22 241 103
tp @s[scores={A1T12P=2}] 103 241 22
tp @s[scores={A1T12P=3}] 103 241 184
tp @s[scores={A1T12P=4}] 184 241 103
