# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 164 243 66


summon template:npc 156 243 162
summon template:npc 60 243 66
summon template:npc 68 243 162