# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 156 243 58

summon template:npc 164 243 154
summon template:npc 68 243 58
summon template:npc 60 243 154