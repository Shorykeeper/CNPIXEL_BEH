# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 125 253 110
summon minecrafts:emerald_spawner "" 99 253 110
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
