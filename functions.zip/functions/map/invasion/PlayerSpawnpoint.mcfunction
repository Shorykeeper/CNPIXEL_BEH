# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 160 243 63
spawnpoint @s[scores={A1T12P=2}] 160 243 158
spawnpoint @s[scores={A1T12P=3}] 64 243 62
spawnpoint @s[scores={A1T12P=4}] 64 243 158
