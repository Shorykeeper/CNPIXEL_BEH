# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 164 243 58
summon bedwars:text "§b" 164 243 162
summon bedwars:text "§b" 60 243 58
summon bedwars:text "§b" 60 243 162

