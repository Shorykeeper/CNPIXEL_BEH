# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 64 240 110
summon minecrafts:diamond_spawner "" 112 240 62
summon minecrafts:diamond_spawner "" 112 240 158
summon minecrafts:diamond_spawner "" 160 240 110
