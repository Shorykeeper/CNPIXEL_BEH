# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 160 243 63
tp @s[scores={A1T12P=2}] 160 243 158
tp @s[scores={A1T12P=3}] 64 243 62
tp @s[scores={A1T12P=4}] 64 243 158
