# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 143 233 143
summon minecrafts:diamond_spawner "" 53 233 143
summon minecrafts:diamond_spawner "" 53 233 53
summon minecrafts:diamond_spawner "" 143 233 53
