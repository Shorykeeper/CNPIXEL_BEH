# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 107 237 100
summon minecrafts:emerald_spawner "" 89 237 96
summon minecrafts:emerald_spawner "" 98 249 98
#summon minecrafts:diamond_spawner "" 
