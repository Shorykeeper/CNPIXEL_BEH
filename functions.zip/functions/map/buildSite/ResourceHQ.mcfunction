# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 5 231 98
summon bedwars:text "§b" 98 231 5
summon bedwars:text "§b" 98 231 191
summon bedwars:text "§b" 191 231 98

