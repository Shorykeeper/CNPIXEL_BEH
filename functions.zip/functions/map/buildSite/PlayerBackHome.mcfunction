# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 14 232 98
tp @s[scores={A1T12P=2}] 98 232 14
tp @s[scores={A1T12P=3}] 98 232 182
tp @s[scores={A1T12P=4}] 182 232 98
