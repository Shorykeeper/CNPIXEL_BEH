# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 14 232 93


summon template:npc 103 232 14
summon template:npc 93 232 182
summon template:npc 182 232 103