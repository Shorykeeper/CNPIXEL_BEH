# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 103 236 9
tp @s[scores={A1T12P=2}] 200 236 102
tp @s[scores={A1T12P=3}] 10 236 106
tp @s[scores={A1T12P=4}] 107 236 199
