# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 195 252 194
summon minecrafts:diamond_spawner "" 178 236 177
summon minecrafts:diamond_spawner "" 15 252 14
summon minecrafts:diamond_spawner "" 32 236 31
