# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 111 235 8
summon template:npc 201 235 110
summon template:npc 9 235 98
summon template:npc 99 235 209
