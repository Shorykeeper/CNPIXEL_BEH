# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 103 235 2
summon bedwars:text "§b" 207 235 102
summon bedwars:text "§b" 3 235 106
summon bedwars:text "§b" 107 235 206
