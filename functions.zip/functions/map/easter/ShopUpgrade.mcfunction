# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 111 235 12
summon template:npc 197 235 110
summon template:npc 13 235 98
summon template:npc 99 235 196
