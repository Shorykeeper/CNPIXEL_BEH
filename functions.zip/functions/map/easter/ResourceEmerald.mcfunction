# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 133 245 76
summon minecrafts:emerald_spawner "" 77 245 132
#summon minecrafts:emerald_spawner ""
#summon minecrafts:emerald_spawner ""
