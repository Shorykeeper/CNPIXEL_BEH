# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 103 231 15
summon bedwars:text "§b" 194 231 106
summon bedwars:text "§b" 12 231 106
summon bedwars:text "§b" 103 231 197

