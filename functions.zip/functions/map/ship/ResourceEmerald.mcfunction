# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 96 237 99
summon minecrafts:emerald_spawner "" 110 237 113
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
