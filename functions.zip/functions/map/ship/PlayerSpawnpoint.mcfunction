# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 103 232 21
spawnpoint @s[scores={A1T12P=2}] 188 232 106
spawnpoint @s[scores={A1T12P=3}] 18 232 106
spawnpoint @s[scores={A1T12P=4}] 103 232 191
