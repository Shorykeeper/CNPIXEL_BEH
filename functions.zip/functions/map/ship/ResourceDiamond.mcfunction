# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 68 236 141
summon minecrafts:diamond_spawner "" 138 236 141
summon minecrafts:diamond_spawner "" 138 236 71
summon minecrafts:diamond_spawner "" 68 236 71
