# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 98 232 21

summon template:npc 188 232 101
summon template:npc 18 232 111
summon template:npc 108 232 191