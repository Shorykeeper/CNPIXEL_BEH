# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 107 237 14
summon bedwars:text "§b" 193 237 100
summon bedwars:text "§b" 21 237 100
summon bedwars:text "§b" 107 237 186

