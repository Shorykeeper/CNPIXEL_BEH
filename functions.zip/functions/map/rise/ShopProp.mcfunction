# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 112 238 20


summon template:npc 187 238 105
summon template:npc 27 238 95
summon template:npc 102 238 180