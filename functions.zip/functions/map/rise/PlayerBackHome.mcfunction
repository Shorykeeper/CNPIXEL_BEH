# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 107 238 19
tp @s[scores={A1T12P=2}] 188 238 100
tp @s[scores={A1T12P=3}] 26 238 100
tp @s[scores={A1T12P=4}] 107 238 181
