# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 63 255 144
summon minecrafts:diamond_spawner "" 63 255 56
summon minecrafts:diamond_spawner "" 151 255 56
summon minecrafts:diamond_spawner "" 151 255 144
