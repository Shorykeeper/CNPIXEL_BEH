# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 131 245 124
summon minecrafts:emerald_spawner "" 83 245 76
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
