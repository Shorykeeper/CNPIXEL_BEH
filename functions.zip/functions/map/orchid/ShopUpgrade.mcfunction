# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 163 235 52

summon template:npc 163 235 160
summon template:npc 53 235 52
summon template:npc 53 235 160