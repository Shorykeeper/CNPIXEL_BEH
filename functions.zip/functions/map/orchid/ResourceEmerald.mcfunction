# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 108 238 114
summon minecrafts:emerald_spawner "" 108 238 98
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
