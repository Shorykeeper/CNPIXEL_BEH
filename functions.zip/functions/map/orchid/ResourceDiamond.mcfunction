# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 108 238 182
summon minecrafts:diamond_spawner "" 52 238 106
summon minecrafts:diamond_spawner "" 108 238 30
summon minecrafts:diamond_spawner "" 164 238 106
