# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 171 234 56
summon bedwars:text "§b" 171 234 156
summon bedwars:text "§b" 45 234 56
summon bedwars:text "§b" 45 234 156

