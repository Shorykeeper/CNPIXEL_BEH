# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 166 235 56
tp @s[scores={A1T12P=2}] 166 235 156
tp @s[scores={A1T12P=3}] 50 235 56
tp @s[scores={A1T12P=4}] 50 235 156
