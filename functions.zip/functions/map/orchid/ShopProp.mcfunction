# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 166 235 61


summon template:npc 166 235 151
summon template:npc 50 235 61
summon template:npc 50 235 151