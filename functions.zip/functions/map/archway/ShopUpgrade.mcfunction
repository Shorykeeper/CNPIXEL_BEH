# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 83 229 26

summon template:npc 177 229 82
summon template:npc 27 229 120
summon template:npc 121 229 176