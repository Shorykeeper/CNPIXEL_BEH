# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 88 229 26
tp @s[scores={A1T12P=2}] 177 229 87
tp @s[scores={A1T12P=3}] 27 229 115
tp @s[scores={A1T12P=4}] 116 229 176
