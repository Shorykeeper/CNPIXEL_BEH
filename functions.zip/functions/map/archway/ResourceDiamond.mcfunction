# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 68 233 150
summon minecrafts:diamond_spawner "" 53 233 67
summon minecrafts:diamond_spawner "" 136 233 52
summon minecrafts:diamond_spawner "" 151 233 135
