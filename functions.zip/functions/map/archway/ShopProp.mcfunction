# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 93 229 26


summon template:npc 177 229 92
summon template:npc 27 229 110
summon template:npc 111 229 176