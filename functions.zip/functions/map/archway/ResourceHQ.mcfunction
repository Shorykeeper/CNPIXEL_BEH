# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 88 228 21
summon bedwars:text "§b" 182 228 87
summon bedwars:text "§b" 22 228 115
summon bedwars:text "§b" 116 228 181

