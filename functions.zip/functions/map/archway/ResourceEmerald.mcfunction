# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 102 232 101
summon minecrafts:emerald_spawner "" 102 242 101
#summon minecrafts:emerald_spawner "" 
#summon minecrafts:emerald_spawner "" 
