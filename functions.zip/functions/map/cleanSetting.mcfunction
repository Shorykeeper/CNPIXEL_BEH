# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 不是疾速模式清除疾速保护
# 在游戏开始倒计时的时候执行一次

# 先给对应使用地图的床生成一个计算实体
# 游戏母图需要提前围上床保护
execute if score mapp B7O14L matches 1 run summon rabbit "§d" 17 236 102
execute if score mapp B7O14L matches 1 run summon rabbit "§d" 103 236 17
execute if score mapp B7O14L matches 1 run summon rabbit "§d" 103 236 188
execute if score mapp B7O14L matches 1 run summon rabbit "§d" 189 236 102
execute if score mapp B7O14L matches 2 run summon rabbit "§d" 104 239 57
execute if score mapp B7O14L matches 2 run summon rabbit "§d" 153 239 106
execute if score mapp B7O14L matches 2 run summon rabbit "§d" 55 239 106
execute if score mapp B7O14L matches 2 run summon rabbit "§d" 104 239 155
execute if score mapp B7O14L matches 3 run summon rabbit "§d" 151 242 71
execute if score mapp B7O14L matches 3 run summon rabbit "§d" 151 242 149
execute if score mapp B7O14L matches 3 run summon rabbit "§d" 73 242 71
execute if score mapp B7O14L matches 3 run summon rabbit "§d" 73 242 149
execute if score mapp B7O14L matches 4 run summon rabbit "§d" 102 235 184
execute if score mapp B7O14L matches 4 run summon rabbit "§d" 181 235 105
execute if score mapp B7O14L matches 4 run summon rabbit "§d" 23 235 105
execute if score mapp B7O14L matches 4 run summon rabbit "§d" 102 235 26
execute if score mapp B7O14L matches 5 run summon rabbit "§d" 101 234 54
execute if score mapp B7O14L matches 5 run summon rabbit "§d" 158 234 111
execute if score mapp B7O14L matches 5 run summon rabbit "§d" 44 234 111
execute if score mapp B7O14L matches 5 run summon rabbit "§d" 101 234 168
execute if score mapp B7O14L matches 6 run summon rabbit "§d" 102 231 174
execute if score mapp B7O14L matches 6 run summon rabbit "§d" 100 231 40
execute if score mapp B7O14L matches 6 run summon rabbit "§d" 34 231 108
execute if score mapp B7O14L matches 6 run summon rabbit "§d" 168 231 106
execute if score mapp B7O14L matches 7 run summon rabbit "§d" 54 245 108
execute if score mapp B7O14L matches 7 run summon rabbit "§d" 108 245 54
execute if score mapp B7O14L matches 7 run summon rabbit "§d" 108 245 162
execute if score mapp B7O14L matches 7 run summon rabbit "§d" 162 245 108
execute if score mapp B7O14L matches 8 run summon rabbit "§d" 100 229 44
execute if score mapp B7O14L matches 8 run summon rabbit "§d" 159 225 102
execute if score mapp B7O14L matches 8 run summon rabbit "§d" 41 225 102
execute if score mapp B7O14L matches 8 run summon rabbit "§d" 100 225 162
execute if score mapp B7O14L matches 9 run summon rabbit "§d" 100 226 37
execute if score mapp B7O14L matches 9 run summon rabbit "§d" 163 226 100
execute if score mapp B7O14L matches 9 run summon rabbit "§d" 37 226 100
execute if score mapp B7O14L matches 9 run summon rabbit "§d" 100 226 163
execute if score mapp B7O14L matches 10 run summon rabbit "§d" 106 228 36
execute if score mapp B7O14L matches 10 run summon rabbit "§d" 172 228 102
execute if score mapp B7O14L matches 10 run summon rabbit "§d" 40 228 102
execute if score mapp B7O14L matches 10 run summon rabbit "§d" 106 228 168
execute if score mapp B7O14L matches 11 run summon rabbit "§d" 106 228 30
execute if score mapp B7O14L matches 11 run summon rabbit "§d" 179 228 103
execute if score mapp B7O14L matches 11 run summon rabbit "§d" 33 228 103
execute if score mapp B7O14L matches 11 run summon rabbit "§d" 106 228 176
execute if score mapp B7O14L matches 12 run summon rabbit "§d" 113 232 47
execute if score mapp B7O14L matches 12 run summon rabbit "§d" 161 232 95
execute if score mapp B7O14L matches 12 run summon rabbit "§d" 65 232 95
execute if score mapp B7O14L matches 12 run summon rabbit "§d" 113 232 143
execute if score mapp B7O14L matches 13 run summon rabbit "§d" 102 227 35
execute if score mapp B7O14L matches 13 run summon rabbit "§d" 166 227 99
execute if score mapp B7O14L matches 13 run summon rabbit "§d" 38 227 99
execute if score mapp B7O14L matches 13 run summon rabbit "§d" 102 227 163
execute if score mapp B7O14L matches 14 run summon rabbit "§d" 87 228 35
execute if score mapp B7O14L matches 14 run summon rabbit "§d" 168 228 86
execute if score mapp B7O14L matches 14 run summon rabbit "§d" 36 228 116
execute if score mapp B7O14L matches 14 run summon rabbit "§d" 117 228 167
execute if score mapp B7O14L matches 15 run summon rabbit "§d" 27 230 98
execute if score mapp B7O14L matches 15 run summon rabbit "§d" 98 230 27
execute if score mapp B7O14L matches 15 run summon rabbit "§d" 98 230 169
execute if score mapp B7O14L matches 15 run summon rabbit "§d" 169 230 98
execute if score mapp B7O14L matches 16 run summon rabbit "§d" 40 235 103
execute if score mapp B7O14L matches 16 run summon rabbit "§d" 103 235 40
execute if score mapp B7O14L matches 16 run summon rabbit "§d" 103 235 166
execute if score mapp B7O14L matches 16 run summon rabbit "§d" 166 235 103
execute if score mapp B7O14L matches 17 run summon rabbit "§d" 101 234 40
execute if score mapp B7O14L matches 17 run summon rabbit "§d" 167 234 106
execute if score mapp B7O14L matches 17 run summon rabbit "§d" 35 234 106
execute if score mapp B7O14L matches 17 run summon rabbit "§d" 101 234 172
execute if score mapp B7O14L matches 18 run summon rabbit "§d" 107 243 29
execute if score mapp B7O14L matches 18 run summon rabbit "§d" 182 243 104
execute if score mapp B7O14L matches 18 run summon rabbit "§d" 32 243 104
execute if score mapp B7O14L matches 18 run summon rabbit "§d" 107 243 179
execute if score mapp B7O14L matches 19 run summon rabbit "§d" 111 232 45
execute if score mapp B7O14L matches 19 run summon rabbit "§d" 170 232 104
execute if score mapp B7O14L matches 19 run summon rabbit "§d" 52 232 104
execute if score mapp B7O14L matches 19 run summon rabbit "§d" 111 232 162
execute if score mapp B7O14L matches 20 run summon rabbit "§d" 160 236 106
execute if score mapp B7O14L matches 20 run summon rabbit "§d" 105 236 161
execute if score mapp B7O14L matches 20 run summon rabbit "§d" 105 236 51
execute if score mapp B7O14L matches 20 run summon rabbit "§d" 50 236 106
execute if score mapp B7O14L matches 21 run summon rabbit "§d" 110 233 181
execute if score mapp B7O14L matches 21 run summon rabbit "§d" 42 233 113
execute if score mapp B7O14L matches 21 run summon rabbit "§d" 178 233 113
execute if score mapp B7O14L matches 21 run summon rabbit "§d" 110 233 45
execute if score mapp B7O14L matches 22 run summon rabbit "§d" 149 233 56
execute if score mapp B7O14L matches 22 run summon rabbit "§d" 149 233 156
execute if score mapp B7O14L matches 22 run summon rabbit "§d" 67 233 56
execute if score mapp B7O14L matches 22 run summon rabbit "§d" 67 233 156
execute if score mapp B7O14L matches 23 run summon rabbit "§d" 169 236 106
execute if score mapp B7O14L matches 23 run summon rabbit "§d" 31 236 106
execute if score mapp B7O14L matches 23 run summon rabbit "§d" 100 236 37
execute if score mapp B7O14L matches 23 run summon rabbit "§d" 100 236 175
execute if score mapp B7O14L matches 24 run summon rabbit "§d" 107 236 32
execute if score mapp B7O14L matches 24 run summon rabbit "§d" 175 236 100
execute if score mapp B7O14L matches 24 run summon rabbit "§d" 39 236 100
execute if score mapp B7O14L matches 24 run summon rabbit "§d" 107 236 168
execute if score mapp B7O14L matches 25 run summon rabbit "§d" 103 232 38
execute if score mapp B7O14L matches 25 run summon rabbit "§d" 171 232 106
execute if score mapp B7O14L matches 25 run summon rabbit "§d" 35 232 106
execute if score mapp B7O14L matches 25 run summon rabbit "§d" 103 232 174
execute if score mapp B7O14L matches 26 run summon rabbit "§d" 104 235 26
execute if score mapp B7O14L matches 26 run summon rabbit "§d" 183 235 103
execute if score mapp B7O14L matches 26 run summon rabbit "§d" 27 235 105
execute if score mapp B7O14L matches 26 run summon rabbit "§d" 106 235 182
execute if score mapp B7O14L matches 27 run summon rabbit "§d" 131 233 59
execute if score mapp B7O14L matches 27 run summon rabbit "§d" 147 233 139
execute if score mapp B7O14L matches 27 run summon rabbit "§d" 51 233 75
execute if score mapp B7O14L matches 27 run summon rabbit "§d" 67 233 155



# exe实体进行清除

# -清木板
execute unless score mode O8P02W matches 1 as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace oak_planks

# -清羊毛
execute unless score mode O8P02W matches 1 as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace minecrafts:red_wool
execute unless score mode O8P02W matches 1 as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace minecrafts:lime_wool
execute unless score mode O8P02W matches 1 as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace minecrafts:blue_wool
execute unless score mode O8P02W matches 1 as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace minecrafts:yellow_wool

execute if score mode O8P02W matches 1 as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 end_stone 0 replace minecrafts:red_wool
execute if score mode O8P02W matches 1 as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 end_stone 0 replace minecrafts:lime_wool
execute if score mode O8P02W matches 1 as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 end_stone 0 replace minecrafts:blue_wool
execute if score mode O8P02W matches 1 as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 end_stone 0 replace minecrafts:yellow_wool

# -清玻璃
execute as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace red_stained_glass
execute as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace blue_stained_glass
execute as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace lime_stained_glass
execute as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace yellow_stained_glass

# - reset tags
execute unless score mode O8P02W matches 2 run tag @a remove fastbuild

# 闭环
kill @e[type=rabbit,name="§d"]
