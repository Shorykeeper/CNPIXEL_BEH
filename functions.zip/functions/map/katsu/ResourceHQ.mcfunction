# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 106 233 13
summon bedwars:text "§b" 200 232 103
summon bedwars:text "§b" 12 232 103
summon bedwars:text "§b" 106 232 197

