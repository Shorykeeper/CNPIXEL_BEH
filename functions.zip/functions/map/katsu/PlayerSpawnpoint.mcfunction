# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 106 232 9
spawnpoint @s[scores={A1T12P=2}] 196 233 103
spawnpoint @s[scores={A1T12P=3}] 16 233 103
spawnpoint @s[scores={A1T12P=4}] 106 233 193
