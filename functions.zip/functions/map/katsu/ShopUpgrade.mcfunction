# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 100 234 18

summon template:npc 191 234 97
summon template:npc 21 234 109
summon template:npc 112 234 188