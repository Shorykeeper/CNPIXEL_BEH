# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 145 238 55
tp @s[scores={A1T12P=2}] 151 238 153
tp @s[scores={A1T12P=3}] 47 238 61
tp @s[scores={A1T12P=4}] 53 238 159
