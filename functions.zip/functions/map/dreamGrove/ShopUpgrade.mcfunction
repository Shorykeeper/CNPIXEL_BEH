# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 141 238 46

summon template:npc 160 238 149
summon template:npc 38 238 65
summon template:npc 57 238 168