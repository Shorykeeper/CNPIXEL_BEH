# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 106 234 166
summon minecrafts:diamond_spawner "" 158 234 100
summon minecrafts:diamond_spawner "" 92 234 48
summon minecrafts:diamond_spawner "" 40 234 114
