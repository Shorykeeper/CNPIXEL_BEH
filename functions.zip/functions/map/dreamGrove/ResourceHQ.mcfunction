# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 147 237 49
summon bedwars:text "§b" 157 237 155
summon bedwars:text "§b" 41 237 59
summon bedwars:text "§b" 51 237 165

