# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 150 238 57


summon template:npc 149 238 158
summon template:npc 49 238 56
summon template:npc 48 238 157