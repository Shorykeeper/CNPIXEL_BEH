# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 99 234 107
summon minecrafts:emerald_spawner "" 99 246 107
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
