# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 113 231 24


summon template:npc 184 231 109
summon template:npc 28 231 95
summon template:npc 113 231 180