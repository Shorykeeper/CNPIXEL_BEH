# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
