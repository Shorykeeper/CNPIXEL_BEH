# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 106 231 25
tp @s[scores={A1T12P=2}] 183 231 102
tp @s[scores={A1T12P=3}] 29 231 102
tp @s[scores={A1T12P=4}] 106 231 179
