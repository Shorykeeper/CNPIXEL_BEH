# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 106 230 20
summon bedwars:text "§b" 188 230 102
summon bedwars:text "§b" 24 230 102
summon bedwars:text "§b" 106 230 184

