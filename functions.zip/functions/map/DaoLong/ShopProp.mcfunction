# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 105 229 23


summon template:npc 23 229 95
summon template:npc 95 229 177