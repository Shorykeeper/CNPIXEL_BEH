# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 100 228 19
tp @s[scores={A1T12P=2}] 19 228 100
#tp @s[scores={A1T12P=3}] 
tp @s[scores={A1T12P=4}] 100 228 181
