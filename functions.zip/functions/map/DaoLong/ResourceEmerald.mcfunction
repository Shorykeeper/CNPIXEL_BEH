# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:emerald_spawner "" 100 237 100
summon minecrafts:emerald_spawner "" 100 226 100
#summon minecrafts:diamond_spawner "" 
#summon minecrafts:diamond_spawner "" 
