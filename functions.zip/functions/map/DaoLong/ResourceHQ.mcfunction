# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 100 227 13
summon bedwars:text "§b" 13 227 100
#summon bedwars:text "§b"
summon bedwars:text "§b" 100 227 187

