# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 100 228 19
spawnpoint @s[scores={A1T12P=2}] 19 228 100
#spawnpoint @s[scores={A1T12P=3}] 
spawnpoint @s[scores={A1T12P=4}] 100 228 181
