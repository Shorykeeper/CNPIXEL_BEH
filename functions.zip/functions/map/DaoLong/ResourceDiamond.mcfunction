# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon minecrafts:diamond_spawner "" 60 234 140
summon minecrafts:diamond_spawner "" 60 234 60
summon minecrafts:diamond_spawner "" 140 234 60
summon minecrafts:diamond_spawner "" 140 234 140
