# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon bedwars:text "§b" 176 237 106
summon bedwars:text "§b" 105 237 177
summon bedwars:text "§b" 105 237 35
summon bedwars:text "§b" 34 237 106

