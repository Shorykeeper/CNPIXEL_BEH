# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

tp @s[scores={A1T12P=1}] 170 238 106
tp @s[scores={A1T12P=2}] 105 238 171
tp @s[scores={A1T12P=3}] 105 238 41
tp @s[scores={A1T12P=4}] 40 238 106
