# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 175 238 102

summon template:npc 109 238 176
summon template:npc 101 238 36
summon template:npc 35 238 110