# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

summon template:npc 175 238 112


summon template:npc 99 238 176
summon template:npc 111 238 36
summon template:npc 35 238 100