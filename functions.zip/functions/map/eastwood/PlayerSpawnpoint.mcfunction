# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/18

spawnpoint @s[scores={A1T12P=1}] 170 238 106
spawnpoint @s[scores={A1T12P=2}] 105 238 171
spawnpoint @s[scores={A1T12P=3}] 105 238 41
spawnpoint @s[scores={A1T12P=4}] 40 238 106
