# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 总启驱动


## 计算房间总人数
function control/rs

## 战斗功能
execute if score start B7O14L matches 2 run function system/fighting

## 执行主城功能
function system/lobby/lobbyMain

## 计算开局条件
execute unless score start B7O14L matches 2.. run function system/start/attempt

## 若成功倒计时则循环倒计时系统检测
execute if score start B7O14L matches 1 run function system/start/main





