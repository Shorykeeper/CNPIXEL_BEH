

scoreboard players set @e[name="§a✔"] D1W04T 0

tag @e[tag=rtbeds] remove rtbeds
tag @e[name="§c✘"] add rtbeds

