

scoreboard players set @e[name="§a1"] D1W04T 0

tag @e[tag=btbeds] remove btbeds
tag @e[name="§c✘"] add btbeds

