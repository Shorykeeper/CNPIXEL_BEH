

scoreboard players set @e[name="§a2"] D1W04T 0

tag @e[tag=gtbeds] remove gtbeds
tag @e[name="§c✘"] add gtbeds

