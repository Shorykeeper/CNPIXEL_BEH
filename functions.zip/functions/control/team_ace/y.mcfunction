

scoreboard players set @e[name="§c✘"] D1W04T 0

tag @e[tag=ytbeds] remove ytbeds
tag @e[name="§c✘"] add ytbeds

