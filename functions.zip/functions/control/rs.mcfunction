# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 总人数计算

#  计算本房间所有人人数
scoreboard players set rs D1W04T 0
execute as @a run scoreboard players add rs D1W04T 1



