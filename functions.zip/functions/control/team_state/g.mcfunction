

# ==================================================
# 绿队逻辑 (Green Team)
# 使用分数: grs | 标签: gtbeds | 控制对象: §a1-§a5
# ==================================================

# 绿队 5
execute if score grs D1W04T matches 5 if entity @e[name=!§a5,tag=gtbeds] run tag @e[name=!§a5,tag=gtbeds] remove gtbeds
execute if entity @e[name=§a5,tag=!gtbeds] if score grs D1W04T matches 5 run tag @e[name=§a5] add gtbeds

# 绿队 4
execute if score grs D1W04T matches 4 if entity @e[name=!§a4,tag=gtbeds] run tag @e[name=!§a4,tag=gtbeds] remove gtbeds
execute if entity @e[name=§a4,tag=!gtbeds] if score grs D1W04T matches 4 run tag @e[name=§a4] add gtbeds

# 绿队 3
execute if score grs D1W04T matches 3 if entity @e[name=!§a3,tag=gtbeds] run tag @e[name=!§a3,tag=gtbeds] remove gtbeds
execute if entity @e[name=§a3,tag=!gtbeds] if score grs D1W04T matches 3 run tag @e[name=§a3] add gtbeds

# 绿队 2
execute if score grs D1W04T matches 2 if entity @e[name=!§a2,tag=gtbeds] run tag @e[name=!§a2,tag=gtbeds] remove gtbeds
execute if entity @e[name=§a2,tag=!gtbeds] if score grs D1W04T matches 2 run tag @e[name=§a2] add gtbeds

# 绿队 1
execute if score grs D1W04T matches 1 run tag @e[name=!§a1,tag=gtbeds] remove gtbeds
execute if entity @e[name=§a1,tag=!gtbeds] if score grs D1W04T matches 1 run tag @e[name=§a1] add gtbeds

