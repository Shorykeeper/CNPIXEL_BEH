

# ==================================================
# 黄队逻辑 (Yellow Team)
# 使用分数: yrs | 标签: ytbeds | 控制对象: §a1-§a5
# ==================================================

# 黄队 5
execute if score yrs D1W04T matches 5 if entity @e[name=!§a5,tag=ytbeds] run tag @e[name=!§a5,tag=ytbeds] remove ytbeds
execute if entity @e[name=§a5,tag=!ytbeds] if score yrs D1W04T matches 5 run tag @e[name=§a5] add ytbeds

# 黄队 4
execute if score yrs D1W04T matches 4 if entity @e[name=!§a4,tag=ytbeds] run tag @e[name=!§a4,tag=ytbeds] remove ytbeds
execute if entity @e[name=§a4,tag=!ytbeds] if score yrs D1W04T matches 4 run tag @e[name=§a4] add ytbeds

# 黄队 3
execute if score yrs D1W04T matches 3 if entity @e[name=!§a3,tag=ytbeds] run tag @e[name=!§a3,tag=ytbeds] remove ytbeds
execute if entity @e[name=§a3,tag=!ytbeds] if score yrs D1W04T matches 3 run tag @e[name=§a3] add ytbeds

# 黄队 2
execute if score yrs D1W04T matches 2 if entity @e[name=!§a2,tag=ytbeds] run tag @e[name=!§a2,tag=ytbeds] remove ytbeds
execute if entity @e[name=§a2,tag=!ytbeds] if score yrs D1W04T matches 2 run tag @e[name=§a2] add ytbeds

# 黄队 1
execute if score yrs D1W04T matches 1 run tag @e[name=!§a1,tag=ytbeds] remove ytbeds
execute if entity @e[name=§a1,tag=!ytbeds] if score yrs D1W04T matches 1 run tag @e[name=§a1] add ytbeds

