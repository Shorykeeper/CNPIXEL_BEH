# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 计算对局人数
# @TeamCode: 1R 2B 3G 4Y

#  计算四队人数
#  注意 这里仅专门计算队伍人数 运算处理结果在ace那
scoreboard players set rrs D1W04T 0
execute as @a[scores={A1T12P=1}] at @s run scoreboard players add rrs D1W04T 1

scoreboard players set grs D1W04T 0
execute as @a[scores={A1T12P=4}] at @s run scoreboard players add grs D1W04T 1

scoreboard players set yrs D1W04T 0
execute as @a[scores={A1T12P=3}] at @s run scoreboard players add yrs D1W04T 1

scoreboard players set brs D1W04T 0
execute as @a[scores={A1T12P=2}] at @s run scoreboard players add brs D1W04T 1

#  无床计分板显示队伍人数:
#  当无床且人数大等一才计分板显示队伍人数
#  有床不用计算只显示勾 为零是unless管故这不用计算
execute if entity @r[tag=无床,scores={A1T12P=1}] if score rrs D1W04T matches 1.. if entity @e[name="§a✔",tag=canace] run function control/team_state/r
execute if entity @r[tag=无床,scores={A1T12P=3}] if score grs D1W04T matches 1.. if entity @e[name="§a2",tag=canace] run function control/team_state/g
execute if entity @r[tag=无床,scores={A1T12P=2}] if score brs D1W04T matches 1.. if entity @e[name="§a1",tag=canace] run function control/team_state/b
execute if entity @r[tag=无床,scores={A1T12P=4}] if score yrs D1W04T matches 1.. if entity @e[name="§c✘",tag=canace] run function control/team_state/y
