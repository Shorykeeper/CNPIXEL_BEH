# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 后台自动计算队伍存活/结算
# @TeamCode: 1R 2B 3G 4Y


#  可显示团灭文本机会 tag = canace
#  空人队计分板条件 直接执行
execute if score rrs D1W04T matches 0 if entity @e[name="§a✔",tag=canace] run function system/end/elimshow/red
execute if score rrs D1W04T matches 0 if entity @e[name="§a✔",tag=canace] run tag @e[name="§a✔",tag=canace] remove canace

execute if score grs D1W04T matches 0 if entity @e[name="§a2",tag=canace] run function system/end/elimshow/green
execute if score grs D1W04T matches 0 if entity @e[name="§a2",tag=canace] run tag @e[name="§a2",tag=canace] remove canace

execute if score brs D1W04T matches 0 if entity @e[name="§a1",tag=canace] run function system/end/elimshow/blue
execute if score brs D1W04T matches 0 if entity @e[name="§a1",tag=canace] run tag @e[name="§a1",tag=canace] remove canace

execute if score yrs D1W04T matches 0 if entity @e[name="§c✘",tag=canace] run function system/end/elimshow/yellow
execute if score yrs D1W04T matches 0 if entity @e[name="§c✘",tag=canace] run tag @e[name="§c✘",tag=canace] remove canace


#  以下计算剩余队伍(已团灭数思路) 进行胜利判定
#  直接Unless计算 
#  Warning : NPC的代分数 必须在结束的时候清除 
execute unless entity @a[scores={A1T12P=1}] if score start B7O14L matches 2 run function system/end/team_ace/r
execute unless entity @a[scores={A1T12P=2}] if score start B7O14L matches 2 run function system/end/team_ace/b
execute unless entity @a[scores={A1T12P=3}] if score start B7O14L matches 2 run function system/end/team_ace/y
execute unless entity @a[scores={A1T12P=4}] if score start B7O14L matches 2 run function system/end/team_ace/g


#  再次计算NPC载体分数为0的数量
scoreboard players set allt D1W04T 0
execute if score start B7O14L matches 2 as @e[type=armor_stand,scores={D1W04T=0}] run scoreboard players add allt D1W04T 1


#  已团灭队伍分数结果为三 == 若无人空队数为三 即为三队出局 剩下一队便是胜利队伍
execute if entity @e[name="comp",tag=canend] if score allt D1W04T matches 3 run function system/end/win
execute if entity @e[name="comp",tag=canend] if score allt D1W04T matches 3 run tag @e[name="comp",tag=canend] remove canend

