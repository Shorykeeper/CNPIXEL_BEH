function global_


