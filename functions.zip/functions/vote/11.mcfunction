# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/14

summon armor_stand "胜津城" -64 -60 1010
tag @e[type=armor_stand,name=胜津城,x=-64,y=-60,z=1010,r=2,c=1] add 选中
scoreboard players set mapp B7O14L 11