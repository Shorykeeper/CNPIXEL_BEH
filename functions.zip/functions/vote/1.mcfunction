# Coding = UTF-8
# by Shorykeeper 
# CreateTime: 26/6/13

summon armor_stand "潮起亚细亚" -64 -60 1010
tag @e[type=armor_stand,name=潮起亚细亚,x=-64,y=-60,z=1010,r=2,c=1] add 选中
scoreboard players set mapp B7O14L 1

