scoreboard objectives add vote dummy
scoreboard players random rand vote 1 27
execute if score rand vote matches 1 run function vote/1
execute if score rand vote matches 2 run function vote/2
execute if score rand vote matches 3 run function vote/3
execute if score rand vote matches 4 run function vote/4
execute if score rand vote matches 5 run function vote/5
execute if score rand vote matches 6 run function vote/6
execute if score rand vote matches 7 run function vote/7
execute if score rand vote matches 8 run function vote/8
execute if score rand vote matches 9 run function vote/9
execute if score rand vote matches 10 run function vote/10
execute if score rand vote matches 11 run function vote/11
execute if score rand vote matches 12 run function vote/12
execute if score rand vote matches 13 run function vote/13
execute if score rand vote matches 14 run function vote/14
execute if score rand vote matches 15 run function vote/15
execute if score rand vote matches 16 run function vote/16
execute if score rand vote matches 17 run function vote/17
execute if score rand vote matches 18 run function vote/18
execute if score rand vote matches 19 run function vote/19
execute if score rand vote matches 20 run function vote/20
execute if score rand vote matches 21 run function vote/21
execute if score rand vote matches 22 run function vote/22
execute if score rand vote matches 23 run function vote/23
execute if score rand vote matches 24 run function vote/24
execute if score rand vote matches 25 run function vote/25
execute if score rand vote matches 26 run function vote/26
execute if score rand vote matches 27 run function vote/27
scoreboard objectives remove vote