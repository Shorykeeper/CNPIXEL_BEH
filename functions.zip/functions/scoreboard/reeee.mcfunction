

scoreboard objectives add U2C44V dummy
scoreboard objectives add T8R43H dummy
scoreboard objectives add V5G28k dummy
scoreboard objectives add C4D31J dummy
scoreboard objectives add S0F06V dummy
scoreboard objectives add Q0A59I dummy
scoreboard objectives add E1B36G dummy
scoreboard objectives add G7C23S dummy
scoreboard objectives add Y5T96B dummy
scoreboard objectives add V3P49H dummy
scoreboard objectives add S8Q83P dummy
scoreboard objectives add D2K48A dummy
scoreboard objectives add K8T78F dummy
scoreboard objectives add A1T12P dummy



scoreboard objectives add O3G30Q dummy
scoreboard objectives add G2L41J dummy
scoreboard objectives add R4DO6T dummy
scoreboard objectives add F5J47Z dummy
scoreboard objectives add U9Y72H dummy
scoreboard objectives add W4G21E dummy
scoreboard objectives add A4Q23U dummy
scoreboard objectives add M3F75C dummy
scoreboard objectives add D1W04T dummy
scoreboard objectives add T2R10A dummy
scoreboard objectives add I0S08X dummy
scoreboard objectives add X2C07R dummy
scoreboard objectives add B7O14L dummy
scoreboard objectives add S2P10K dummy
scoreboard objectives add O8P02W dummy
scoreboard objectives add F3Q58B dummy
scoreboard objectives add I3P77O dummy
scoreboard objectives add G6Y81S dummy
scoreboard objectives add Z4T27M dummy
scoreboard objectives add D9T95M dummy
scoreboard objectives add N5L93G dummy
scoreboard objectives add H8F72J dummy
scoreboard objectives add D9W45S dummy
scoreboard objectives add L2R37T dummy
scoreboard objectives add C1T28Q dummy
scoreboard objectives add Y9V88N dummy
scoreboard objectives add A1B23C dummy
scoreboard objectives add X5T99R dummy
scoreboard objectives add Q7M04P dummy
scoreboard objectives add Z3K56L dummy
scoreboard objectives add T8R43H dummy
scoreboard objectives add V5G28k dummy
scoreboard objectives add C4D31J dummy
scoreboard objectives add S0F06V dummy
scoreboard objectives add Q0A59I dummy
scoreboard objectives add E1B36G dummy
scoreboard objectives add G7C23S dummy
scoreboard objectives add K4W93O dummy
scoreboard objectives add Y5T96B dummy
scoreboard objectives add S8Q83P dummy
scoreboard objectives add G6Y81U dummy
scoreboard objectives add P4J90M dummy
scoreboard objectives add E3Q28N dummy




# 天梯
scoreboard objectives add T4T32T dummy

scoreboard objectives add M3F75C dummy
scoreboard objectives add D1W04T dummy

