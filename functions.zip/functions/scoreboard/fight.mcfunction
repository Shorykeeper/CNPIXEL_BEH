# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 显示战斗数据板

# 中文
#红#
execute as @a[scores={A1T12P=1},tag=inf] run titleraw @s actionbar {"rawtext":[{"text":"§e§l       起床战争\n"},{"text":"§r§726/7/2 Anniversary\n\n§f"},{"selector":"@e[tag=语言事件]"},{"text":"§f - §a"},{"score":{"name":"sjm2","objective":"D9T95M"}},{"score":{"name":"sjm1","objective":"D9T95M"}},{"text":":"},{"score":{"name":"sjs2","objective":"D9T95M"}},{"score":{"name":"sjs1","objective":"D9T95M"}},{"text":"\n\n§c§l红§r§f 红队: "},{"selector":"@e[tag=rtbeds]"},{"text":"§7 (你)\n§9§l蓝§r§f 蓝队: "},{"selector":"@e[tag=btbeds]"},{"text":"\n§e§l黄§r§f 黄队: "},{"selector":"@e[tag=ytbeds]"},{"text":"\n§a§l绿§r§f 绿队: "},{"selector":"@e[tag=gtbeds]"},{"text":"\n\n§f击杀数: §a"},{"score":{"name":"@s","objective":"O3G30Q"}},{"text":"\n§f最终击杀数: §a"},{"score":{"name":"@s","objective":"G2L41J"}},{"text":"\n§f破坏床数: §a"},{"score":{"name":"@s","objective":"R4DO6T"}},{"text":"\n\n§eCNPIXEL"}]}
#蓝#
execute as @a[scores={A1T12P=2},tag=inf] run titleraw @s actionbar {"rawtext":[{"text":"§e§l       起床战争\n"},{"text":"§r§726/7/2 Anniversary\n\n§f"},{"selector":"@e[tag=语言事件]"},{"text":"§f - §a"},{"score":{"name":"sjm2","objective":"D9T95M"}},{"score":{"name":"sjm1","objective":"D9T95M"}},{"text":":"},{"score":{"name":"sjs2","objective":"D9T95M"}},{"score":{"name":"sjs1","objective":"D9T95M"}},{"text":"\n\n§c§l红§r§f 红队: "},{"selector":"@e[tag=rtbeds]"},{"text":"\n§9§l蓝§r§f 蓝队: "},{"selector":"@e[tag=btbeds]"},{"text":"§7 (你)\n§e§l黄§r§f 黄队: "},{"selector":"@e[tag=ytbeds]"},{"text":"\n§a§l绿§r§f 绿队: "},{"selector":"@e[tag=gtbeds]"},{"text":"\n\n§f击杀数: §a"},{"score":{"name":"@s","objective":"O3G30Q"}},{"text":"\n§f最终击杀数: §a"},{"score":{"name":"@s","objective":"G2L41J"}},{"text":"\n§f破坏床数: §a"},{"score":{"name":"@s","objective":"R4DO6T"}},{"text":"\n\n§eCNPIXEL"}]}
#黄#
execute as @a[scores={A1T12P=3},tag=inf] run titleraw @s actionbar {"rawtext":[{"text":"§e§l       起床战争\n"},{"text":"§r§726/7/2 Anniversary\n\n§f"},{"selector":"@e[tag=语言事件]"},{"text":"§f - §a"},{"score":{"name":"sjm2","objective":"D9T95M"}},{"score":{"name":"sjm1","objective":"D9T95M"}},{"text":":"},{"score":{"name":"sjs2","objective":"D9T95M"}},{"score":{"name":"sjs1","objective":"D9T95M"}},{"text":"\n\n§c§l红§r§f 红队: "},{"selector":"@e[tag=rtbeds]"},{"text":"\n§9§l蓝§r§f 蓝队: "},{"selector":"@e[tag=btbeds]"},{"text":"\n§e§l黄§r§f 黄队: "},{"selector":"@e[tag=ytbeds]"},{"text":"§7 (你)\n§a§l绿§r§f 绿队: "},{"selector":"@e[tag=gtbeds]"},{"text":"\n\n§f击杀数: §a"},{"score":{"name":"@s","objective":"O3G30Q"}},{"text":"\n§f最终击杀数: §a"},{"score":{"name":"@s","objective":"G2L41J"}},{"text":"\n§f破坏床数: §a"},{"score":{"name":"@s","objective":"R4DO6T"}},{"text":"\n\n§eCNPIXEL"}]}
#绿#
execute as @a[scores={A1T12P=4},tag=inf] run titleraw @s actionbar {"rawtext":[{"text":"§e§l       起床战争\n"},{"text":"§r§726/7/2 Anniversary\n\n§f"},{"selector":"@e[tag=语言事件]"},{"text":"§f - §a"},{"score":{"name":"sjm2","objective":"D9T95M"}},{"score":{"name":"sjm1","objective":"D9T95M"}},{"text":":"},{"score":{"name":"sjs2","objective":"D9T95M"}},{"score":{"name":"sjs1","objective":"D9T95M"}},{"text":"\n\n§c§l红§r§f 红队: "},{"selector":"@e[tag=rtbeds]"},{"text":"\n§9§l蓝§r§f 蓝队: "},{"selector":"@e[tag=btbeds]"},{"text":"\n§e§l黄§r§f 黄队: "},{"selector":"@e[tag=ytbeds]"},{"text":"\n§a§l绿§r§f 绿队: "},{"selector":"@e[tag=gtbeds]"},{"text":"§7 (你)\n\n§f击杀数: §a"},{"score":{"name":"@s","objective":"O3G30Q"}},{"text":"\n§f最终击杀数: §a"},{"score":{"name":"@s","objective":"G2L41J"}},{"text":"\n§f破坏床数: §a"},{"score":{"name":"@s","objective":"R4DO6T"}},{"text":"\n\n§eCNPIXEL"}]}



#场外但观战
execute as @a[m=spectator,tag=观战,tag=!inf] at @s run titleraw @s actionbar {"rawtext":[{"text":"§e§l       起床战争\n"},{"text":"§r§726/7/2 Anniversary\n\n§f"},{"selector":"@e[tag=语言事件]"},{"text":"§f - §a"},{"score":{"name":"sjm2","objective":"D9T95M"}},{"score":{"name":"sjm1","objective":"D9T95M"}},{"text":":"},{"score":{"name":"sjs2","objective":"D9T95M"}},{"score":{"name":"sjs1","objective":"D9T95M"}},{"text":"\n\n§c§l红§r§f 红队: "},{"selector":"@e[tag=rtbeds]"},{"text":"\n§9§l蓝§r§f 蓝队: "},{"selector":"@e[tag=btbeds]"},{"text":"\n§e§l黄§r§f 黄队: "},{"selector":"@e[tag=ytbeds]"},{"text":"\n§a§l绿§r§f 绿队: "},{"selector":"@e[tag=gtbeds]"},{"text":"§7\n\n§f你现在是一名旁观者\n\n§eCNPIXEL 1st"}]}


#纯场外 交给lobby
execute as @a[tag=!inf,tag=!观战] run function scoreboard/lobby




