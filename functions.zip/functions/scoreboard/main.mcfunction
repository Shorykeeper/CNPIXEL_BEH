# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ ShoreKeep ]
# @Function : 显示计分板

execute if score start B7O14L matches -1 run function scoreboard/lobby

execute if score start B7O14L matches 0 run function scoreboard/lobby

execute if score start B7O14L matches 1 run function scoreboard/wait

execute if score start B7O14L matches 2.. run function scoreboard/fight



