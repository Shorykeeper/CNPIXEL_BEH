# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ ShoreKeep ]
# @Function : 显示倒计时计分板

#倒计时计分板不涉及针对@s的个人数据 不exe

#中
titleraw @a[tag=!inf] actionbar {"rawtext":[{"text":"      §e§l起床战争§r\n"},{"text":"§726/4/26 v1.68[Beta]"},{"text":"\n\n§f地图: §a"},{"selector":"@e[x=-8,y=-60,z=1058,r=1,type=armor_stand,c=1]"},{"text":"\n§f人数: §a"},{"score":{"objective":"D1W04T","name":"rs"}},{"text":"/8"},{"text":"\n\n§f即将开始: §a"},{"score":{"objective":"M3F75C","name":"count"}},{"text":"\n\n§f模式: §a2v2v2v2\n§f版本: §7v1.68 §e\n\n§o§l§d§oBon§u Voyage!"}]}
