

function scoreboard/main



