# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]

scoreboard players reset @s FlyVl
scoreboard players reset @s A2S33B
scoreboard players reset @s Tspeed


tag @s[tag=!wtf,tag=!banned] add 封禁


say §c被 §f[Server] §c检测为高危对象!

