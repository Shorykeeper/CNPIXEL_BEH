# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]

execute as @a[tag=!banned] run camera @a fade time 0.1 5.1 0.1 color 235 86 75

title @a times 0 100 0

execute as @a[tag=!banned] run titleraw @a title {"rawtext":[{"text":"§l§bAur§fora\n§r§f检测到作弊者"}]}
execute as @a[tag=!banned] run titleraw @a subtitle {"rawtext":[{"text":"§f感谢你的举报\n作弊者已受到系统惩罚,游戏取消则所有玩家的输赢均不计入"}]}

