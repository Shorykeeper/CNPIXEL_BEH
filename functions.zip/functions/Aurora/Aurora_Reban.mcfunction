# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 解封

tag @s remove banned

clear @s

tag @s add 清除

function allgames/join/clean_data

scoreboard players reset @s ac.fly.time
scoreboard players reset @s FlyVl


titleraw @s[tag=语言] title {"rawtext":[{"translate":"aurora.cnp.reban.title"}]}
titleraw @s[tag=语言] subtitle {"rawtext":[{"translate":"aurora.cnp.reban.subtitle"}]}


title @s[tag=language] title {"rawtext":[{"translate":"aaurora.hyp.reban.title"}]}
title @s[tag=language] subtitle {"rawtext":[{"translate":"aaurora.hyp.reban.subtitle"}]}

tellraw @s {"rawtext":[{"translate":"CNPIXEL.name.starting"}]}
tellraw @s[tag=language] {"rawtext":[{"translate":"aurora.hyp.reban.msg"}]}
tellraw @s[tag=语言] {"rawtext":[{"translate":"aurora.cnp.reban.msg"}]}

tp @s 73 186 1824

spawnpoint @s 73 186 1824

