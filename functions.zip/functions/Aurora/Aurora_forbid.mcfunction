
gamemode 2 @a[tag=banned,m=!2]

camera @a[tag=banned] fade time 0.1 2.5 1 color 235 86 75

tp @a[tag=banned] 73 183 1824

title @a[tag=banned] title §d§l账号状态异常!
title @a[tag=banned] subtitle §7§l这可能是一次误判,若有异议可申诉此封禁

effect @a[tag=banned] instant_health 0 0 true
