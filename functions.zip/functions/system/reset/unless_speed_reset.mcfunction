# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 不是疾速模式清除疾速保护
# 在游戏开始倒计时的时候执行一次

# 先给对应使用地图的床生成一个计算实体
# Game In Need: 游戏母图需要提前围上床保护
# 被- 是则不执行 不是则清除.
# === 地图 1: Unturned ===
execute if score mapp F3Q58B = num_1 B7O14L run summon rabbit "§d" 105 277 27
execute if score mapp F3Q58B = num_1 B7O14L run summon rabbit "§d" 183 277 105
execute if score mapp F3Q58B = num_1 B7O14L run summon rabbit "§d" 105 277 183
execute if score mapp F3Q58B = num_1 B7O14L run summon rabbit "§d" 27 277 105

# === 地图 2: Pool Party ===
execute if score mapp F3Q58B = num_2 B7O14L run summon rabbit "§d" 22 274 100
execute if score mapp F3Q58B = num_2 B7O14L run summon rabbit "§d" 106 274 22
execute if score mapp F3Q58B = num_2 B7O14L run summon rabbit "§d" 184 274 106
execute if score mapp F3Q58B = num_2 B7O14L run summon rabbit "§d" 100 274 184


# === 地图 3: Katsu ===
execute if score mapp F3Q58B = num_3 B7O14L run summon rabbit "§d" 98 270 24
execute if score mapp F3Q58B = num_3 B7O14L run summon rabbit "§d" 172 270 98
execute if score mapp F3Q58B = num_3 B7O14L run summon rabbit "§d" 98 270 172
execute if score mapp F3Q58B = num_3 B7O14L run summon rabbit "§d" 24 270 98

# === 地图 4: Garden ===
execute if score mapp F3Q58B = num_4 B7O14L run summon rabbit "§d" 39 274 103
execute if score mapp F3Q58B = num_4 B7O14L run summon rabbit "§d" 104 274 35
execute if score mapp F3Q58B = num_4 B7O14L run summon rabbit "§d" 165 274 103
execute if score mapp F3Q58B = num_4 B7O14L run summon rabbit "§d" 104 274 171

# === 地图 5: Graveship ===
execute if score mapp F3Q58B = num_5 B7O14L run summon rabbit "§d" 167 276 90
execute if score mapp F3Q58B = num_5 B7O14L run summon rabbit "§d" 86 276 171
execute if score mapp F3Q58B = num_5 B7O14L run summon rabbit "§d" 33 276 119
execute if score mapp F3Q58B = num_5 B7O14L run summon rabbit "§d" 114 276 37

# === 地图 6: Chained === 
execute if score mapp F3Q58B = num_6 B7O14L run summon rabbit "§d" 103 278 34
execute if score mapp F3Q58B = num_6 B7O14L run summon rabbit "§d" 172 278 103
execute if score mapp F3Q58B = num_6 B7O14L run summon rabbit "§d" 103 278 172
execute if score mapp F3Q58B = num_6 B7O14L run summon rabbit "§d" 34 278 103


# exe实体进行清除 (由AerMini提供的思路)
# -清木板
execute unless score mode O8P02W = num_1 B7O14L as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace oak_planks

# -清羊毛
execute unless score mode O8P02W = num_1 B7O14L as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace red_wool
execute unless score mode O8P02W = num_1 B7O14L as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace lime_wool
execute unless score mode O8P02W = num_1 B7O14L as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace blue_wool
execute unless score mode O8P02W = num_1 B7O14L as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace yellow_wool

execute if score mode O8P02W = num_1 B7O14L as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 end_stone 0 replace red_wool
execute if score mode O8P02W = num_1 B7O14L as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 end_stone 0 replace lime_wool
execute if score mode O8P02W = num_1 B7O14L as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 end_stone 0 replace blue_wool
execute if score mode O8P02W = num_1 B7O14L as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 end_stone 0 replace yellow_wool

# -清玻璃
execute as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace red_stained_glass
execute as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace blue_stained_glass
execute as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace lime_stained_glass
execute as @e[type=rabbit,name="§d"] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 air 0 replace yellow_stained_glass

# - reset tags
tag @a remove fastbuild

# 闭环
kill @e[type=rabbit,name="§d"]



