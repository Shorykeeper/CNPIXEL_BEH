

playsound random.orb @a

titleraw @a[tag=语言] title {"rawtext":[{"translate":"style.cnp.reset_over.title"}]}
titleraw @a[tag=语言] subtitle {"rawtext":[{"translate":"style.cnp.reset_over.subtitle"}]}

titleraw @a[tag=language] title {"rawtext":[{"translate":"style.hyp.reset_over.title"}]}
titleraw @a[tag=language] subtitle {"rawtext":[{"translate":"style.hyp.reset_over.subtitle"}]}

tellraw @a[tag=语言] {"rawtext":[{"translate":"style.cnp.reset_over.msg"}]}
tellraw @a[tag=language] {"rawtext":[{"translate":"style.hyp.reset_over.msg"}]}


scoreboard players set start B7O14L 0

tag @a remove canmap

