# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 平局效果
# @TeamCode: 1R 2B 3G 4Y



# DRAW Effect
titleraw @a[tag=语言] title {"rawtext":[{"translate":"style.cnp.gameover.title"}]}
titleraw @a[tag=language] title {"rawtext":[{"translate":"style.hyp.gameover.title"}]}

execute if score event_level M3F75C = num_0 B7O14L if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 4..5 run title @a title §c§l非正确场地!
execute if score event_level M3F75C = num_0 B7O14L if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 4..5 run title @a subtitle §f§l排位模式正在刷新场地

execute if score event_level M3F75C = num_0 B7O14L if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 1..2 run title @a title §c§l非正确场地!
execute if score event_level M3F75C = num_0 B7O14L if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 1..2 run title @a subtitle §f§l排位模式正在刷新场地

#function global/end/HR


execute as @a[tag=inf] at @s run summon fireworks_rocket
execute as @a[tag=inf] at @s run summon fireworks_rocket


setblock 9 101 972 redstone_block

tag @e[type=npc] remove canace

scoreboard players set start B7O14L 3

execute as @a at @s run playsound mob.enderdragon.death @s

tag @e remove 语言地图
tag @e remove languagemap

