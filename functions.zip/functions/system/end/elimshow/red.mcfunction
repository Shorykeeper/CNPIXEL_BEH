
tellraw @a {"rawtext":[{"text":""}]}

tellraw @a {"rawtext":[{"translate":"style.cnp.red_eliminated"}]}
