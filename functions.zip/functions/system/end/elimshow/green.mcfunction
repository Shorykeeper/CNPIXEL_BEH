
tellraw @a {"rawtext":[{"text":""}]}

tellraw @a {"rawtext":[{"translate":"style.cnp.green_eliminated"}]}
