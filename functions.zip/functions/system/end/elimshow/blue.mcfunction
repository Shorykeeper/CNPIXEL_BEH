
tellraw @a {"rawtext":[{"text":""}]}

tellraw @a {"rawtext":[{"translate":"style.cnp.blue_eliminated"}]}
