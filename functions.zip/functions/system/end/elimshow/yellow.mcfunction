
tellraw @a {"rawtext":[{"text":""}]}

tellraw @a {"rawtext":[{"translate":"style.cnp.yellow_eliminated"}]}
