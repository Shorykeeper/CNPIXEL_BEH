

execute as @a[tag=inf,tag=winn] at @s run summon fireworks_rocket

execute as @a[tag=inf,tag=winn] at @s run effect @s jump_boost 2 3 true

titleraw @a[tag=语言,tag=winn] title {"rawtext":[{"translate":"style.cnp.victory.title"}]}
titleraw @a[tag=language,tag=winn] title {"rawtext":[{"translate":"style.hyp.victory.title"}]}

execute as @a[tag=inf,tag=winn] at @s run summon fireworks_rocket

execute if score event_level M3F75C = num_0 B7O14L if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 4..5 run title @a title §c§l非正确场地!
execute if score event_level M3F75C = num_0 B7O14L if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 4..5 run title @a subtitle §f§l排位模式正在刷新场地

execute if score event_level M3F75C = num_0 B7O14L if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 1..2 run title @a title §c§l非正确场地!
execute if score event_level M3F75C = num_0 B7O14L if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 1..2 run title @a subtitle §f§l排位模式正在刷新场地



