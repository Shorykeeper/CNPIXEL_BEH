

#  递进计算 活源更迭
#  这里不需要考虑团灭 只计算无床有人的计分板显示

# 当分数等于 5 时
execute if score brs D1W04T = num_5 B7O14L if entity @e[name=!"§a5",tag=btbeds] run tag @e[name=!"§a5",tag=btbeds] remove btbeds
execute if entity @e[name="§a5",tag=!btbeds] if score brs D1W04T = num_5 B7O14L run tag @e[name="§a5"] add btbeds

# 当分数等于 4 时
execute if score brs D1W04T = num_4 B7O14L if entity @e[name=!"§a4",tag=btbeds] run tag @e[name=!"§a4",tag=btbeds] remove btbeds
execute if entity @e[name="§a4",tag=!btbeds] if score brs D1W04T = num_4 B7O14L run tag @e[name="§a4"] add btbeds


execute if score brs D1W04T = num_3 B7O14L if entity @e[name=!"§a3",tag=btbeds] run tag @e[name=!"§a3",tag=btbeds] remove btbeds
execute if entity @e[name="§a3",tag=!btbeds] if score brs D1W04T = num_3 B7O14L run tag @e[name="§a3"] add btbeds

execute if score brs D1W04T = num_2 B7O14L if entity @e[name=!"§a2",tag=btbeds] run tag @e[name=!"§a2",tag=btbeds] remove btbeds
execute if entity @e[name="§a2",tag=!btbeds] if score brs D1W04T = num_2 B7O14L run tag @e[name="§a2"] add btbeds

execute if score brs D1W04T = num_1 B7O14L run tag @e[name=!"§a1",tag=btbeds] remove btbeds
execute if entity @e[name="§a1",tag=!btbeds] if score brs D1W04T = num_1 B7O14L run tag @e[name="§a1"] add btbeds

