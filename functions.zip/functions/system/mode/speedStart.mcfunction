
# customized commands
countdown upgrade diamond
countdown upgrade diamond
countdown upgrade emerald
countdown upgrade emerald


kill @e[name="§e等级 §cI"]
execute as @e[type=minecrafts:diamond_spawner] at @s run summon bedwars:text "§e等级 §cIII" ~~0.8~
execute as @e[type=minecrafts:emerald_spawner] at @s run summon bedwars:text "§e等级 §cIII" ~~0.8~

scoreboard players set @e[tag=iron_spawn] Y9V88N 5

execute at @e[tag=iron_spawn] run structure load ShoreKeepBeh:emerald ~~1~
