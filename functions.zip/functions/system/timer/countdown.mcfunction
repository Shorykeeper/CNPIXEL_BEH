# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 倒计时引用
# @PING : 20


# 各数值
execute if score start B7O14L matches 1 if score count M3F75C matches 180 run function system/start/num/180
execute if score start B7O14L matches 1 if score count M3F75C matches 120 run function system/start/num/120
execute if score start B7O14L matches 1 if score count M3F75C matches 60 run function system/start/num/60
execute if score start B7O14L matches 1 if score count M3F75C matches 40 run function system/start/num/40
execute if score start B7O14L matches 1 if score count M3F75C matches 20 run function system/start/num/20
execute if score start B7O14L matches 1 if score count M3F75C matches 10 run function system/start/num/10
execute if score start B7O14L matches 1 if score count M3F75C matches 5 run function system/start/num/5
execute if score start B7O14L matches 1 if score count M3F75C matches 4 run function system/start/num/4
execute if score start B7O14L matches 1 if score count M3F75C matches 3 run function system/start/num/3
execute if score start B7O14L matches 1 if score count M3F75C matches 2 run function system/start/num/2
execute if score start B7O14L matches 1 if score count M3F75C matches 1 run function system/start/num/1

# 倒计时成功归零 引用全局开局
execute unless entity @a[tag=inf] if score start B7O14L matches 1 if score count M3F75C matches ..0 run function system/start/bwstart



