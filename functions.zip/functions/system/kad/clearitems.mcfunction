# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 和谐地清空玩家物品 需要被引用使用
# @TeamCode: 1R 2B 3G 4Y

##清背包 inventory 0-26
replaceitem entity @s slot.inventory 0 air
replaceitem entity @s slot.inventory 1 air
replaceitem entity @s slot.inventory 2 air
replaceitem entity @s slot.inventory 3 air
replaceitem entity @s slot.inventory 4 air
replaceitem entity @s slot.inventory 5 air
replaceitem entity @s slot.inventory 6 air
replaceitem entity @s slot.inventory 7 air
replaceitem entity @s slot.inventory 8 air
replaceitem entity @s slot.inventory 9 air
replaceitem entity @s slot.inventory 10 air
replaceitem entity @s slot.inventory 11 air
replaceitem entity @s slot.inventory 12 air
replaceitem entity @s slot.inventory 13 air
replaceitem entity @s slot.inventory 14 air
replaceitem entity @s slot.inventory 15 air
replaceitem entity @s slot.inventory 16 air
replaceitem entity @s slot.inventory 17 air
replaceitem entity @s slot.inventory 18 air
replaceitem entity @s slot.inventory 19 air
replaceitem entity @s slot.inventory 20 air
replaceitem entity @s slot.inventory 21 air
replaceitem entity @s slot.inventory 22 air
replaceitem entity @s slot.inventory 23 air
replaceitem entity @s slot.inventory 24 air
replaceitem entity @s slot.inventory 25 air
replaceitem entity @s slot.inventory 26 air

##清物品栏 hotbar 0-8
replaceitem entity @s[tag=inf] slot.hotbar 0 wooden_sword 
replaceitem entity @s slot.hotbar 1 air
replaceitem entity @s slot.hotbar 2 air
replaceitem entity @s slot.hotbar 3 air
replaceitem entity @s slot.hotbar 4 air
replaceitem entity @s slot.hotbar 5 air
replaceitem entity @s slot.hotbar 6 air
replaceitem entity @s slot.hotbar 7 air
replaceitem entity @s slot.hotbar 8 air

##清副手 offhand 1
replaceitem entity @s slot.weapon.offhand 1 air
