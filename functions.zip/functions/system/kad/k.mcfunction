# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 玩家击杀效果 被BwScript引用 
# @TeamCode: 1R 2B 3G 4Y

playsound random.orb @s

execute if score mode O8P02W = num_1 B7O14L as @s run give @s golden_apple 1


