# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 死亡减工具级

scoreboard players add @s X2C07R 0
scoreboard players add @s I0S08X 0

execute as @s[scores={X2C07R=2..4}] run scoreboard players remove @s X2C07R 1
execute as @s[scores={I0S08X=2..4}] run scoreboard players remove @s I0S08X 1

execute as @s[scores={X2C07R=1}] run loot give @s loot "pickaxe_0"
execute as @s[scores={X2C07R=2}] run loot give @s loot "pickaxe_1"
execute as @s[scores={X2C07R=3}] run loot give @s loot "pickaxe_2"
execute as @s[scores={X2C07R=4}] run loot give @s loot "pickaxe_3"

execute as @s[scores={I0S08X=1}] run loot give @s loot "axe_0"
execute as @s[scores={I0S08X=2}] run loot give @s loot "axe_1"
execute as @s[scores={I0S08X=3}] run loot give @s loot "axe_2"
execute as @s[scores={I0S08X=4}] run loot give @s loot "axe_3"

execute as @s[tag=shears] run give @s shears 1 0 {"item_lock":{"mode":"lock_in_inventory"}}

