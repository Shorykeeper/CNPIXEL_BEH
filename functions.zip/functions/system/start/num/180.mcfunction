
# sounds
execute as @a at @s run playsound note.hat @s

#titleraw
titleraw @a title {"rawtext":[{"translate":"style.hyp.startdown_180.title"}]}

#tellraw
tellraw @a {"rawtext":[{"translate":"style.cnp.startdown_180.msg"}]}
tellraw @a[tag=language] {"rawtext":[{"translate":"style.hyp.startdown_180.msg"}]}
