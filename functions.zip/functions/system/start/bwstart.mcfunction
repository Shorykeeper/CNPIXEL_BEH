# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 游戏开始
# @TeamCode: 1R 2B 3G 4Y 


# rbw模式防护
execute unless entity @r[tag=canrbw] if score mode O8P02W matches 5 run tellraw @a {"rawtext":[{"text":"\n§c§l未检索到可使用rbw模式权限的玩家,已调回经典模式,若需要开启rbw模式请持有开启秘钥的玩家前来开启"}]}
execute unless entity @r[tag=canrbw] if score mode O8P02W matches 5 run scoreboard players set @a O8P02W 6
execute unless entity @r[tag=canrbw] if score mode O8P02W matches 5 run scoreboard players set mode O8P02W 6



# ======================================
#清除
tag @a remove S2P10K
kill @e[name="§c保护你的床!"]
kill @e[name="§1"]
kill @e[name="§2"]
kill @e[name="§3"]
kill @e[name="§4"]
clear @a
kill @e[type=item]
xp -10000l @a
tag @a remove candoend



#  设置游戏状态为 [对局中 , 2]
#  重置倒计时 = 60
scoreboard players set count M3F75C 60

# ======================================
#  设置悬浮生命值显示 [T2R10A , @s]
scoreboard objectives remove T2R10A
scoreboard objectives add T2R10A dummy "§c❤"
scoreboard objectives setdisplay belowname T2R10A

#  同步模式数据
execute as @a run scoreboard players operation @s O8P02W = mode O8P02W 


#执行分队
# 选队分数 = 实际队伍分
scoreboard objectives add team_c dummy
scoreboard players add @a team_c 0
scoreboard players add @a A1T12P 0
execute as @a[tag=!nogame,tag=!banned] run scoreboard players operation @s A1T12P = @s team_c

# 清除 初始化
scoreboard players set team_rp B7O14L 0
scoreboard players set team_bp B7O14L 0
scoreboard players set team_gp B7O14L 0
scoreboard players set team_yp B7O14L 0

# 计算队伍人数 在之后为避免空队
execute as @a[scores={A1T12P=1}] run scoreboard players add team_rp B7O14L 1
execute as @a[scores={A1T12P=2}] run scoreboard players add team_bp B7O14L 1
execute as @a[scores={A1T12P=3}] run scoreboard players add team_gp B7O14L 1
execute as @a[scores={A1T12P=4}] run scoreboard players add team_yp B7O14L 1

# 避免空队 进行最后轮补
scoreboard players add @a[tag=!nogame,tag=!banned] A1T12P 0
execute if score team_rp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 1
execute if score team_bp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 2
execute if score team_gp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 3
execute if score team_yp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 4

execute if score team_rp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 1
execute if score team_bp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 2
execute if score team_gp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 3
execute if score team_yp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 4


execute as @a[scores={A1T12P=1}] run scoreboard players add team_rp B7O14L 1
execute as @a[scores={A1T12P=2}] run scoreboard players add team_bp B7O14L 1
execute as @a[scores={A1T12P=3}] run scoreboard players add team_gp B7O14L 1
execute as @a[scores={A1T12P=4}] run scoreboard players add team_yp B7O14L 1

execute if score team_rp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 1
execute if score team_bp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 2
execute if score team_gp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 3
execute if score team_yp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 4

execute if score team_rp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 1
execute if score team_bp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 2
execute if score team_gp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 3
execute if score team_yp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 4


execute unless score team_yp B7O14L matches 2 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 4
execute unless score team_gp B7O14L matches 2 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 3
execute unless score team_bp B7O14L matches 2 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 2
execute unless score team_rp B7O14L matches 2 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 1




# 对轮空的进行轮空操作
execute as @a[scores={A1T12P=0}] run tag @s add 轮空
execute as @a[tag=轮空] run gamemode spectator @s
scoreboard players reset @a[scores={A1T12P=0}] A1T12P
execute as @a[tag=轮空] run function global/command/view



# 清除选队 闭环
scoreboard players reset * team_c



scoreboard players set start B7O14L 2

tag @a[scores={A1T12P=1..4}] add startgame

tag @e[name="comp",type=armor_stand,tag=!canend] add canend
scoreboard players set @a O3G30Q 0
scoreboard players set @a R4DO6T 0
scoreboard players set @a G2L41J 0
scoreboard players set @a I3P77O 0


#播放音效
execute as @a at @s run playsound random.levelup @s 
execute as @a at @s run playsound mob.enderdragon.growl @s ~~12~


# 补时间正计时分分
scoreboard players set m1 Z4T27M 0
scoreboard players set m2 Z4T27M 0
scoreboard players set s2 Z4T27M 0
scoreboard players set s1 Z4T27M 0

# 设置初始时间
scoreboard players set m1 D9T95M 1
scoreboard players set m2 D9T95M 4
scoreboard players set s1 D9T95M 0
scoreboard players set s2 D9T95M 0
#
scoreboard players add m1 D9T95M 1


#  更新队伍状态显示
tag @e remove rtbeds
tag @e remove btbeds
tag @e remove gtbeds
tag @e remove ytbeds

tag @e[name="§a✔"] add rtbeds
tag @e[name="§a✔"] add btbeds
tag @e[name="§a✔"] add ytbeds
tag @e[name="§a✔"] add gtbeds


#给木剑
replaceitem entity @a[tag=inf] slot.hotbar 0 wooden_sword 




#自定义颜色盔甲挂接
execute as @a[scores={A1T12P=1..}] run function system/armor/team
tag @a add inf

function map/apply

#赋予团灭提示机会 借用NPC作为载体
tag @e[name="§c✘"] add canace
tag @e[name="§a1"] add canace
tag @e[name="§a2"] add canace
tag @e[name="§a✔"] add canace

#设置初始事件为0 开局 意为0个事件已发生
scoreboard players set event_level M3F75C 0


scoreboard players reset @e[type=armor_stand] D1W04T 
scoreboard players add allt D1W04T 0


effect @a clear

# ======================================
#  基地矿石系统 [Y9V88N , type=bedwars:text]
#  初始刷新,生成家矿资源点
#execute unless score mode O8P02W matches 1 B7O14L as @a[scores={A1T12P=1..}] run function global/start/deploy_to_map/ore
#   以主城为中心rm选择标识基地资源点
execute positioned 73 186 1824 unless score mode O8P02W matches 1 run tag @e[rm=100,type=bedwars:text,name="§b"] add iron_spawn
#   基地资源初始赋分 (初始等级)
execute as @e[tag=iron_spawn] at @s run scoreboard players set @s Y9V88N 1


#title提示
titleraw @a title {"rawtext":[{"translate":"style.cnp.startgame.title"}]}
titleraw @a subtitle {"rawtext":[{"translate":"style.cnp.startgame.subtitle"}]}


# 提示开始文字
function system/start/introduce

#队伍聊天提示
function global/reward/chatNoteInStart

#参与奖励
#execute as @a[scores={A1T12P=1..4}] as @a[scores={A1T12P=1..}] run function system/reward/participationRewards



#激活事件
function system/event/bwstart_activate



gamemode 0 @a[tag=inf]



replaceitem entity @a[tag=inf] slot.hotbar 8 compass
replaceitem entity @a[tag=inf] slot.hotbar 0 wooden_sword

execute as @a[scores={A1T12P=1..4}] if score mode O8P02W matches 1 as @a[scores={A1T12P=1..}] run function system/mode/bedfightWeapon
execute if score mode O8P02W matches 3 run scoreboard players set resource A4Q23U 1



scoreboard players random match_id B7O14L 1 100000
scoreboard players operation @a[tag=inf] B7O14L = match_id B7O14L

scoreboard players set start B7O14L 2

execute unless score mode O8P02W matches 1 unless score mode O8P02W matches 2 run tag @a[tag=inf] add 床保护
execute unless score mode O8P02W matches 1 unless score mode O8P02W matches 2 run scoreboard players set 床保护 B7O14L 100

# 显示文本（相对坐标，无需修改）
execute as @e[type=minecrafts:diamond_spawner] at @s run summon bedwars:text "§l§b钻石" ~~0.4~
execute as @e[type=minecrafts:diamond_spawner] at @s run summon bedwars:text "§e等级 §cI" ~~0.8~

execute as @e[type=minecrafts:diamond_spawner] at @s run summon hb:block ~~-1.2~
execute as @e[type=minecrafts:diamond_spawner] at @s run event entity @e[r=3,type=hb:block] diamond

execute at @e[type=minecrafts:diamond_spawner] run structure load ShoreKeepBeh:diamond ~~1~

# -----
execute as @e[type=minecrafts:emerald_spawner] at @s run summon bedwars:text "§l§2绿宝石" ~~0.4~
execute as @e[type=minecrafts:emerald_spawner] at @s run summon bedwars:text "§e等级 §cI" ~~0.8~


execute as @e[type=minecrafts:emerald_spawner] at @s run summon hb:block ~~-1.2~
execute as @e[type=minecrafts:emerald_spawner] at @s run event entity @e[r=3,type=hb:block] emerald

execute at @e[type=minecrafts:emerald_spawner] run structure load ShoreKeepBeh:emerald ~~1~


# 疾速模式 满资源点
execute if score mode O8P02W matches 2 as @a[scores={A1T12P=1..}] run function system/mode/speedStart

execute if score mode O8P02W matches 4 run scoreboard players set @e[tag=iron_spawn] Y9V88N 5


