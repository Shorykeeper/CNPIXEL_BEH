# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 取消倒计时


# 复原机制 
# 重置倒计时 = 60
# 重置游戏状态为 [等待 , 0]
scoreboard players set count M3F75C 60
scoreboard players set start B7O14L 0


tellraw @a {"rawtext":[{"translate":"style.cnp.need_more.msg"}]}
titleraw @a title {"rawtext":[{"translate":"style.cnp.need_more.title"}]}
titleraw @a subtitle {"rawtext":[{"translate":"style.cnp.need_more.subtitle"}]}


xp -1000L @a

clear @a

tp @a 2314 240 2285

