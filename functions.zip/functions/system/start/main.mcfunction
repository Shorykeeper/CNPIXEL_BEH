# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 倒计时主体 当非战斗时会长引用


# 人数重新不足 则倒计时失败 引用中止
execute unless entity @a[tag=inf] if score start B7O14L matches 1 if score count M3F75C matches 1.. if score rs D1W04T matches ..1 run function system/start/cancel
# 倒计时效果在 time-global/timer/countdown进行引用计算

#循环启用选队系统
#execute if score start B7O14L matches 1 unless entity @a[tag=inf] run function system/start/choose_team/choose_team_main

#给选队
# ender_eye 道具检测使用
execute if score start B7O14L matches 1 if score count M3F75C matches 7.. if score rs D1W04T matches 3.. unless entity @a[tag=inf] run replaceitem entity @a slot.hotbar 0 ender_eye 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}


#传送不在玻璃屋的人
execute if score start B7O14L matches 1  unless entity @a[tag=inf] positioned 111 230 104 as @a[rm=100] at @s run function map/spectating

#人数达到合适就快进进程
execute if score start B7O14L matches 1 if score rs D1W04T matches 4.. if score count M3F75C matches 31.. run function system/start/increaseCountDown

#隐身NPC
#execute as @e[type=npc] at @s run playanimation @e[type=npc] animation.creeper.swelling move 178178

