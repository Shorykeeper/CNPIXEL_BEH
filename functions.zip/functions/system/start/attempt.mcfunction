# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 倒计时主体 当非战斗时会长引用

# 仅触发一次部署
execute unless entity @a[tag=inf] if score start B7O14L matches 0 if score rs D1W04T matches 2.. run function system/start/deploy

