# -*- coding: utf-8 -*-
# @Author : AerMini. [ QID: AerMini ]
# @Function : 余额分队 被bwstart调用
# @TeamCode: A1T12P - 1R 2B 3G 4Y

# 选队分数 = 实际队伍分
execute as @a[tag=!nogame,tag=!banned] run scoreboard players operation @s A1T12P = @s team_c

# 清除 初始化
scoreboard players set team_rp B7O14L 0
scoreboard players set team_bp B7O14L 0
scoreboard players set team_gp B7O14L 0
scoreboard players set team_yp B7O14L 0

# 计算队伍人数 在之后为避免空队
execute as @a[scores={A1T12P=1}] run scoreboard players add team_rp B7O14L 1
execute as @a[scores={A1T12P=2}] run scoreboard players add team_bp B7O14L 1
execute as @a[scores={A1T12P=3}] run scoreboard players add team_gp B7O14L 1
execute as @a[scores={A1T12P=4}] run scoreboard players add team_yp B7O14L 1

# 避免空队 进行最后轮补
scoreboard players add @a[tag=!nogame,tag=!banned] A1T12P 0
execute if score team_rp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 1
execute if score team_bp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 2
execute if score team_gp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 3
execute if score team_yp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 4

execute if score team_rp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 1
execute if score team_bp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 2
execute if score team_gp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 3
execute if score team_yp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=0}] A1T12P 4


execute as @a[scores={A1T12P=1}] run scoreboard players add team_rp B7O14L 1
execute as @a[scores={A1T12P=2}] run scoreboard players add team_bp B7O14L 1
execute as @a[scores={A1T12P=3}] run scoreboard players add team_gp B7O14L 1
execute as @a[scores={A1T12P=4}] run scoreboard players add team_yp B7O14L 1

execute if score team_rp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 1
execute if score team_bp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 2
execute if score team_gp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 3
execute if score team_yp B7O14L matches 0 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 4

execute if score team_rp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 1
execute if score team_bp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 2
execute if score team_gp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 3
execute if score team_yp B7O14L matches 1 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 4


execute unless score team_yp B7O14L matches 2 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 4
execute unless score team_gp B7O14L matches 2 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 3
execute unless score team_bp B7O14L matches 2 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 2
execute unless score team_rp B7O14L matches 2 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 1

execute if score mode O8P02W = num_5 B7O14L run scoreboard players reset * team_c
execute if score mode O8P02W = num_5 B7O14L run scoreboard players set @a A1T12P 0
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 3 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 2
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 3 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 4
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 3 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 2
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 3 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 4
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 3 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 2
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 3 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 4
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 3 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 2
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 3 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 4


execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 6 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 3
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 6 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 4
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 6 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 3
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 6 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 4
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 6 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 3
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 6 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 4
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 6 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 3
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 6 run scoreboard players set @r[scores={A1T12P=!1..4}] A1T12P 4


# 对轮空的进行轮空操作
execute as @a[scores={A1T12P=0}] run tag @s add 轮空
execute as @a[tag=轮空] run gamemode spectator @s
scoreboard players reset @a[scores={A1T12P=0}] A1T12P
execute as @a[tag=轮空] run function global/command/view



# 清除选队 闭环
scoreboard players reset * team_c


