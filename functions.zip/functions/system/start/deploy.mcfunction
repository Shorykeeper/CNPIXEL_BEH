# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ ShoreKeep ]
# @Function : 部署一次倒计时开始效果

#Tips: 这里只在main条件达标的时唯引一次
#function start/choose_team/config/normal

#设置游戏状态为 [倒计时 , 1]
scoreboard players set start B7O14L 1

#验证模式判断是否清除疾速保护
function map/cleanSetting

#设置倒计时为 180
scoreboard players set count M3F75C 180

#播报即将开始文本title
titleraw @a title {"rawtext":[{"translate":"style.cnp.can_start.title"}]}
titleraw @a subtitle {"rawtext":[{"translate":"style.cnp.can_start.subtitle"}]}

# 根据模式清理设置初始床保护
function map/cleanSetting

#传到战场
execute as @a run function map/spectating

#加经验条数字倒计时显示 1l = 1s
xp -9999l @a
xp 180L @a

# 播放一次开始一次音效
execute as @a at @s run playsound random.levelup @s
