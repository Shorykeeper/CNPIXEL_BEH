# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 黄队床被破坏

#   --% 文件的名等同于脚本逻辑何床所破
#   --% 在此骄傲一下我的format小巧思

## 播放音效
#黄 无床音
execute as @a[scores={A1T12P=4}] at @s run playsound mob.wither.death @s ~~~
#其他 床音
execute as @a[scores={A1T12P=!4}] at @s run playsound mob.enderdragon.growl @s ~~12~

## 清除被破床队陷阱 这里是 -> 黄队
scoreboard players reset yellow W4G21E

## 更改显示 取消有床状态
tag @e[name="§a✔"] remove ytbeds
tag @e[name="§c✘"] add ytbeds

## 告诉同志们个好消息
# 无床人的msg

execute if score @p[tag=desb_YELLOW] A1T12P matches 1 run tellraw @a[scores={A1T12P=4}] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.cnp.own_bed_dest.msg","with":{"rawtext":[{"translate":"§c%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}
execute if score @p[tag=desb_YELLOW] A1T12P matches 2 run tellraw @a[scores={A1T12P=4}] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.cnp.own_bed_dest.msg","with":{"rawtext":[{"translate":"§9%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}
execute if score @p[tag=desb_YELLOW] A1T12P matches 3 run tellraw @a[scores={A1T12P=4}] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.cnp.own_bed_dest.msg","with":{"rawtext":[{"translate":"§a%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}

# 其他人的msg
execute if score @p[tag=desb_YELLOW] A1T12P matches 1 run tellraw @a[scores={A1T12P=!4}] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.cnp.bed_dest_yellow.msg","with":{"rawtext":[{"translate":"§c%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}
execute if score @p[tag=desb_YELLOW] A1T12P matches 2 run tellraw @a[scores={A1T12P=!4}] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.cnp.bed_dest_yellow.msg","with":{"rawtext":[{"translate":"§9%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}
execute if score @p[tag=desb_YELLOW] A1T12P matches 3 run tellraw @a[scores={A1T12P=!4}] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.cnp.bed_dest_yellow.msg","with":{"rawtext":[{"translate":"§a%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}

#无床人的title+subtitle
titleraw @a[scores={A1T12P=4}] title {"rawtext":[{"translate":"style.cnp.bed_dest.title"}]}
titleraw @a[scores={A1T12P=4}] subtitle {"rawtext":[{"translate":"style.cnp.bed_dest.subtitle"}]}

## 给无床人无床tag
tag @a[scores={A1T12P=4}] add 无床

## 给破床人奖励
execute as @p[tag=desb_YELLOW] at @s run function global/reward/desbed

## 破床人清除标签
tag @p[tag=desb_YELLOW] remove desb_YELLOW





