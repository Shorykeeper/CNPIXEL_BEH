
execute as @s at @s run tellraw @a {"rawtext":[{"translate":"%%%%s","with":{"rawtext":[{"score":{"name":"@s","objective":"E3Q28N"}},{"translate":"style.cnp.bed_dest_blue.msg","with":{"rawtext":[{"selector":"@s"}]}},{"translate":"style.cnp.bed_dest_blue_1.msg","with":{"rawtext":[{"selector":"@s"}]}},{"translate":"style.cnp.bed_dest_blue_2.msg","with":{"rawtext":[{"selector":"@s"}]}},{"translate":"style.cnp.bed_dest_blue_3.msg","with":{"rawtext":[{"selector":"@s"}]}},{"translate":"style.cnp.bed_dest_blue_4.msg","with":{"rawtext":[{"selector":"@s"}]}},{"translate":"style.cnp.bed_dest_blue_5.msg","with":{"rawtext":[{"selector":"@s"}]}}]}}]}


