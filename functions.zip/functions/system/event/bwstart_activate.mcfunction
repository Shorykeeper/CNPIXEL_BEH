# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 游戏开始时 激活事件 引用一次

#记得加execute if score加模式区分
# 1 = bf  2 = speed   15分钟床自毁
execute if score mode O8P02W matches 1..2 run summon rabbit "床自毁" -32 -57 1023
execute if score mode O8P02W matches 1..2 run tag @e[name="床自毁"] add 语言事件

#  4-5-6 设置事件初始时间为6分钟
execute if score mode O8P02W matches 1..2 run scoreboard players set sjm1 D9T95M 4
execute if score mode O8P02W matches 1..2 run scoreboard players set sjm2 D9T95M 2
execute if score mode O8P02W matches 1..2 run scoreboard players set sjs1 D9T95M 0
execute if score mode O8P02W matches 1..2 run scoreboard players set sjs2 D9T95M 0
#
execute if score mode O8P02W matches 1..2 run scoreboard players add sjm1 D9T95M 1




# 3 = onexp
execute if score mode O8P02W matches 3 run summon rabbit "资源生成点升至II级倒计时" -32 -57 1023
execute if score mode O8P02W matches 3 run tag @e[name="资源生成点升至II级倒计时"] add 语言事件

# 3 设置事件初始时间为5分钟
execute if score mode O8P02W matches 3 run scoreboard players set sjm1 D9T95M 4
execute if score mode O8P02W matches 3 run scoreboard players set sjm2 D9T95M 0
execute if score mode O8P02W matches 3 run scoreboard players set sjs1 D9T95M 0
execute if score mode O8P02W matches 3 run scoreboard players set sjs2 D9T95M 0

execute if score mode O8P02W matches 3 run scoreboard players add sjm1 D9T95M 1


# 4=xp 5=job 6=classic
execute if score mode O8P02W matches 4..6 run summon rabbit "钻石生成点II级" -32 -57 1023
execute if score mode O8P02W matches 4..6 run tag @e[name="钻石生成点II级"] add 语言事件


#  4-5-6 设置事件初始时间为6分钟
execute if score mode O8P02W matches 4..6 run scoreboard players set sjm1 D9T95M 5
execute if score mode O8P02W matches 4..6 run scoreboard players set sjm2 D9T95M 0
execute if score mode O8P02W matches 4..6 run scoreboard players set sjs1 D9T95M 0
execute if score mode O8P02W matches 4..6 run scoreboard players set sjs2 D9T95M 0

execute if score mode O8P02W matches 4..6 run scoreboard players add sjm1 D9T95M 1
