
#
execute if score start B7O14L matches 2 if score event_level M3F75C matches 0 if score sjm2 D9T95M matches 0 if score sjm1 D9T95M matches 0 if score sjs2 D9T95M matches 0 if score sjs1 D9T95M matches 0 run function system/event/project/destruction

#
execute if score start B7O14L matches 2 if score event_level M3F75C matches 1 if score sjm2 D9T95M matches 0 if score sjm1 D9T95M matches 0 if score sjs2 D9T95M matches 0 if score sjs1 D9T95M matches 0 run function system/event/project/duel

#
execute if score start B7O14L matches 2 if score event_level M3F75C matches 2 if score sjm2 D9T95M matches 0 if score sjm1 D9T95M matches 0 if score sjs2 D9T95M matches 0 if score sjs1 D9T95M matches 0 run function system/event/project/end

