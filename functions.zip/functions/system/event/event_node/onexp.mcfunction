


execute if score start B7O14L matches 2 if score event_level M3F75C matches 0 if score sjm1 D9T95M matches 0 if score sjs2 D9T95M matches 0 if score sjs1 D9T95M matches 0 run function system/event/project/ore_level/1xp/resource_2

#
execute if score start B7O14L matches 2 if score event_level M3F75C matches 1 if score sjm1 D9T95M matches 0 if score sjs2 D9T95M matches 0 if score sjs1 D9T95M matches 0 run function system/event/project/1xp/health_1

#
execute if score start B7O14L matches 2 if score event_level M3F75C matches 2 if score sjm1 D9T95M matches 0 if score sjs2 D9T95M matches 0 if score sjs1 D9T95M matches 0 run function system/event/project/ore_level/1xp/resource_3

#
execute if score start B7O14L matches 2 if score event_level M3F75C matches 3 if score sjm1 D9T95M matches 0 if score sjs2 D9T95M matches 0 if score sjs1 D9T95M matches 0 run function system/event/project/1xp/wither_bow

#
execute if score start B7O14L matches 2 if score event_level M3F75C matches 4 if score sjm1 D9T95M matches 0 if score sjs2 D9T95M matches 0 if score sjs1 D9T95M matches 0 run function system/event/project/ore_level/1xp/resource_4

#
execute if score start B7O14L matches 2 if score event_level M3F75C matches 5 if score sjm1 D9T95M matches 0 if score sjs2 D9T95M matches 0 if score sjs1 D9T95M matches 0 run function system/event/project/1xp/health_2

#
execute if score start B7O14L matches 2 if score event_level M3F75C matches 6 if score sjm1 D9T95M matches 0 if score sjs2 D9T95M matches 0 if score sjs1 D9T95M matches 0 run function system/event/project/ore_level/1xp/resource_5

#
execute if score start B7O14L matches 2 if score event_level M3F75C matches 7 if score sjm1 D9T95M matches 0 if score sjs2 D9T95M matches 0 if score sjs1 D9T95M matches 0 run function system/event/project/destruction

#
execute if score start B7O14L matches 2 if score event_level M3F75C matches 8 if score sjm1 D9T95M matches 0 if score sjs2 D9T95M matches 0 if score sjs1 D9T95M matches 0 run function system/event/project/end



