# ===================================
# 根据地图编号执行对应床的移除操作
# 使用记分板判断：mapp F3Q58B == num_1 ~ num_6 B7O14L
# ===================================

# ---------- 地图1: Unturned ----------
execute if score mapp F3Q58B = num_1 B7O14L run fill 105 277 26 105 277 27 air 0 replace bed
execute if score mapp F3Q58B = num_1 B7O14L run fill 184 277 105 183 277 105 air 0 replace bed
execute if score mapp F3Q58B = num_1 B7O14L run fill 105 277 184 105 277 183 air 0 replace bed
execute if score mapp F3Q58B = num_1 B7O14L run fill 26 277 105 27 277 105 air 0 replace bed

# ---------- 地图2: Pool Party ----------
execute if score mapp F3Q58B = num_2 B7O14L run fill 17 276 103 18 276 103 air 0 replace bed
execute if score mapp F3Q58B = num_2 B7O14L run fill 103 276 18 103 276 19 air 0 replace bed
execute if score mapp F3Q58B = num_2 B7O14L run fill 189 276 103 188 276 103 air 0 replace bed
execute if score mapp F3Q58B = num_2 B7O14L run fill 103 276 189 103 276 188 air 0 replace bed

# ---------- 地图3: Katsu ----------
execute if score mapp F3Q58B = num_3 B7O14L run fill 98 270 25 98 270 24 air 0 replace bed
execute if score mapp F3Q58B = num_3 B7O14L run fill 171 270 98 172 270 98 air 0 replace bed
execute if score mapp F3Q58B = num_3 B7O14L run fill 98 270 171 98 270 172 air 0 replace bed
execute if score mapp F3Q58B = num_3 B7O14L run fill 25 270 98 24 270 98 air 0 replace bed

# ---------- 地图4: Garden ----------
execute if score mapp F3Q58B = num_4 B7O14L run fill 38 274 103 39 274 103 air 0 replace bed
execute if score mapp F3Q58B = num_4 B7O14L run fill 104 274 33 104 274 35 air 0 replace bed
execute if score mapp F3Q58B = num_4 B7O14L run fill 166 274 103 165 274 103 air 0 replace bed
execute if score mapp F3Q58B = num_4 B7O14L run fill 104 274 172 104 274 171 air 0 replace bed

# ---------- 地图5: Graveship ----------
execute if score mapp F3Q58B = num_5 B7O14L run fill 167 276 91 167 276 90 air 0 replace bed
execute if score mapp F3Q58B = num_5 B7O14L run fill 87 276 171 86 276 171 air 0 replace bed
execute if score mapp F3Q58B = num_5 B7O14L run fill 33 276 118 33 276 119 air 0 replace bed
execute if score mapp F3Q58B = num_5 B7O14L run fill 113 276 37 114 276 37 air 0 replace bed

# ---------- 地图6: Picnic ----------
execute if score mapp F3Q58B = num_6 B7O14L run fill 41 275 100 42 275 100 air 0 replace bed
execute if score mapp F3Q58B = num_6 B7O14L run fill 102 274 37 102 274 38 air 0 replace bed
execute if score mapp F3Q58B = num_6 B7O14L run fill 166 275 100 165 275 100 air 0 replace bed
execute if score mapp F3Q58B = num_6 B7O14L run fill 102 274 164 102 274 163 air 0 replace bed

