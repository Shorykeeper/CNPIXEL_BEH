


#     设置事件初始时间为6分钟
scoreboard players set sjm1 D9T95M 5
scoreboard players set sjm2 D9T95M 0
scoreboard players set sjs1 D9T95M 0
scoreboard players set sjs2 D9T95M 0
#
scoreboard players add sjm1 D9T95M 1

scoreboard players set dlv A4Q23U 2

tellraw @a {"rawtext":[{"translate":"style.cnp.event.diamond_2"}]}


#清除上一个
kill @e[type=rabbit,tag=语言事件]


#2-3 升级新生
summon rabbit "绿宝石生成点II级" -32 -57 1023


tag @e[name="绿宝石生成点II级"] add 语言事件


scoreboard players add event_level M3F75C 1



execute as @e[type=minecrafts:diamond_spawner] at @s run kill @e[type=bedwars:text,name="§e等级 §cI",r=5]
execute as @e[type=minecrafts:diamond_spawner] at @s run summon bedwars:text "§e等级 §cII" ~~0.8~



countdown upgrade diamond

