
#     设置事件初始时间为5分钟
scoreboard players set sjm1 D9T95M 4
scoreboard players set sjm2 D9T95M 0
scoreboard players set sjs1 D9T95M 0
scoreboard players set sjs2 D9T95M 0
#
scoreboard players add sjm1 D9T95M 1

scoreboard players set resource A4Q23U 4

tellraw @a {"rawtext":[{"translate":"style.cnp.event.one_xp.resource_4"}]}



#清除上一个
kill @e[type=rabbit,tag=语言事件]


#
summon rabbit "第二次血量提升倒计时" -32 -57 1023




scoreboard players add event_level M3F75C 1


