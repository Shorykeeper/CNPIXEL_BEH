
#     设置事件初始时间为5分钟
scoreboard players set sjm1 D9T95M 4
scoreboard players set sjm2 D9T95M 0
scoreboard players set sjs1 D9T95M 0
scoreboard players set sjs2 D9T95M 0
#
scoreboard players add sjm1 D9T95M 1

scoreboard players set resource A4Q23U 5

tellraw @a {"rawtext":[{"translate":"style.cnp.event.one_xp.resource_5"}]}



#清除上一个
kill @e[type=rabbit,tag=语言事件]


#2-3 升级新生
summon rabbit "死亡模式倒计时" -32 -57 1023


tag @e[name="死亡模式倒计时"] add 语言事件


scoreboard players add event_level M3F75C 1


