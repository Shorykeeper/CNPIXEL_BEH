

function global/end/draw

scoreboard players set sjm1 D9T95M 0
scoreboard players set sjm2 D9T95M 0
scoreboard players set sjs1 D9T95M 0
scoreboard players set sjs2 D9T95M 0
#
scoreboard players add sjm1 D9T95M 0


scoreboard players add event_level M3F75C 1

