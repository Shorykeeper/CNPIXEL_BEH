

scoreboard players set sjm1 D9T95M 5
scoreboard players set sjm2 D9T95M 0
scoreboard players set sjs1 D9T95M 0
scoreboard players set sjs2 D9T95M 0
#
scoreboard players add sjm1 D9T95M 1


#挂接清床功能
function system/event/project/event_function/dest_bed

#文本提示
tellraw @a {"rawtext":[{"translate":"style.cnp.event.bed_selfaway.msg"}]}


titleraw @a title {"rawtext":[{"translate":"style.cnp.event.bed_selfaway.title"}]}
titleraw @a subtitle {"rawtext":[{"translate":"style.cnp.event.bed_selfaway.subtitle"}]}



execute as @a at @s run playsound mob.wither.death @s ~~~
tag @a[tag=inf] add 无床


#清除上一个
kill @e[type=rabbit,tag=语言事件]


#升级新生
summon rabbit "绝杀模式" -32 -57 1023


tag @e[name="绝杀模式"] add 语言事件



scoreboard players add event_level M3F75C 1



