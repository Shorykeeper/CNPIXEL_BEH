# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ ShoreKeep ]
# @Function : 床保护end

title @a title §6§l床保护结束
title @a subtitle §f场上的床均可被破坏!

scoreboard players reset 床保护 B7O14L
tag @a remove 床保护

tellraw @a{"rawtext":[{"text":"\n§6§l床保护结束!§r§f 在场所有床已均可被破坏!"}]}

execute as @a at @s run playsound mob.wither.spawn @s ~~~
