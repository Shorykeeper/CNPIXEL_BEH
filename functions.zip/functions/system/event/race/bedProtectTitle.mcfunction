# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ ShoreKeep ]
# @Function : 竞赛床保护提示

title @a title §l§d- Bon §uVoyage！ -
title @a subtitle §7网易全面双端互通,对局可能有PC玩家!

execute as @a[tag=inf] at @s run playsound mob.wither.spawn @s ~~~

execute if score event_level M3F75C = num_0 B7O14L if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 4..5 run title @a title §c§l非正确场地!
execute if score event_level M3F75C = num_0 B7O14L if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 4..5 run title @a subtitle §f§l排位模式正在刷新场地

execute if score event_level M3F75C = num_0 B7O14L if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 1..2 run title @a title §c§l非正确场地!
execute if score event_level M3F75C = num_0 B7O14L if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 1..2 run title @a subtitle §f§l排位模式正在刷新场地



