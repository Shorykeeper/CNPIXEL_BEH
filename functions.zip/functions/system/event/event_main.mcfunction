# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 计算事件发生和部署
# 对应关系: sjm2 sjm1 : sjs2 sjs1


# 切床模式 == 1  疾速模式 == 2 ： 使用快速模型
execute if score mode O8P02W matches 1 run function system/event/event_node/fast_model
execute if score mode O8P02W matches 2 run function system/event/event_node/fast_model

# 一经验模式 == 3 ： 定制特殊模型
execute if score mode O8P02W matches 3 run function system/event/event_node/onexp


# 经验模式 ==4 排位模式 == 5  经典 == 6 ： 使用通用模型
execute if score mode O8P02W matches 4..6 run function system/event/event_node/general






