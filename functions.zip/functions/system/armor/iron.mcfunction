
replaceitem entity @s slot.armor.feet 4 iron_boots 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s slot.armor.legs 3 iron_leggings 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}
tag @s add 附魔

