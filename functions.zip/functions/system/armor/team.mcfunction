# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 初始化玩家颜色盔甲 需要execute引用

##自定义颜色盔甲
#红队 C1
replaceitem entity @s[scores={A1T12P=1}] slot.armor.head 0 fam:helmet_red 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[scores={A1T12P=1}] slot.armor.legs 0 fam:leggings_red 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[scores={A1T12P=1}] slot.armor.chest 0 fam:chestplate_red 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[scores={A1T12P=1}] slot.armor.feet 0 fam:boots_red 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}


#蓝队 C2
replaceitem entity @s[scores={A1T12P=2}] slot.armor.head 0 fam:helmet_blue 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[scores={A1T12P=2}] slot.armor.chest 0 fam:chestplate_blue 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[scores={A1T12P=2}] slot.armor.legs 0 fam:leggings_blue 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[scores={A1T12P=2}] slot.armor.feet 0 fam:boots_blue 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}


#黄队 C3
replaceitem entity @s[scores={A1T12P=3}] slot.armor.head 0 fam:helmet_yellow 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[scores={A1T12P=3}] slot.armor.chest 0 fam:chestplate_yellow 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[scores={A1T12P=3}] slot.armor.legs 0 fam:leggings_yellow 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[scores={A1T12P=3}] slot.armor.feet 0 fam:boots_yellow 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}


#绿队 C4
replaceitem entity @s[scores={A1T12P=4}] slot.armor.head 0 fam:helmet_green 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[scores={A1T12P=4}] slot.armor.chest 0 fam:chestplate_green 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[scores={A1T12P=4}] slot.armor.legs 0 fam:leggings_green 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[scores={A1T12P=4}] slot.armor.feet 0 fam:boots_green 1 0 {"minecraft:item_lock":{"mode":"lock_in_slot"}}

##锁链甲
execute as @s[scores={I3P77O=1}] run function system/armor/chain
##铁甲
execute as @s[scores={I3P77O=2}] run function system/armor/iron
##钻石甲
execute as @s[scores={I3P77O=3}] run function system/armor/diamond


tag @s[tag=inf] add 附魔

