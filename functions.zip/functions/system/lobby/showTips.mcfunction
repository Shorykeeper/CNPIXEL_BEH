# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 全局的系统的小Tips 被执行一次

# msg是一瞬间创建的用于随机分数的计分板

## 前置创建随机计分板
scoreboard objectives add msg dummy

## 随机提示样式分数
scoreboard players random use msg 1 13

## 执行显示
execute if score use msg matches 1 run tellraw @a {"rawtext":[{"translate":"tips.cnp.warn.noct.msg"}]}


execute if score use msg matches 2 run tellraw @a {"rawtext":[{"translate":"tips.cnp.shory.sys.msg"}]}


execute if score use msg matches 3 run tellraw @a {"rawtext":[{"translate":"tips.cnp.rejoin.noct.msg"}]}


execute if score use msg matches 4 run tellraw @a {"rawtext":[{"translate":"tips.cnp.group.msg"}]}


execute if score use msg matches 5 run tellraw @a {"rawtext":[{"translate":"tips.cnp.ultraVires.report.msg"}]}


execute if score use msg matches 6 run tellraw @a {"rawtext":[{"translate":"tips.cnp.tryLuoYueMap.msg"}]}


execute if score use msg matches 7 run tellraw @a {"rawtext":[{"translate":"tips.cnp.AuroraConsiderates.msg"}]}


execute if score use msg matches 8 run tellraw @a {"rawtext":[{"translate":"style.cnp.smwy_PCPE_warning.msg"}]}


execute if score use msg matches 9 run tellraw @a {"rawtext":[{"translate":"style.cnp.smwy_PCPE_warning.msg"}]}


execute if score use msg matches 10 run tellraw @a {"rawtext":[{"translate":"style.cnp.smwy_PCPE_warning.msg"}]}


execute if score use msg matches 11 run tellraw @a {"rawtext":[{"translate":"style.cnp.tips_011.msg"}]}


execute if score use msg matches 12 run tellraw @a {"rawtext":[{"translate":"style.cnp.tips_012.msg"}]}


execute if score use msg matches 13 run tellraw @a {"rawtext":[{"translate":"style.cnp.tips_013.msg"}]}



## 重置计时时间
scoreboard players set tips M3F75C 0

## 直接销毁临时计算计分板
scoreboard objectives remove msg









