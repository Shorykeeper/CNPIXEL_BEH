# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 计时-刷矿中转计算(引用已前置unless)
# @TeamCode: 1R 2B 3G 4Y

# 偷懒 一秒一个铁直接这样得了
function system/ore/timer/base_ore_level/iron

# 刷五次铁后刷一次金
scoreboard players add gold_n Z4T27M 1
execute if score gold_n Z4T27M matches 5..6 run function system/ore/timer/base_ore_level/gold
execute if score gold_n Z4T27M matches 5..6 run scoreboard players reset gold_n Z4T27M
