# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 刷新矿石

#金刷新进行
#execute as @s unless entity @s[tag=spawn_max_gold] at @s run structure load ShoreKeepBeh:gold ~~~

execute as @s at @s unless entity @a[r=3] run structure load ShoreKeepBeh:gold ~~~

execute as @s if entity @a[r=3] run function system/ore/giveDirectly/gold

