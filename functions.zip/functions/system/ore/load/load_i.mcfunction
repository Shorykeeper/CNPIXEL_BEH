# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 刷新矿石

#铁刷新进行
#execute as @s[tag=iron_spawn,tag=!spawn_max_iron] at @s run structure load ShoreKeepBeh:iron ~~~

execute as @s[tag=iron_spawn] at @s unless entity @a[r=3] run structure load ShoreKeepBeh:iron ~~~

execute as @s[tag=iron_spawn] at @s if entity @a[r=3] run function system/ore/giveDirectly/iron
