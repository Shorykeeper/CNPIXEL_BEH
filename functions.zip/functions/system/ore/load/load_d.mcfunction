# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 刷新钻石

#钻石刷新进行
structure load ShoreKeepBeh:diamond ~~~


