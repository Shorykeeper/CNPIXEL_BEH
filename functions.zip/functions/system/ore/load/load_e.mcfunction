# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ ShoreKeep ]
# @Function : 刷新矿石

#绿宝石刷新进行
structure load ShoreKeepBeh:emerald ~~~
