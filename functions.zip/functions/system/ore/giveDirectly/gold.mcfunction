# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 当有人(可多)吸时 不生资源 直接给

execute unless score mode O8P02W matches 3..4 run give @a[r=2,m=0] gold_ingot 1
execute unless score mode O8P02W matches 3..4 run playsound random.pop @a[r=2,m=0] ~~~ 0.18 1.6


execute if score mode O8P02W matches 3..4 run xp 10l @a[r=2,m=0]
execute if score mode O8P02W matches 3..4 run playsound random.orb @a[r=2,m=0]
