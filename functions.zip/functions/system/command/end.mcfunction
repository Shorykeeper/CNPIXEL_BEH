
execute as @s[tag=!candoend] run say 没有合适的时机结束游戏

tag @s[tag=wtf] add candoend
tag @s[tag=wtf1] add candoend
tag @s[tag=wdf] add candoend


execute if entity @s[tag=candoend] run function global/end/draw

tag @s remove candoend


