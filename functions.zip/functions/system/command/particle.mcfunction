

function lobby/npc/particle
