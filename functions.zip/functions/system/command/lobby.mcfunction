
execute as @s[tag=!inf] at @s run function join

