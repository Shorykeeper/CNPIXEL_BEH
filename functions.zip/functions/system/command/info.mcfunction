# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ ShoreKeep ]

function lobby/npc/config

