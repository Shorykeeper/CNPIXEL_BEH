# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ ShoreKeep ]
# @Function : 玩家进入观战效果 被BwScript引用
# @TeamCode: 1R 2B 3G 4Y

execute as @s[tag=!inf,m=2] run tag @s add 观战

execute as @s[tag=!inf,m=2] run effect @s[tag=观战] clear

execute as @s[tag=!inf,m=2] run tellraw @s[tag=观战] {"rawtext":[{"text":"§7正在将你传送到 床战双四 (Bw44-w1tz)"}]}

execute as @s[tag=!inf,m=2] run tellraw @s[tag=观战] {"rawtext":[{"text":"§a§l\n进入观战 §r§7你现在是一名旁观者!\n§r§e输入指令§b/lobby§e可返回主城!"}]}

execute as @s[tag=!inf,m=2] run title @s[tag=观战] title §a§l观战模式

execute as @s[tag=!inf,m=2] run title @s[tag=观战] subtitle §7输入指令 §e/lobby §7可返回主城

execute as @s[tag=!inf] run gamemode spectator @s[tag=观战]

execute as @s[tag=!inf] run tp @s[tag=观战] @r[scores={A1T12P=1..4}]

tag @s remove 轮空
