# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ ShoreKeep ]

tag @s[tag=语言] add 转英文
tag @s[tag=language] add 转中文

tellraw @s[tag=转英文] {"rawtext":[{"translate":"style.hyp.language_use.msg"}]}
tellraw @s[tag=转中文] {"rawtext":[{"translate":"style.cnp.language_use.msg"}]}


tag @s[tag=转英文,tag=语言] add language
tag @s[tag=转英文,tag=语言,tag=language] remove 语言

tag @s[tag=转中文,tag=language] add 语言
tag @s[tag=转中文,tag=language,tag=语言] remove language

tag @a[tag=language,tag=转英文] remove 转英文
tag @a[tag=语言,tag=转中文] remove 转中文

