# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ ShoreKeep ]

tag @s[tag=颗秒] add 转关闭
tag @s[tag=!颗秒] add 转开启



tag @s[tag=转关闭,tag=颗秒] remove 颗秒
tag @s[tag=转开启,tag=!颗秒] add 颗秒


tag @s[tag=转关闭] remove 转关闭
tag @s[tag=转开启] remove 转开启

