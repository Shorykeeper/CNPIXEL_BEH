# -*- coding: utf-8 -*-
# @Author : AerMini. [ QID: AerMini ]
# @Function : 救援平台
# @TeamCode: A1T12P - 1R 2B 3G 4Y

# 计分板:
#CD - @s N5L93G
#KeepTime: @Pig N5L93G

#尝试使用
execute as @e[type=xp_bottle] at @s run tag @p add usesave
execute as @a[tag=usesave,tag=语言] at @s if score @s N5L93G >= num_0 B7O14L run tellraw @s {"rawtext":[{"translate":"style.cnp.save_platform.in_colddown","with":{"rawtext":[{"score":{"objective":"N5L93G","name":"@s"}}]}}]}
execute as @a[tag=usesave,tag=language] at @s if score @s N5L93G >= num_0 B7O14L run tellraw @s {"rawtext":[{"translate":"style.hyp.save_platform.in_colddown","with":{"rawtext":[{"score":{"objective":"N5L93G","name":"@s"}}]}}]}
execute as @a[tag=usesave] at @s if score @s N5L93G >= num_0 B7O14L run give @s experience_bottle

#成功开启
execute as @a[tag=usesave] at @s unless score @s N5L93G >= num_0 B7O14L run summon pig ~~100~
execute as @a[tag=usesave] at @s unless score @s N5L93G >= num_0 B7O14L run tp ~~1.2~
execute as @a[tag=usesave] at @s unless score @s N5L93G >= num_0 B7O14L run scoreboard players set @s N5L93G 16

#清除
tag @a remove usesave
execute as @e[type=xp_bottle] at @s run kill @s

#平台展开
execute as @e[type=pig] at @s run tp ~~~ 
execute as @e[type=pig] at @s run fill ~-1~-100~-1~1~-100~1 slime 0 replace air
execute as @e[type=pig] at @s run setblock ~-1~-100~2 slime keep
execute as @e[type=pig] at @s run setblock ~-1~-100~-2 slime keep
execute as @e[type=pig] at @s run setblock ~1~-100~2 slime keep
execute as @e[type=pig] at @s run setblock ~1~-100~-2 slime keep
execute as @e[type=pig] at @s run setblock ~2~-100~1 slime keep
execute as @e[type=pig] at @s run setblock ~2~-100~-1 slime keep
execute as @e[type=pig] at @s run setblock ~-2~-100~1 slime keep
execute as @e[type=pig] at @s run setblock ~-2~-100~-1 slime keep

#计算时间
scoreboard players add @e[type=pig] N5L93G 1
execute as @e[type=pig,scores={N5L93G=250..}] at @s run fill ~-2~-100~-2~2~-100~2 air 0 replace slime
execute as @e[type=pig,scores={N5L93G=250..}] at @s run kill @s

#以后可能有执行延迟
scoreboard players add @a N5L93G 0
scoreboard players set @a[scores={N5L93G=0}] N5L93G -1


