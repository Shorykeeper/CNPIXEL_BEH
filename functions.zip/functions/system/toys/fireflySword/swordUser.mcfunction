
clear @s minecrafts:firefly_sword 1 0

