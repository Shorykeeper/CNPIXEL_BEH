
effect @s jump_boost 15 1

effect @s instant_health 1 2 true

effect @s resistance 15 1

effect @s slow_falling 15 1

effect @s regeneration 5 0 


