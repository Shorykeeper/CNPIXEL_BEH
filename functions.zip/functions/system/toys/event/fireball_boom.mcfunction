
fill ~1~1~1~-1~-1~-1 air replace red_wool
fill ~1~1~1~-1~-1~-1 air replace blue_wool
fill ~1~1~1~-1~-1~-1 air replace yellow_wool
fill ~1~1~1~-1~-1~-1 air replace lime_wool

