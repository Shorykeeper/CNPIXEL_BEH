#爆炸效果
fill ~2~2~3~-3~-2~-2 air 0 replace red_wool
fill ~2~2~3~-3~-2~-2 air 0 replace blue_wool
fill ~2~2~3~-3~-2~-2 air 0 replace lime_wool
fill ~2~2~3~-3~-2~-2 air 0 replace yellow_wool
fill ~2~2~3~-3~-2~-2 air 0 replace web
fill ~2~2~3~-3~-2~-2 air 0 replace slime
fill ~2~2~3~-3~-2~-2 air 0 replace sponge


fill ~1~1~1~-1~-1~-1 air 0 replace end_stone

fill ~1~1~2~-2~-1~-1 air 0 replace green_terracotta
fill ~1~1~2~-2~-1~-1 air 0 replace yellow_terracotta
fill ~1~1~2~-2~-1~-1 air 0 replace blue_terracotta
fill ~1~1~2~-2~-1~-1 air 0 replace red_terracotta

fill ~1~2~1~-2~-1~-2 air 0 replace oak_planks
fill ~1~2~1~-2~-1~-2 air 0 replace sponge
fill ~2~2~2~-2~-2~-2 air 0 replace ladder


