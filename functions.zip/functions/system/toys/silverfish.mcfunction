# 珍珠
# 时间计算借用牛奶计分板G6Y81S

# execute as @e[type=ender_pearl] run scoreboard players add @e[type=ender_pearl] G6Y81S 1
# execute as @e[scores={G6Y81S=152..},type=ender_pearl] run kill @s
