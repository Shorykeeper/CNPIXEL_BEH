#神奇牛奶

#自定义物品 给时间
execute as @e[tag=usemilk] unless score @s G6Y81S >= num_1 B7O14L run tellraw @s {"rawtext":[{"text":"§e你获得了三十秒抗陷阱能力"}]}
execute as @e[tag=usemilk] unless score @s G6Y81S >= num_1 B7O14L run scoreboard players set @s G6Y81S 30
execute as @a[scores={G6Y81S=0..},tag=usemilk] at @s run tag @s remove usemilk

#计算时间 30x20 -> 0
execute as @a[scores={G6Y81S=0..1}] at @s run scoreboard players set @s G6Y81S -1
