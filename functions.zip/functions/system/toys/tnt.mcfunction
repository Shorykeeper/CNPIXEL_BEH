# 炸药
# 时间计算借用牛奶计分板G6Y81S

scoreboard players add @e[type=tnt] G6Y81S 1
execute as @e[scores={G6Y81S=158..},type=tnt] at @s run function global/toys/event/explode
