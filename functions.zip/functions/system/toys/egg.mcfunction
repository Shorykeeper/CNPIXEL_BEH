# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 道具-搭桥蛋  在道具main被if en引用

# todo: 记得在虚空和出范围杀死

# 主计时 存在周期
scoreboard players add @e[scores={F5J47Z=1..4},type=egg] M3F75C 1
execute as @e[scores={F5J47Z=1..4,M3F75C=52..},type=egg] at @s run kill @s

# 队伍颜色判定
# 初始化队伍
scoreboard players add @e[type=egg] F5J47Z 0
execute as @e[type=egg,scores={F5J47Z=!1..4}] at @s run tag @p[scores={A1T12P=1..4}] add testt
execute as @e[type=egg,scores={F5J47Z=!1..4}] at @s run scoreboard players operation @s F5J47Z = @p[tag=testt] A1T12P
tag @a[tag=testt] remove testt

# 掷出效果
execute as @e[type=egg,scores={F5J47Z=1..4}] at @s run playsound random.pop @a[r=7]
execute as @e[type=egg,scores={F5J47Z=1..4}] at @s run particle minecraft:heart_particle ~~~

# 生成桥梁
execute as @e[type=egg,scores={F5J47Z=1}] at @s positioned ~ ~-1 ~ run fill ~-1~-1~ ~~-1~1 red_wool replace air
execute as @e[type=egg,scores={F5J47Z=2}] at @s positioned ~ ~-1 ~ run fill ~-1~-1~ ~~-1~1 blue_wool replace air
execute as @e[type=egg,scores={F5J47Z=4}] at @s positioned ~ ~-1 ~ run fill ~-1~-1~ ~~-1~1 yellow_wool replace air
execute as @e[type=egg,scores={F5J47Z=3}] at @s positioned ~ ~-1 ~ run fill ~-1~-1~ ~~-1~1 lime_wool replace air

