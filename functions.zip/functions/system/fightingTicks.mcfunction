# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 统括全战局 被other二级条件引用
# @TeamCode: 1R 2B 3G 4Y

## 摔虚空
damage @a[x=-6,y=120,z=-6,dx=300,dy=-300,dz=300,scores={A1T12P=1..},m=0,tag=!winn] 9999 anvil

