# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 统括全战局 被other二级条件引用
# @TeamCode: 1R 2B 3G 4Y


# 计算战斗对局人数
function control/fightingrs

# 事件
function system/event/event_main

function control/ace

#指令管辖的道具引用
execute unless score mode O8P02W matches 1 run function global/toys/main

#执行复活
execute if entity @r[tag=S2P10K] run function system/kad/r

#计算事件
function global/event/event_main

#计算增益效果
function global/upgrade/A_manifest

#防止观战的乱跑
execute if entity @r[tag=观战] positioned 111 230 104 run tp @a[rm=145,tag=观战,m=spectator] 111 230 104

#执行模式效果
function mode/node/main


