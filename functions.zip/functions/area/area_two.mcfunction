tickingarea remove copy1_1
tickingarea remove copy1_2
tickingarea remove copy1_3

tickingarea add -4.45 -60.00 1213.52 79.41 -60.00 1429.57 copy2_1
tickingarea add 79.41 -60.00 1429.57 149.22 -59.72 1213.40 copy2_2
tickingarea add 149.22 -59.72 1213.40 211.48 -59.72 1429.68 copy2_3

structure load 地图复制2 -10 -60 998