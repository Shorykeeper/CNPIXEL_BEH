tickingarea remove copy1_1
tickingarea remove copy1_2
tickingarea remove copy1_3

tickingarea add -222.56 -60.00 1431.54 -6.61 -60.00 1505.54 copy4_1
tickingarea add -6.61 -60.00 1505.54 -222.50 -60.00 1569.50 copy4_2
tickingarea add -222.50 -60.00 1569.50 -6.43 -60.00 1647.53 copy4_3

structure load 地图复制4 -10 -60 998
