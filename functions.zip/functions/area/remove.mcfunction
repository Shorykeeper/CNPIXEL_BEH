tickingarea remove copy1_1
tickingarea remove copy1_2
tickingarea remove copy1_3

tickingarea remove copy2_1
tickingarea remove copy2_2
tickingarea remove copy2_3

tickingarea remove copy3_1
tickingarea remove copy3_2
tickingarea remove copy3_3

tickingarea remove copy4_1
tickingarea remove copy4_2
tickingarea remove copy4_3