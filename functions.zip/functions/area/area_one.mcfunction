tickingarea add -4.53 -60.00 995.37 78.56 -60.00 1211.50 copy1_1
tickingarea add 78.56 -60.00 1211.50 140.48 -60.00 995.49 copy1_2
tickingarea add 140.48 -60.00 995.49 211.45 -60.00 1211.56 copy1_3
structure load 地图复制1 -10 -60 998
structure load 地图复制1 -10 -60 998