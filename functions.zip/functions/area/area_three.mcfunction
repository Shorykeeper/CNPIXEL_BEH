tickingarea remove copy1_1
tickingarea remove copy1_2
tickingarea remove copy1_3

tickingarea add -4.54 -60.00 1431.63 211.57 -60.00 1501.50 copy3_1
tickingarea add 211.57 -60.00 1501.50 -4.55 -60.00 1573.49 copy3_2
tickingarea add -4.55 -60.00 1573.49 211.60 -60.00 1647.61 copy3_3

structure load 地图复制3 -10 -60 998
