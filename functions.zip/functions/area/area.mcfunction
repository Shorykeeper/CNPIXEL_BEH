
## 执行初始刷新常加载
function area/area_one

## 添加常加载区保障成功复制
execute as @e[name="灯笼节",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_two
execute as @e[name="刀龙",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_two
execute as @e[name="城堡",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_two
execute as @e[name="胜津城",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_two
execute as @e[name="壳",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_two
execute as @e[name="阿尔忒弥斯",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_two
execute as @e[name="拱廊",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_two

execute as @e[name="庇护营地",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_three
execute as @e[name="建筑工地",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_three
execute as @e[name="岸滨",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_three
execute as @e[name="大庙",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_three
execute as @e[name="方碑",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_three
execute as @e[name="伊斯特伍德",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_three
execute as @e[name="航空站",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_three

execute as @e[name="幽兰花",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_four
execute as @e[name="铁索连环",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_four
execute as @e[name="Rise",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_four
execute as @e[name="万圣海盗船",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_four
execute as @e[name="复活节",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_four
execute as @e[name="梦幻林",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run function area/area_four

## 传送重置助手盔甲架




# 1
execute as @e[name=潮起亚细亚,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 -60 995
execute as @e[name=水族馆,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 -9 995
execute as @e[name=入侵,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 42 995
execute as @e[name=通讯站,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 93 995
execute as @e[name=圣诞,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 154 995
execute as @e[name=菌落,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 205 995
execute as @e[name=冰淇淋,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 257 995
# 7

# 8
execute as @e[name=灯笼节,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 257 1213
execute as @e[name=刀龙,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 205 1213
execute as @e[name=城堡,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 154 1213
execute as @e[name=胜津城,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 93 1213
execute as @e[name=壳,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 42 1213
execute as @e[name=阿尔忒弥斯,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 -9 1213
execute as @e[name=拱廊,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 -60 1213
# 14

# 15
execute as @e[name=建筑工地,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 -60 1431
execute as @e[name=庇护营地,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 -9 1431
execute as @e[name=岸滨,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 42 1431
execute as @e[name=方碑,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 93 1431
execute as @e[name=大庙,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 154 1431
execute as @e[name=伊斯特伍德,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 205 1431
# 20

# 21
execute as @e[name=航空站,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -5 268 1432
execute as @e[name=幽兰花,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -223 -60 1431
execute as @e[name=铁索连环,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -223 -9 1431
execute as @e[name=Rise,type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -223 93 1431
execute as @e[name="万圣海盗船",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -223 42 1431
execute as @e[name="复活节",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -223 154 1431
execute as @e[name="梦幻林",type=armor_stand,x=-64,y=-60,z=1010,r=1,tag=选中] at @s run tp @e[name=重置助手,type=armor_stand] -223 205 1431
# 27

## 清除确权盔甲架
kill @e[type=armor_stand,x=-64,y=-60,z=1010,r=1]


