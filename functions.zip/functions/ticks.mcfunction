# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 时间系统 计时器
# 20ticks


#  丨 ----- 计时器 ----- 丨
#  四位正反计时引用
execute if score start B7O14L matches 2 run function system/timer/FourCountTIMER

#  丨 ----- 小文字tips ----- 丨
scoreboard players add tips M3F75C 1
execute if score tips M3F75C matches 90.. run function system/lobby/showTips

#  丨 ----- 检测升级 ----- 丨
execute as @r[scores={E1B36G=5000..}] run function allgames/levelTest

#  丨 ----- 游戏开始倒计时 ----- 丨
#  倒计时效果引用
execute if score start B7O14L matches 1 run function system/timer/countdown
execute if score start B7O14L matches 1 run scoreboard players remove count M3F75C 1
execute if score start B7O14L matches 1 if score rs D1W04T matches 2.. if score count M3F75C matches 1.. run xp -1L @a


# 丨 ----- 时长奖励 ----- 丨
# 统一倒计时 不给各客户端单独计算 我故意的
scoreboard players add reward_time M3F75C 1
execute if score reward_time M3F75C matches 120.. run function system/reward/onlineReward


# 丨 ----- 铁金矿石刷新 ----- 丨
# 激活并引用节点
execute if score start B7O14L matches 2 unless entity @a[tag=winn] run function system/ore/timer/base_ig


#  丨 ----- 玩家救援平台CD递减 ----- 丨
#execute if score start B7O14L matches 2 as @a[scores={N5L93G=0..}] at @s run scoreboard players remove @s N5L93G 1


# 丨 ----- 床保护 ----- 丨
execute if score start B7O14L matches 2 if score 床保护 B7O14L matches 97 unless score mode O8P02W matches 1 unless score mode O8P02W matches 2 run function system/event/race/bedProtectTitle
execute if score start B7O14L matches 2 if score 床保护 B7O14L matches 0 unless score mode O8P02W matches 1 unless score mode O8P02W matches 2 run scoreboard players remove 床保护 B7O14L 1
execute if score start B7O14L matches 2 if score 床保护 B7O14L matches 0 unless score mode O8P02W matches 1 unless score mode O8P02W matches 2 run function system/event/race/bedProtectEnd


# 丨 ----- 治愈池 ----- 丨
#execute if score start B7O14L matches 2 run function global/upgrade/regeneration_pool



damage @a[x=-6,y=120,z=-6,dx=300,dy=-300,dz=300,scores={A1T12P=1..},m=0,tag=!winn] 9999 anvil
execute as @a[x=-6,y=120,z=-6,dx=300,dy=-300,dz=300,m=2,tag=!winn] at @s run function map/spectating
