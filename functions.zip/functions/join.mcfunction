# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 玩家加入房间效果 被BwScript引用 



#初始add 0刷新跨局战绩
execute unless score @s G7C23S >= num_0 B7O14L run execute as @s run function scoreboard/reload

scoreboard players set @s T2R10A 20

scoreboard players add @s S9T03A 0

function _1int1_

scoreboard players reset @s A1T12P

effect @e[type=rabbit] instant_health 99999 255 true

tp @s 2315 240 2285 facing 2311 240 2285

spawnpoint @s 2315 240 2285

title @s times 0 100 0

#teleport
tellraw @s {"rawtext":[{"translate":"style.cnp.teleport.msg"}]}


tellraw @s {"rawtext":[{"text":"§e"}]}
#level reward
tellraw @s[scores={G7C23S=1..}] {"rawtext":[{"translate":"style.cnp.level_reward_main.msg","with":{"rawtext":[{"score":{"objective":"G7C23S","name":"@s"}}]}}]}
tellraw @s[scores={G7C23S=1..}] {"rawtext":[{"translate":"style.cnp.level_reward_click.msg"}]}


titleraw @s title {"rawtext":[{"translate":"style.hyp.playerjoin_title"}]}

titleraw @s subtitle {"rawtext":[{"translate":"style.cnp.playerjoin_subtitle"}]}

# 挂接特殊权限赋值
function account/rightsRegister

