# -*- coding: utf-8 -*-
"""
Created on 2025-11-03
服务端系统
"""
from utils import *
class eid:
    pass


class Main(BaseServer):
    def __init__(self, namespace, systemName):
        super(Main, self).__init__(namespace, systemName)
        self.iron_entities = dict() # type: dict[eid, int]
        self.gold_entities = dict() # type: dict[eid, int]
        self.diamond_entities = dict() # type: dict[eid, int]
        self.emerald_entities = dict() # type: dict[eid, int]
        self.iron_level = 0
        self.gold_level = 0
        self.diamond_level = 0
        self.emerald_level = 0

    def resetAll(self):
        self.iron_level = 0
        self.gold_level = 0
        self.diamond_level = 0
        self.emerald_level = 0
        for eid in self.iron_entities:
            self.DestroyEntity(eid)
        self.iron_entities.clear()
        for eid in self.gold_entities:
            self.DestroyEntity(eid)
        self.gold_entities.clear()
        for eid in self.diamond_entities:
            self.DestroyEntity(eid)
        self.diamond_entities.clear()
        for eid in self.emerald_entities:
            self.DestroyEntity(eid)
        self.emerald_entities.clear()



    @Listen()
    def CustomCommandTriggerServerEvent(self, args):
        command = args["command"]
        variant = args["variant"]
        if command == "countdown":
            if variant == 0:
                self.resetAll()
                args["return_msg_key"] = "重置游戏成功"
            elif variant == 1:
                _type = args["args"][1].get("value")
                if _type == "iron":
                    self.iron_level += 1
                elif _type == "gold":
                    self.gold_level += 1
                elif _type == "diamond":
                    self.diamond_level += 1
                elif _type == "emerald":
                    self.emerald_level += 1
                args["return_msg_key"] = "升级成功"

    @Listen()
    def EntityDefinitionsEventServerEvent(self, args):
        eid = args["entityId"]
        if args["eventName"] == "minecrafts:res_tick":
            e_type = CF.CreateEngineType(eid).GetEngineTypeStr()
            if e_type == "minecrafts:iron_spawner":
                timer = self.getTimer(e_type)
                if eid in self.iron_entities:
                    tick = self.iron_entities[eid]
                    self.iron_entities[eid] -= 0.5
                    if tick <= 0:
                        self.summonIron(eid)
                        self.iron_entities[eid] = timer
                else:
                    self.iron_entities[eid] = timer
            elif e_type == "minecrafts:gold_spawner":
                timer = self.getTimer(e_type)
                if eid in self.gold_entities:
                    tick = self.gold_entities[eid]
                    self.gold_entities[eid] -= 0.5
                    if tick <= 0:
                        self.summonGold(eid)
                        self.gold_entities[eid] = timer
                else:
                    self.gold_entities[eid] = timer
            elif e_type == "minecrafts:diamond_spawner":
                timer = self.getTimer(e_type)
                if eid in self.diamond_entities:
                    tick = self.diamond_entities[eid]
                    self.diamond_entities[eid] -= 1
                    NameComp(eid).SetName(diamond_show_text % tick)
                    if tick <= 0:
                        self.summonDiamond(eid)
                        self.diamond_entities[eid] = timer
                else:
                    self.diamond_entities[eid] = timer
            elif e_type == "minecrafts:emerald_spawner":
                timer = self.getTimer(e_type)
                if eid in self.emerald_entities:
                    tick = self.emerald_entities[eid]
                    self.emerald_entities[eid] -= 1
                    NameComp(eid).SetName(emerald_show_text % tick)
                    if tick <= 0:
                        self.summonEmerald(eid)
                        self.emerald_entities[eid] = timer
                else:
                    self.emerald_entities[eid] = timer

    def summonIron(self, eid):
        """
        生成钻石
        """
        if self.iron_level == 2:
            self.summon_resource(eid, "minecraft:iron_ingot", iron_max, 2)
        else:
            self.summon_resource(eid, "minecraft:iron_ingot", iron_max)

    def summonGold(self, eid):
        """
        生成绿宝石
        """
        self.summon_resource(eid, "minecraft:gold_ingot", gold_max)

    def summonDiamond(self, eid):
        """
        生成钻石
        """
        self.summon_resource(eid, "minecraft:diamond", diamond_max)

    def summonEmerald(self, eid):
        """
        生成绿宝石
        """
        self.summon_resource(eid, "minecraft:emerald", emerald_max)

    def summon_resource(self, eid, item, max_num, count=1):
        """
        生成资源
        """
        itemDict = {
            'newItemName': item,  # 必须设置，物品的identifier，即"命名空间:物品名"
            'count': count,  # 必须设置，物品数量。设置为0时为空物品
            'newAuxValue': 0,  # 必须设置，物品附加值
        }
        pos = PosComp(eid).GetPos()
        if not pos:
            return
        item_num, player_list = self.TestSquareAreaEntities(pos, itemDict['newItemName'])
        if player_list and (item in ["minecraft:iron_ingot", "minecraft:gold_ingot"]):
            for pid in player_list:
                ItemComp(pid).SpawnItemToPlayerInv(itemDict, pid)
                self.NotifyToClient(pid, "play_sound", {"name": "random.pop", "pitch": random.randint(5, 17) * 0.1, "volume": 0.1})
            return
        if item_num < max_num:
            ItemComp(LevelId).SpawnItemToLevel(itemDict, 0, pos)

    def TestSquareAreaEntities(self, pos, item):
        """
        测试资源区域实体
        """
        startPos = (pos[0] - 1, pos[1], pos[2] - 1)
        endPos = (pos[0] + 1, pos[1] + 4, pos[2] + 1)
        entity_list = Game.GetEntitiesInSquareArea(None, startPos, endPos, 0)
        item_num = 0
        for item_id in entity_list:
            item_dict = CF.CreateItem(LevelId).GetDroppedItem(item_id)
            if item_dict:
                if item_dict['newItemName'] == item:
                    item_num += item_dict['count']
        return item_num, [pid for pid in serverApi.GetPlayerList() if pid in entity_list]

    def getTimer(self, _type):
        if _type == "minecrafts:iron_spawner":
            return iron_timer[self.iron_level]
        if _type == "minecrafts:gold_spawner":
            return gold_timer[self.gold_level]
        if _type == "minecrafts:diamond_spawner":
            return diamond_timer[self.diamond_level]
        if _type == "minecrafts:emerald_spawner":
            return emerald_timer[self.emerald_level]
        return 0


