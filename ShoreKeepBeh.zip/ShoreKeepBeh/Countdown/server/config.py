# coding=utf-8
modName = "Countdown"
version = "0.0.1"
systemName = "main"

diamond_timer = { # level: time
    0: 30,
    1: 25,
    2: 20
}
diamond_max = 8
diamond_show_text = "§e将在 §c%s §e秒后产出"
emerald_timer = {
    0: 45,
    1: 40,
    2: 35
}
emerald_max = 4
emerald_show_text = "§e将在 §c%s §e秒后产出"
iron_timer = {
    0: 1,
    1: 0.5,
    2: 0.5
}
iron_max = 76
gold_timer = {
    0: 5,
    1: 3,
    2: 2.5
}
gold_max = 12