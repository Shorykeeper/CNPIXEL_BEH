# coding=utf-8
modName = "Countdown"
version = "0.0.1"
systemName = "main"
