# -*- encoding: utf-8 -*-
from ..__init__ import *
import time, math, mod.client.extraClientApi as clientApi
import mod.common.minecraftEnum as enum
from mod_log import logger as logger
from ..config.modConfig import *
from ..listen.listen import Listen, server, client, EventPriority
from .BaseListener import *
ClientSystem = clientApi.GetClientSystemCls()
CF = clientApi.GetEngineCompFactory()
levelId = clientApi.GetLevelId()
playerId = clientApi.GetLocalPlayerId()
textBoardComp = CF.CreateTextBoard(playerId)
posComp = CF.CreatePos(playerId)
music = CF.CreateCustomAudio(levelId)
game = CF.CreateGame(levelId)
NameComp = lambda playerID: CF.CreateName(playerID)  # type: playerID:(str or int)
Name = NameComp(playerId).GetName()

