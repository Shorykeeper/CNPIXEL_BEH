# -*- coding: utf-8 -*-

from utils import *

CustomUIScreenProxy = clientApi.GetUIScreenProxyCls()
path = "variables_button_mappings_and_controls/safezone_screen_matrix/inner_matrix/safezone_screen_panel/root_screen_panel"
PATH_LIST = [
"/base_panel/hotbar_and_panels/gamepad_helper_border/both_panels/left_tab_navigation_panel_pocket/content/search_tab_panel",  # 搜索
"/base_panel/hotbar_and_panels/gamepad_helper_border/both_panels/left_tab_navigation_panel_pocket/content/equipment_tab_panel",  # 装备
"/base_panel/hotbar_and_panels/gamepad_helper_border/both_panels/left_tab_navigation_panel_pocket/content/construction_tab_panel",  # 建筑
"/base_panel/hotbar_and_panels/gamepad_helper_border/both_panels/left_tab_navigation_panel_pocket/content/items_tab_panel",  # 物品
"/base_panel/hotbar_and_panels/gamepad_helper_border/both_panels/left_tab_navigation_panel_pocket/content/nature_tab_panel",  # 自然
"/base_panel/hotbar_and_panels/gamepad_helper_border/both_panels/left_panel/recipe_book_tab_content/tab_content_search_bar_panel/scroll_pane",  # 物品网格
"/base_panel/hotbar_and_panels/gamepad_helper_border/both_panels/right_panel/crafting_tab_content/content", # 合成烂
]

class Main(CustomUIScreenProxy):
    def __init__(self, screenName, screenNode):
        CustomUIScreenProxy.__init__(self, screenName, screenNode)
        self.client = weakref.proxy(clientApi.GetSystem(modName, "main"))

    def OnCreate(self):
        screen = self.GetScreenNode()
        visible = False
        gameType = game.GetPlayerGameType(playerId)
        if gameType == enum.GameType.Creative:
            visible = True
        for child_path in PATH_LIST:
            Control = screen.GetBaseUIControl(path + child_path)
            if Control:
                Control.SetVisible(visible)

        def parterner_tab(visible):
            Control = screen.GetBaseUIControl(path + "/base_panel/hotbar_and_panels/gamepad_helper_border/both_panels/right_tab_navigation_panel_pocket/content/parterner_tab")
            if Control:
                Control.SetVisible(visible)

        game.AddTimer(0.1, parterner_tab, visible)

    def OnDestroy(self):
        """
        @description UI销毁时调用
        """

