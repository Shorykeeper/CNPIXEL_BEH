# -*- coding: utf-8 -*-

from utils import *

CustomUIScreenProxy = clientApi.GetUIScreenProxyCls()
path = "variables_button_mappings_and_controls/safezone_screen_matrix/inner_matrix/safezone_screen_panel/root_screen_panel"
PATH_LIST = [
"/content_stack_panel/recipe_book/tab_navigation_panel",  #
"/content_stack_panel/recipe_book/tab_content_panel/tab_content_search_bar_panel/scroll_pane",
"/content_stack_panel/player_inventory/inventory_panel_top_half/crafting_panel",  # 合成栏
]

class Main(CustomUIScreenProxy):
    def __init__(self, screenName, screenNode):
        CustomUIScreenProxy.__init__(self, screenName, screenNode)
        self.client = weakref.proxy(clientApi.GetSystem(modName, "main"))

    def OnCreate(self):
        screen = self.GetScreenNode()
        visible = False
        gameType = game.GetPlayerGameType(playerId)
        if gameType == enum.GameType.Creative:
            visible = True
        for child_path in PATH_LIST:
            Control = screen.GetBaseUIControl(path + child_path)
            if Control:
                Control.SetVisible(visible)

        def parterner_tab(visible):
            Control = screen.GetBaseUIControl(path + "/content_stack_panel/toolbar_anchor/toolbar_panel/toolbar_background/toolbar_stack_panel/parterner_tab_layout_toggle_panel")
            if Control:
                Control.SetVisible(visible)

        game.AddTimer(0.1, parterner_tab, visible)

    def OnDestroy(self):
        """
        @description UI销毁时调用
        """

