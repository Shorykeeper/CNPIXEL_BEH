# coding=utf-8
"""
Created on 2025/5/9
背包界面控制器
这里主要 注册 背包界面代理
接口：
- 无
"""

from ..utils import *


class inventoryUIController(BaseModule):

    def __init__(self):
        super(inventoryUIController, self).__init__()


    @Listen.on(client.UiInitFinished)
    def init_ui(self, args):
        """
        可以创建UI
        """
        # 给原生聊天界面注册委托
        clientApi.GetNativeScreenManagerCls().instance().RegisterScreenProxy(
                                                "crafting.inventory_screen",
                                                "NoCrafting.client.ui.inventory_ui.Main"
                                                )
        clientApi.GetNativeScreenManagerCls().instance().RegisterScreenProxy(
                                                "crafting_pocket.inventory_screen_pocket",
                                                "NoCrafting.client.ui.inventory_ui_pocket.Main"
                                                )


