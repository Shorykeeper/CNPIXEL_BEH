# -*- coding: utf-8 -*-
"""
Created on 2024/9/29

"""
from utils import *
from BaseClientSystem import BaseClientSystem
from controller.inventoryUIController import inventoryUIController


class Main(BaseClientSystem):
    def __init__(self, namespace, systemName):
        super(Main, self).__init__(namespace, systemName)
        self.inventoryUIController = None

    @Listen.on(client.LoadClientAddonScriptsAfter)
    def server_load_addon_scripts_after(self, args):
        self.register_controller()

    def register_controller(self):
        self.inventoryUIController = inventoryUIController()
