# -*- coding: utf-8 -*-
# 以下为MOD配置信息
modName = "NoCrafting"
version = "0.0.1"
systemName = "main"

debug = True  # 是否开启调试模式\
