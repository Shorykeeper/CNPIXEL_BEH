# -*- encoding: utf-8 -*-
import random, time, mod.server.extraServerApi as serverApi, mod.common.minecraftEnum as Enum
from mod_log import logger as logger
from ..config.modConfig import *
from ..listen.listen import Listen, server, client, EventPriority
from .BaseListener import *
ServerSystem = serverApi.GetServerSystemCls()
EngineComponent = serverApi.GetEngineCompFactory()
SF = serverApi.GetEngineCompFactory()
levelId = serverApi.GetLevelId()

game = SF.CreateGame(levelId)
commandComp = SF.CreateCommand(levelId)
BlockComp = SF.CreateBlockInfo(levelId)
ChestBlockComp = SF.CreateChestBlock(levelId)
posComp = SF.CreatePos
rotComp = SF.CreateRot
itemComp = SF.CreateItem
nameComp = SF.CreateName
dataComp = SF.CreateExtraData
msgComp = SF.CreateMsg
