# -*- coding: utf-8 -*-

from utils import *
from BaseServerSystem import BaseServerSystem


class Main(BaseServerSystem):
    def __init__(self, namespace, systemName):
        super(Main, self).__init__(namespace, systemName)

    @Listen.on(server.LoadServerAddonScriptsAfter)
    def server_load_addon_scripts_after(self, args):
        self.register_controller()

    def register_controller(self):
        pass
