# -*- coding: utf-8 -*-
FASTBUILD_TAG = 'fastbuild'
CAN_FASTBUILD_TAG = 'canFastbuild'