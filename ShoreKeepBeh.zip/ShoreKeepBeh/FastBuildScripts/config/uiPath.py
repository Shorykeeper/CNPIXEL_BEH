# -*- coding: utf-8 -*-

BASE_PATH = '/variables_button_mappings_and_controls/safezone_screen_matrix/inner_matrix/safezone_screen_panel/root_screen_panel'
TOGGLE = BASE_PATH + '/switch_toggle'
