# -*- coding: utf-8 -*-

DEFAULT = '§l§a| §r快速搭路§7 >> §r'
