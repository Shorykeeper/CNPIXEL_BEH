# -*- coding: utf-8 -*-

MOD_ATTR_KEY = 'CanUseFastbuild'
