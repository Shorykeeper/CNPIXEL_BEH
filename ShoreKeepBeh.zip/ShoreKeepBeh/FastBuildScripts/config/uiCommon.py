# -*- coding: utf-8 -*-
from .file import *

UI_NAME = 'fastbuildUi'
CLS_PATH = DIR_ROOT + '.system.ui.main.Main'
SCREEN_PATH = UI_NAME + '.main'
CREATE_PARAM = {'isHud': 1}
