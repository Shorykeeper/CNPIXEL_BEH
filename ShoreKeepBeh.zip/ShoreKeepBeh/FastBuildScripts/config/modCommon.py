# -*- coding: utf-8 -*-
MOD_NAME = 'com.fastbuild.console'
MOD_NAMESPACE = ''
VERSION = '0.0.1'