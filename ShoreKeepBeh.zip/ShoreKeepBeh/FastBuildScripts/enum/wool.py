# -*- coding: utf-8 -*-

class Wool(object):
    # 黑色羊毛
    BLACK_WOOL = 'minecraft:black_wool'
    # 蓝色羊毛
    BLUE_WOOL = 'minecraft:blue_wool'
    # 棕色羊毛
    BROWN_WOOL = 'minecraft:brown_wool'
    # 青色羊毛
    CYAN_WOOL = 'minecraft:cyan_wool'
    # 灰色羊毛
    GRAY_WOOL = 'minecraft:gray_wool'
    # 绿色羊毛
    GREEN_WOOL = 'minecraft:green_wool'
    # 浅蓝色羊毛
    LIGHT_BLUE_WOOL = 'minecraft:light_blue_wool'
    # 浅灰色羊毛
    LIGHT_GRAY_WOOL = 'minecraft:light_gray_wool'
    # 酸橙绿羊毛
    LIME_WOOL = 'minecraft:lime_wool'
    # 品红色羊毛
    MAGENTA_WOOL = 'minecraft:magenta_wool'
    # 橙色羊毛
    ORANGE_WOOL = 'minecraft:orange_wool'
    # 粉色羊毛
    PINK_WOOL = 'minecraft:pink_wool'
    # 紫色羊毛
    PURPLE_WOOL = 'minecraft:purple_wool'
    # 红色羊毛
    RED_WOOL = 'minecraft:red_wool'
    # 白色羊毛
    WHITE_WOOL = 'minecraft:white_wool'
    # 黄色羊毛
    YELLOW_WOOL = 'minecraft:yellow_wool'
    # 全部羊毛
    WOOL_LIST = [BLACK_WOOL, BLUE_WOOL, BROWN_WOOL, CYAN_WOOL, GRAY_WOOL, GREEN_WOOL, LIGHT_BLUE_WOOL, LIGHT_GRAY_WOOL,
                 LIME_WOOL, MAGENTA_WOOL, ORANGE_WOOL, PINK_WOOL, PURPLE_WOOL, RED_WOOL, WHITE_WOOL, YELLOW_WOOL]