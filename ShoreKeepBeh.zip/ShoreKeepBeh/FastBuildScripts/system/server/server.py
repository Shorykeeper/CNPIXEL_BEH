# -*- coding: utf-8 -*-
from ...config.configUtils import *
from ...constant.serverConstant import *
from ...enum.wool import Wool
from ...library.consoleLib.serverApi import *
from ...library.consoleMod.config.configUtils import CONSOLE_MOD_MOD_NAME, CONSOLE_MOD_SERVER_SYSTEM_NAME, \
    CONSOLE_MOD_CLIENT_SYSTEM_NAME
from ...library.consoleMod.serverApi import Listen

serverSystem = serverApi.GetSystem(CONSOLE_MOD_MOD_NAME, CONSOLE_MOD_SERVER_SYSTEM_NAME)

NotifyToClient = serverSystem.NotifyToClient


@Listen(namespace=CONSOLE_MOD_MOD_NAME, systemName=CONSOLE_MOD_CLIENT_SYSTEM_NAME)
def ClientTouchToggleEvent(args):
    pid = args['pid']
    state = args['state']
    if not TagComp(pid).EntityHasTag(FASTBUILD_TAG) and state:
        # 玩家没有fastbuild标签
        GameComp(LEVEL_ID).SetOneTipMessage(pid, '非疾速模式无法使用疾速模式建桥模式')
        NotifyToClient(pid, 'ServerCloseToggleEvent', {})
        return
    if state:
        TagComp(pid).AddEntityTag(CAN_FASTBUILD_TAG)
    else:
        TagComp(pid).RemoveEntityTag(CAN_FASTBUILD_TAG)
    GameComp(LEVEL_ID).SetOnePopupNotice(pid, '',
                                         '{}§l快速搭路已{}'.format(ENUM.ColorCode.GREEN if state else ENUM.ColorCode.RED,
                                                                 '开启' if state else '关闭'))
    RunCommand('/playsound random.orb @s', pid)


@Listen
def EntityPlaceBlockAfterServerEvent(args):
    pid = args['entityId']
    blockId = args['fullName']
    x = args['x']
    y = args['y']
    z = args['z']
    dimensionId = args['dimensionId']
    face = args['face']
    if blockId in Wool.WOOL_LIST:
        if not TagComp(pid).EntityHasTag(CAN_FASTBUILD_TAG):
            return
        reach = ModAttrComp(pid).GetAttr(MOD_ATTR_KEY, 7)
        FACING_CONFIG = {
            ENUM.Facing.Up: ('y', y + 1, y + reach + 1, 1),
            ENUM.Facing.Down: ('y', y - 1, y - reach - 1, -1),
            ENUM.Facing.North: ('z', z - 1, z - reach - 1, -1),
            ENUM.Facing.South: ('z', z + 1, z + reach + 1, 1),
            ENUM.Facing.West: ('x', x - 1, x - reach - 1, -1),
            ENUM.Facing.East: ('x', x + 1, x + reach + 1, 1)
        }

        # 无效朝向 直接返回
        if face not in FACING_CONFIG:
            return

        # 获取当前朝向的坐标配置
        axis, start, end, step = FACING_CONFIG[face]

        # 生成正确坐标列表
        posList = []
        # 计算坐标
        for val in range(start, end, step):
            pos = (val, y, z) if axis == 'x' else (x, val, z) if axis == 'y' else (x, y, val)
            posList.append(pos)
        # repeatedList是一个列表 内部为空字符串
        # len(repeatedList)用于计算已经放置的次数 从0开始
        repeatedList = []
        timer = None

        # 计时器函数
        def SetBlock():
            repeatedTimes = len(repeatedList)

            # 达到最大放置数量 取消定时器
            if repeatedTimes >= reach:
                GameComp(LEVEL_ID).CancelTimer(timer)
                return

            repeatedList.append('')
            currentPos = posList[repeatedTimes]
            # 检查障碍物
            blockIdNew = BlockInfoComp.GetBlockNew(currentPos, dimensionId)['name']
            entities = GameComp(LEVEL_ID).GetEntitiesInSquareArea(None, currentPos,
                                                                  (currentPos[0] + 1, currentPos[1] + 1,
                                                                   currentPos[2] + 1), dimensionId)
            if blockIdNew != 'minecraft:air' or entities:
                GameComp(LEVEL_ID).CancelTimer(timer)
                return
            BlockInfoComp.SetBlockNew(currentPos, {'name': blockId}, 0, dimensionId, True, False)

        # 创建定时器
        timer = GameComp(LEVEL_ID).AddRepeatedTimer(0.08, SetBlock)

@Listen
def PlayerIntendLeaveServerEvent(args):
    pid = args['playerId']
    TagComp(pid).RemoveEntityTag(CAN_FASTBUILD_TAG)

@Listen
def CustomCommandTriggerServerEvent(args):
    commandName = args['command']
    origin = args['origin']  # type: dict
    param = args['args']
    if commandName == 'fastbuild':
        if not IsRunByPlayer(args):
            args['return_failed'] = True
            args['return_msg_key'] = '该指令在命令方块中不能使用'
            return
        pid = origin['entityId']
        reach = param[0]['value']
        if reach < 2 or reach > 10:
            # 这里给玩家发送一个信息(CommandBlockFeedback是关闭的)
            SendMessageToPlayer(pid, '指令执行失败 只能设置2-10的数字 默认7')
            return

        SendMessageToPlayer(pid, '{}已将自动搭路长度设为{}'.format(DEFAULT, reach))
        ModAttrComp(pid).SetAttr(MOD_ATTR_KEY, reach, True, True)
