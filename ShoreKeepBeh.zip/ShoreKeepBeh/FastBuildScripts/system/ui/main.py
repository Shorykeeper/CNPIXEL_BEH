# -*- coding: utf-8 -*-
from ...constant.clientConstant import *
from ...library.consoleMod.config.configUtils import CONSOLE_MOD_MOD_NAME, CONSOLE_MOD_CLIENT_SYSTEM_NAME

__buttonList = []

screenNode = clientApi.GetScreenNodeCls()
ViewBinder = clientApi.GetViewBinderCls()
clientSystem = clientApi.GetSystem(CONSOLE_MOD_MOD_NAME, CONSOLE_MOD_CLIENT_SYSTEM_NAME)

NotifyToServer = clientSystem.NotifyToServer


def AddButtonTouchEvent(path, param={'isSwallow': True}):
    def __wrapper(func):
        __buttonList.append((path, func.__name__, param))
        return func

    return __wrapper


def InitButton(instance):
    for path, callback, param in __buttonList:
        control = instance.GetBaseUIControl(path).asButton()
        control.AddTouchEventParams(param)
        control.SetButtonTouchDownCallback(getattr(instance, callback))


class Main(screenNode):
    def __init__(self, namespace, name, param):
        screenNode.__init__(self, namespace, name, param)

    def Create(self):
        pass

    @ViewBinder.binding(ViewBinder.BF_ToggleChanged, '#openToggle')
    def ToggleChangedCallBack(self, args):
        state = args['state']
        clientSystem.NotifyToServer('ClientTouchToggleEvent', {'pid': PLAYER_ID, 'state': state})

    def Destroy(self):
        pass

    def Update(self):
        pass
