# -*- coding: utf-8 -*-
from mod.client.ui.screenNode import ScreenNode

from ...config.configUtils import *
from ...constant.clientConstant import *
from ...enum.wool import Wool
from ...library.consoleMod.clientApi import Listen
from ...library.consoleMod.config.configUtils import CONSOLE_MOD_MOD_NAME, CONSOLE_MOD_CLIENT_SYSTEM_NAME, \
    CONSOLE_MOD_SERVER_SYSTEM_NAME

clientSystem = clientApi.GetSystem(CONSOLE_MOD_MOD_NAME, CONSOLE_MOD_CLIENT_SYSTEM_NAME)

NotifyToServer = clientSystem.NotifyToServer

uiNode = None  # type: None | ScreenNode
timeCounter = 0


@Listen
def UiInitFinished(_):
    # 注册UI
    clientApi.RegisterUI(MOD_NAME, UI_NAME, CLS_PATH, SCREEN_PATH)
    global uiNode
    uiNode = clientApi.CreateUI(MOD_NAME, UI_NAME, CREATE_PARAM)
    uiNode.SetScreenVisible(False)


# 同时绑定2个事件
@Listen('OnKeyPressInGame')
@Listen('OnGamepadKeyPressClientEvent')
def TouchToggleEvent(args):
    if uiNode is None:
        return
    # 判断玩家当前的界面
    screenName = clientApi.GetTopUI()
    if screenName != 'hud_screen':
        return
    key = args['key']
    isDown = args['isDown']
    if isDown == '1':
        if int(key) == ENUM.KeyBoardType.KEY_F or int(key) == ENUM.GamepadKeyType.TRIGGER_LEFT: # KEY_F
            itemDict = ItemComp.GetCarriedItem()
            if itemDict:
                if itemDict['newItemName'] in Wool.WOOL_LIST:
                    toggle = uiNode.GetBaseUIControl(TOGGLE).asSwitchToggle()
                    toggle.SetToggleState(not toggle.GetToggleState())


@Listen(namespace=CONSOLE_MOD_MOD_NAME, systemName=CONSOLE_MOD_SERVER_SYSTEM_NAME)
def ServerCloseToggleEvent(_):
    # 关闭toggle
    uiNode.GetBaseUIControl(TOGGLE).asSwitchToggle().SetToggleState(False)


def Update():
    if uiNode is None:
        return
    global timeCounter
    timeCounter += 1
    if timeCounter == 4:
        timeCounter = 0
        itemDict = ItemComp.GetCarriedItem()
        # 手中有物品
        if itemDict is not None:
            if itemDict['newItemName'] in Wool.WOOL_LIST:
                uiNode.SetScreenVisible(True)
            else:
                uiNode.SetScreenVisible(False)
        else:
            uiNode.SetScreenVisible(False)


clientSystem.Update = Update
