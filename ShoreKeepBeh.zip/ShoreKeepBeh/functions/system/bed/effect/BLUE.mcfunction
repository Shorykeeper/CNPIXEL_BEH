# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 蓝队床被破坏

#   --% 文件的名等同于脚本逻辑何床所破
#   --% 在此骄傲一下我的format小巧思

## 播放音效
#蓝 无床音
execute as @a[scores={A1T12P=2}] at @s run playsound mob.wither.death @s ~~~
#其他 床音
execute as @a[scores={A1T12P=!2}] at @s run playsound mob.enderdragon.growl @s ~~12~

## 清除被破床队陷阱 这里是 -> 蓝队
scoreboard players reset blue W4G21E

## 更改显示 取消有床状态
tag @e[name="§a✔"] remove btbeds
tag @e[name="§c✘"] add btbeds

## 告诉同志们个好消息
# 无床人的msg
execute if score @p[tag=desb_BLUE] A1T12P matches 1 run tellraw @a[scores={A1T12P=2},tag=language] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.hyp.own_bed_dest.msg","with":{"rawtext":[{"translate":"§c%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}
execute if score @p[tag=desb_BLUE] A1T12P matches 3 run tellraw @a[scores={A1T12P=2},tag=language] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.hyp.own_bed_dest.msg","with":{"rawtext":[{"translate":"§a%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}
execute if score @p[tag=desb_BLUE] A1T12P matches 4 run tellraw @a[scores={A1T12P=2},tag=language] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.hyp.own_bed_dest.msg","with":{"rawtext":[{"translate":"§e%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}

execute if score @p[tag=desb_BLUE] A1T12P matches 1 run tellraw @a[scores={A1T12P=2},tag=语言] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.cnp.own_bed_dest.msg","with":{"rawtext":[{"translate":"§c%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}
execute if score @p[tag=desb_BLUE] A1T12P matches 3 run tellraw @a[scores={A1T12P=2},tag=语言] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.cnp.own_bed_dest.msg","with":{"rawtext":[{"translate":"§a%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}
execute if score @p[tag=desb_BLUE] A1T12P matches 4 run tellraw @a[scores={A1T12P=2},tag=语言] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.cnp.own_bed_dest.msg","with":{"rawtext":[{"translate":"§e%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}

# 其他人的msg
execute if score @p[tag=desb_BLUE] A1T12P matches 1 run tellraw @a[scores={A1T12P=!2},tag=语言] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.cnp.bed_dest_blue.msg","with":{"rawtext":[{"translate":"§c%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}
execute if score @p[tag=desb_BLUE] A1T12P matches 3 run tellraw @a[scores={A1T12P=!2},tag=语言] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.cnp.bed_dest_blue.msg","with":{"rawtext":[{"translate":"§a%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}
execute if score @p[tag=desb_BLUE] A1T12P matches 4 run tellraw @a[scores={A1T12P=!2},tag=语言] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.cnp.bed_dest_blue.msg","with":{"rawtext":[{"translate":"§e%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}

execute if score @p[tag=desb_BLUE] A1T12P matches 1 run tellraw @a[scores={A1T12P=!2},tag=language] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.hyp.bed_dest_blue.msg","with":{"rawtext":[{"translate":"§c%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}
execute if score @p[tag=desb_BLUE] A1T12P matches 3 run tellraw @a[scores={A1T12P=!2},tag=language] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.hyp.bed_dest_blue.msg","with":{"rawtext":[{"translate":"§a%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}
execute if score @p[tag=desb_BLUE] A1T12P matches 4 run tellraw @a[scores={A1T12P=!2},tag=language] {"rawtext":[{"translate":"\n%%s\n ","with":{"rawtext":[{"translate":"style.hyp.bed_dest_blue.msg","with":{"rawtext":[{"translate":"§e%%s§7","with":{"rawtext":[{"selector":"@s"}]}}]}}]}}]}

#无床人的title+subtitle
titleraw @a[scores={A1T12P=2},tag=language] title {"rawtext":[{"translate":"style.hyp.bed_dest.title"}]}
titleraw @a[scores={A1T12P=2},tag=语言] title {"rawtext":[{"translate":"style.cnp.bed_dest.title"}]}

titleraw @a[scores={A1T12P=2},tag=language] subtitle {"rawtext":[{"translate":"style.hyp.bed_dest.subtitle"}]}
titleraw @a[scores={A1T12P=2},tag=语言] subtitle {"rawtext":[{"translate":"style.cnp.bed_dest.subtitle"}]}

## 给无床人无床tag
tag @a[scores={A1T12P=2}] add 无床

## 给破床人奖励
execute as @p[tag=desb_BLUE] at @s run function global/reward/desbed

## 破床人清除标签
tag @p[tag=desb_BLUE] remove desb_BLUE





