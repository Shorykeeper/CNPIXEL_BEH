# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 铁基础计时-一完整秒一次
# @TeamCode: 1R 2B 3G 4Y

#==================================================
# 铁矿刷新逻辑（按等级处理）
#==================================================

# 1 基础刷新一次
execute unless entity @a[tag=winn] as @e[tag=iron_spawn,scores={Y9V88N=1..}] at @s run function global/ore/request/iron

# 2 额外一次 1+1
execute unless entity @a[tag=winn] as @e[tag=iron_spawn,scores={Y9V88N=2}] at @s run function global/ore/request/iron

# 3-4 额外两次 1+2
execute unless entity @a[tag=winn] as @e[tag=iron_spawn,scores={Y9V88N=3..4}] at @s run function global/ore/request/iron
execute unless entity @a[tag=winn] as @e[tag=iron_spawn,scores={Y9V88N=3..4}] at @s run function global/ore/request/iron

# 5 再额外三次 1+3
execute unless entity @a[tag=winn] as @e[tag=iron_spawn,scores={Y9V88N=5}] at @s run function global/ore/request/iron
execute unless entity @a[tag=winn] as @e[tag=iron_spawn,scores={Y9V88N=5}] at @s run function global/ore/request/iron
execute unless entity @a[tag=winn] as @e[tag=iron_spawn,scores={Y9V88N=5}] at @s run function global/ore/request/iron
