# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 金基础计时 
# @TeamCode: 1R 2B 3G 4Y

# 基础刷新一次
execute as @e[name="§b",tag=iron_spawn,scores={Y9V88N=1..}] at @s run function global/ore/request/gold

# 2 额外一次 1+1
execute as @e[name="§b",tag=iron_spawn,scores={Y9V88N=2}] at @s run function global/ore/request/gold

# 3 额外两次 1+2
execute as @e[name="§b",tag=iron_spawn,scores={Y9V88N=3}] at @s run function global/ore/request/gold
execute as @e[name="§b",tag=iron_spawn,scores={Y9V88N=3}] at @s run function global/ore/request/gold

# 4 额外两次 1+2
execute as @e[name="§b",tag=iron_spawn,scores={Y9V88N=4}] at @s run function global/ore/request/gold
execute as @e[name="§b",tag=iron_spawn,scores={Y9V88N=4}] at @s run function global/ore/request/gold

# 4 以上计算绿宝石
execute as @e[name="§b",tag=iron_spawn,scores={Y9V88N=4..5}] at @s run scoreboard players add @s W4G21E 1
execute as @e[name="§b",tag=iron_spawn,scores={Y9V88N=4..5}] at @s if score @s W4G21E >= num_9 B7O14L run structure load "emerald" ~~~
execute as @e[name="§b",tag=iron_spawn,scores={Y9V88N=4..5,W4G21E=9..}] at @s run scoreboard players reset @s W4G21E

# 5 再额外三次 1+3
execute as @e[name="§b",tag=iron_spawn,scores={Y9V88N=5}] at @s run function global/ore/request/gold
execute as @e[name="§b",tag=iron_spawn,scores={Y9V88N=5}] at @s run function global/ore/request/gold
execute as @e[name="§b",tag=iron_spawn,scores={Y9V88N=5}] at @s run function global/ore/request/gold

