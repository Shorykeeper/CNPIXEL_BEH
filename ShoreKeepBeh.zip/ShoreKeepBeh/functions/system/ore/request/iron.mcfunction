# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 刷铁验证

# 先给所有符合条件的实体分数+1
scoreboard players add @s G6Y81U 1

# 没超量的实体真正生成(max+1)
execute as @s unless score @s G6Y81U matches 77.. run function global/ore/load/load_i

execute as @s if entity @a[r=3] run scoreboard players set @s G6Y81U 0

execute as @s if entity @a[r=3] run scoreboard players set @s Z4T27M 0
