# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 刷金验证


# 先给所有符合条件的实体分数+1
scoreboard players add @s Z4T27M 1

# 没超量的实体真正生成(max+1)
execute as @s unless score @s Z4T27M matches 13.. run function global/ore/load/load_g

