
tellraw @s[tag=language] {"rawtext":[{"text":"§e"}]}
##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.chatChannelTipsOnStart.msg"}]}
##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.chatChannelTipsOnStart.msg"}]}
