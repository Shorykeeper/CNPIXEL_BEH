

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.crime_cmd_banned.msg"}]}

##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.crime_cmd_banned.msg"}]}

