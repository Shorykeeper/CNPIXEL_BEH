
##英原生
tellraw @a[tag=language] {"rawtext":[{"translate":"style.hyp.time_reward_experience.msg"}]}
tellraw @a[tag=language] {"rawtext":[{"translate":"style.hyp.time_reward_coin.msg"}]}
##中汉化
tellraw @a[tag=语言] {"rawtext":[{"translate":"style.cnp.time_reward_experience.msg"}]}
tellraw @a[tag=语言] {"rawtext":[{"translate":"style.cnp.time_reward_coin.msg"}]}
#加硬币
scoreboard players add @a Q0A59I 8
#加经验
scoreboard players add @a E1B36G 25
#归零时间
scoreboard players set reward_time M3F75C 0
