

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.victory_reward_coin.msg"}]}

##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.victory_reward_coin.msg"}]}

scoreboard players add @s 落月币 10
