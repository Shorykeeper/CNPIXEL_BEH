

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.hit_npc_failed.msg"}]}

##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.hit_npc_failed.msg"}]}

