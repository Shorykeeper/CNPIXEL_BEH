

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.fk_reward_coin.msg"}]}

##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.fk_reward_coin.msg"}]}

#加普通最终击杀
scoreboard players add @s G2L41J 1
#加生涯最终击杀
scoreboard players add @s C4D31J 1

#加硬币
scoreboard players add @s Q0A59I 5

scoreboard players add @s 落月币 3

#音效
playsound random.levelup @s
playsound random.hurt @s

