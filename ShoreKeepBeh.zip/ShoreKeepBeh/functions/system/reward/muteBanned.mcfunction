

tellraw @s {"rawtext":[{"text":"§f"}]}

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.muteBanned_warning.msg"}]}

##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.muteBanned_warning.msg"}]}

