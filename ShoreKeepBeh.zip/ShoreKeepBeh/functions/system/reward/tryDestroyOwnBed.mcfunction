

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.des_self_bed.msg"}]}

##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.des_self_bed.msg"}]}




