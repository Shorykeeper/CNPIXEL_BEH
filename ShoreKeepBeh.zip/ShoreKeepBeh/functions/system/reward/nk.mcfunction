#普通击杀没有奖励

#加普通击杀
scoreboard players add @s O3G30Q 1
#加生涯击杀
scoreboard players add @s V5G28k 1

scoreboard players add @s 落月币 1

#音效
playsound random.orb @s


