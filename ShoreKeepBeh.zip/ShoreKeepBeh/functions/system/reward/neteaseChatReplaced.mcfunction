

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.smwy_sxd_write_again.msg"}]}

##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.smwy_sxd_write_again.msg"}]}

