

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.join_reward_experience.msg"}]}
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.join_reward_coin.msg"}]}
##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.join_reward_experience.msg"}]}
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.join_reward_coin.msg"}]}

#经验5
scoreboard players add @s E1B36G 5 
#硬币2
scoreboard players add @s Q0A59I 2

#加生涯场数
scoreboard players add @s V3P49H 1
