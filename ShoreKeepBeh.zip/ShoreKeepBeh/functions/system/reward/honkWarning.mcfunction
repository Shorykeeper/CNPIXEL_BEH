

titleraw @s[tag=language] title {"rawtext":[{"translate":"style.hyp.honkWarning.title"}]}
titleraw @s[tag=language] subtitle {"rawtext":[{"translate":"style.hyp.honkWarning.subtitle"}]}

titleraw @s[tag=语言] title {"rawtext":[{"translate":"style.cnp.honkWarning.title"}]}
titleraw @s[tag=语言] subtitle {"rawtext":[{"translate":"style.cnp.honkWarning.subtitle"}]}

