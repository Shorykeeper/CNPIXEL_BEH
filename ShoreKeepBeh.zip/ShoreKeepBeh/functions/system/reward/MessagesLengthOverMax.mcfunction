

tellraw @s {"rawtext":[{"text":"§f"}]}

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.MessagesLengthOverMax.msg"}]}
tellraw @s[tag=language,tag=!noticedLength] {"rawtext":[{"translate":"style.hyp.MessagesLengthOverMax_tips.msg"}]}


##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.MessagesLengthOverMax.msg"}]}
tellraw @s[tag=语言,tag=!noticedLength] {"rawtext":[{"translate":"style.cnp.MessagesLengthOverMax_tips.msg"}]}

tag @s[tag=!noticedLength] add noticedLength
