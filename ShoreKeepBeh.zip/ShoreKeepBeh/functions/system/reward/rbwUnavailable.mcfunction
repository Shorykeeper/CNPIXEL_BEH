
tellraw @s {"rawtext":[{"text":"§f"}]}

title @s title §f
titleraw @s[tag=language] subtitle {"rawtext":[{"translate":"style.hyp.rbwUnavailable.msg"}]}
titleraw @s[tag=语言] subtitle {"rawtext":[{"translate":"style.cnp.rbwUnavailable.msg"}]}

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.rbwUnavailable.msg"}]}

##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.rbwUnavailable.msg"}]}

#音效
playsound random.break @s

