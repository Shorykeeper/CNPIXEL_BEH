

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.warn_cmd_inuse.msg"}]}

##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.warn_cmd_inuse.msg"}]}

