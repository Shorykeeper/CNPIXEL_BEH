

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.desbed_reward_coin.msg"}]}

##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.desbed_reward_coin.msg"}]}

#加16硬币
scoreboard players add @s Q0A59I 16

#加当局破床
scoreboard players add @s R4DO6T 1

#加生涯破床
scoreboard players add @s S0F06V 1

scoreboard players add @s 落月币 5

