

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.inf_cmd_banned.msg"}]}

##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.inf_cmd_banned.msg"}]}

