

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.attack_in_teammate.msg"}]}

##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.attack_in_teammate.msg"}]}

