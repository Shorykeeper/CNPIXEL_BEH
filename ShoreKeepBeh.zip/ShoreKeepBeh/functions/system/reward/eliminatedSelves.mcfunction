

tellraw @s {"rawtext":[{"text":"§f"}]}

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.player_eliminated.message"}]}

titleraw @s[tag=language] title {"rawtext":[{"translate":"style.hyp.player_eliminated.title"}]}
titleraw @s[tag=language] subtitle {"rawtext":[{"translate":"style.hyp.player_eliminated.subtitle"}]}


##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.player_eliminated.message"}]}

titleraw @s[tag=语言] title {"rawtext":[{"translate":"style.cnp.player_eliminated.title"}]}
titleraw @s[tag=语言] subtitle {"rawtext":[{"translate":"style.cnp.player_eliminated.subtitle"}]}



