

## tag=inf的模式保护
# #模式保护要有区别 如果是inf则调回0 大厅人2 viewer则是3 

gamemode 0 @s[tag=inf]
gamemode spectator @s[tag=view]
gamemode 2 @s[tag=!inf,tag=!view]
