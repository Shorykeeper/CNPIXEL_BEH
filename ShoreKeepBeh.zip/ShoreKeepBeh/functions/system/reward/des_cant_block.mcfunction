

##英原生
tellraw @s[tag=language] {"rawtext":[{"translate":"style.hyp.des_cant_block.msg"}]}

##中汉化
tellraw @s[tag=语言] {"rawtext":[{"translate":"style.cnp.des_cant_block.msg"}]}

