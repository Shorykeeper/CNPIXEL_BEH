# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 玩家击杀效果 被BwScript引用 
# @TeamCode: 1R 2B 3G 4Y

playsound random.orb @s

title @s title §7

title @s subtitle §a§l击败敌人!


