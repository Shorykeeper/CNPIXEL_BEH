# -*- coding: utf-8 -*-
# @suthor  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 当玩家淘汰 被BwScript引用 
# @TeamCode: 1R 2B 3G 4Y

##显示淘汰文本效果
function global/reward/eliminatedSelves

tag @s remove inf

scoreboard players reset @s B7O14L

#队伍
scoreboard players reset @s A1T12P

tag @s remove fastbuild

tag @s add 清除

execute as @s run function global/reset/reset_ender_chest

#血量
scoreboard players set @s T2R10A 20

#盔甲
scoreboard players reset @s I3P77O

#破床
scoreboard players reset @s R4DO6T
#斧子
scoreboard players reset @s I0S08X
#镐子
scoreboard players reset @s X2C07R
#清牛奶
scoreboard players reset @s G6Y81S
#清铁锻炉
scoreboard players reset @s Y9V88N
#清矿物等级
scoreboard players reset @s A4Q23U
#清队伍陷阱数 
scoreboard players reset @s W4G21E
#清救援平台 
scoreboard players reset @s N5L93G
#重置计算队伍机制
scoreboard players set allt D1W04T 0
#清复活
scoreboard players reset @s S2P10K
scoreboard players reset @s C1T28Q
scoreboard players reset @s Y9V88N
scoreboard players reset @s A1B23C
scoreboard players reset @s X5T99R
scoreboard players reset @s Q7M04P
scoreboard players reset @s Z3K56L

#清保护和锋利等增益tag
tag @s remove 保护1
tag @s remove 保护2
tag @s remove 保护3
tag @s remove 保护4

tag @s remove fengl
tag @s remove fengll

tag @s remove kg
tag @s remove kg2

tag @s remove 治愈池

tag @s remove 龙增益


##重置玩家设置
effect @s clear
clear @s
scoreboard players set @s health 20
title @s times 0 70 0

##进入观战

gamemode spectator @s

tag @s add 观战

gamemode spectator @s

tp @s @r[tag=inf]




