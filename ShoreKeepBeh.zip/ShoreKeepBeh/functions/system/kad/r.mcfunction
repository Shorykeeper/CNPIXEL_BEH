# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @GameID  : [NMC]ShoryKeeper [XboxIMC]Oculusina
# @Function : 玩家重生大系统 被BwScript引用 
# @TeamCode: 1R 2B 3G 4Y


## TitleTimes文本表现效果
execute as @a[scores={S2P10K=1..}] at @s run title @s times 0 100 0
execute as @a[scores={S2P10K=1..5}] at @s run gamemode spectator @s[m=!spectator]
##有床的执行重生,加分进程
#这里的验证来源于BwScript引用f(kad)/d
#kad只会给可复活的人复活tag,这里不需过多担心

#给进入到重生队列的进行递增进程操作
scoreboard players add @a[tag=S2P10K] S2P10K 1

#重生玩家已经刷新S2P10K分数1以上,分数选择器在这里生效
execute as @a[scores={S2P10K=30..35}] at @s run clear @s


# 节奏：每 27 tick 推进一次，从第 30 tick 开始
# ======= 5秒提示 ======= (第30tick)
execute as @a[scores={S2P10K=30}] at @s run playsound note.hat @s ~~~

execute as @a[tag=语言,scores={S2P10K=30}] run tellraw @s {"rawtext":[{"translate":"style.cnp.player_died_5.msg"}]}
execute as @a[tag=语言,scores={S2P10K=30..31}] run titleraw @s title {"rawtext":[{"translate":"style.cnp.player_died.title"}]}
execute as @a[tag=语言,scores={S2P10K=30..31}] run titleraw @s subtitle {"rawtext":[{"translate":"style.cnp.player_died_5.subtitle"}]}

execute as @a[tag=language,scores={S2P10K=30}] run tellraw @s {"rawtext":[{"translate":"style.hyp.player_died_5.msg"}]}
execute as @a[tag=language,scores={S2P10K=30..31}] run titleraw @s title {"rawtext":[{"translate":"style.hyp.player_died.title"}]}
execute as @a[tag=language,scores={S2P10K=30..31}] run titleraw @s subtitle {"rawtext":[{"translate":"style.hyp.player_died_5.subtitle"}]}


# ======= 4秒提示 ======= (第57tick)
execute as @a[scores={S2P10K=57}] at @s run playsound note.hat @s ~~~

execute as @a[tag=语言,scores={S2P10K=57}] run tellraw @s {"rawtext":[{"translate":"style.cnp.player_died_4.msg"}]}
execute as @a[tag=语言,scores={S2P10K=57..58}] run titleraw @s title {"rawtext":[{"translate":"style.cnp.player_died.title"}]}
execute as @a[tag=语言,scores={S2P10K=57..58}] run titleraw @s subtitle {"rawtext":[{"translate":"style.cnp.player_died_4.subtitle"}]}

execute as @a[tag=language,scores={S2P10K=57}] run tellraw @s {"rawtext":[{"translate":"style.hyp.player_died_4.msg"}]}
execute as @a[tag=language,scores={S2P10K=57..58}] run titleraw @s title {"rawtext":[{"translate":"style.hyp.player_died.title"}]}
execute as @a[tag=language,scores={S2P10K=57..58}] run titleraw @s subtitle {"rawtext":[{"translate":"style.hyp.player_died_4.subtitle"}]}


# ======= 3秒提示 ======= (第84tick)
execute as @a[scores={S2P10K=84}] at @s run playsound note.hat @s ~~~

execute as @a[tag=语言,scores={S2P10K=84}] run tellraw @s {"rawtext":[{"translate":"style.cnp.player_died_3.msg"}]}
execute as @a[tag=语言,scores={S2P10K=84..85}] run titleraw @s title {"rawtext":[{"translate":"style.cnp.player_died.title"}]}
execute as @a[tag=语言,scores={S2P10K=84..85}] run titleraw @s subtitle {"rawtext":[{"translate":"style.cnp.player_died_3.subtitle"}]}

execute as @a[tag=language,scores={S2P10K=84}] run tellraw @s {"rawtext":[{"translate":"style.hyp.player_died_3.msg"}]}
execute as @a[tag=language,scores={S2P10K=84..85}] run titleraw @s title {"rawtext":[{"translate":"style.hyp.player_died.title"}]}
execute as @a[tag=language,scores={S2P10K=84..85}] run titleraw @s subtitle {"rawtext":[{"translate":"style.hyp.player_died_3.subtitle"}]}


# ======= 2秒提示 ======= (第111tick)
execute as @a[scores={S2P10K=111}] at @s run playsound note.hat @s ~~~

execute as @a[tag=语言,scores={S2P10K=111}] run tellraw @s {"rawtext":[{"translate":"style.cnp.player_died_2.msg"}]}
execute as @a[tag=语言,scores={S2P10K=111..112}] run titleraw @s title {"rawtext":[{"translate":"style.cnp.player_died.title"}]}
execute as @a[tag=语言,scores={S2P10K=111..112}] run titleraw @s subtitle {"rawtext":[{"translate":"style.cnp.player_died_2.subtitle"}]}

execute as @a[tag=language,scores={S2P10K=111}] run tellraw @s {"rawtext":[{"translate":"style.hyp.player_died_2.msg"}]}
execute as @a[tag=language,scores={S2P10K=111..112}] run titleraw @s title {"rawtext":[{"translate":"style.hyp.player_died.title"}]}
execute as @a[tag=language,scores={S2P10K=111..112}] run titleraw @s subtitle {"rawtext":[{"translate":"style.hyp.player_died_2.subtitle"}]}


# ======= 1秒提示 ======= (第138tick)
execute as @a[scores={S2P10K=138}] at @s run playsound note.hat @s ~~~

execute as @a[tag=语言,scores={S2P10K=138}] run tellraw @s {"rawtext":[{"translate":"style.cnp.player_died_1.msg"}]}
execute as @a[tag=语言,scores={S2P10K=138..139}] run titleraw @s title {"rawtext":[{"translate":"style.cnp.player_died.title"}]}
execute as @a[tag=语言,scores={S2P10K=138..139}] run titleraw @s subtitle {"rawtext":[{"translate":"style.cnp.player_died_1.subtitle"}]}

execute as @a[tag=language,scores={S2P10K=138}] run tellraw @s {"rawtext":[{"translate":"style.hyp.player_died_1.msg"}]}
execute as @a[tag=language,scores={S2P10K=138..139}] run titleraw @s title {"rawtext":[{"translate":"style.hyp.player_died.title"}]}
execute as @a[tag=language,scores={S2P10K=138..139}] run titleraw @s subtitle {"rawtext":[{"translate":"style.hyp.player_died_1.subtitle"}]}


# ======= 已重生 ======== (第165tick)
execute as @a[scores={S2P10K=165}] at @s run playsound note.hat @s ~~~

execute as @a[tag=语言,scores={S2P10K=165}] run tellraw @s {"rawtext":[{"translate":"style.cnp.player_respawn.message"}]}
execute as @a[tag=语言,scores={S2P10K=165..}] run titleraw @s title {"rawtext":[{"translate":"style.cnp.player_respawn.title"}]}
execute as @a[tag=语言,scores={S2P10K=165..}] run title @s subtitle §f

execute as @a[tag=language,scores={S2P10K=165}] run tellraw @s {"rawtext":[{"translate":"style.hyp.player_respawn.message"}]}
execute as @a[tag=language,scores={S2P10K=165..}] run titleraw @s title {"rawtext":[{"translate":"style.hyp.player_respawn.title"}]}
execute as @a[tag=language,scores={S2P10K=165..}] run title @s subtitle §f

##给盔甲
#引用global全局里start盔甲文件类里的wear
#很奇怪吧 手伸到开局功能那里 架构好乱啊
execute as @a[scores={S2P10K=165..}] at @s run function global/start/armorWearing

#传送到战场 需要exe引用开局的分图tp思路
execute as @a[scores={S2P10K=165..,A1T12P=1..4}] at @s run function global/start/deploy_to_map/teleport

#重置默认武器木剑
replaceitem entity @a[scores={S2P10K=165..}] slot.hotbar 0 wooden_sword
replaceitem entity @a[scores={S2P10K=165..}] slot.hotbar 8 compass
execute if score mode O8P02W = num_1 B7O14L as @a[scores={S2P10K=165..}] run function mode/1_mode_bedfight
execute as @a[scores={S2P10K=165..}] at @s run function global/kad/declineToolLevel

#清除重生Tag=S2P10K 也是计分板名字 这样明了
tag @a[scores={S2P10K=165..}] remove S2P10K

#恢复游戏模式=生存=0
gamemode 0 @a[scores={S2P10K=165..,A1T12P=1..4},m=!0]
scoreboard players reset @a[scores={S2P10K=165..}] S2P10K





