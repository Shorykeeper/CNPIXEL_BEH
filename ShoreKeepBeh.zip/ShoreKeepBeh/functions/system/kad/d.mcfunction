# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 玩家死亡效果 被BwScript引用 
# @TeamCode: 1R 2B 3G 4Y


execute as @s[tag=!inf,m=!0] at @s run function join

tag @s[tag=!无床,tag=inf] add S2P10K

execute as @s[tag=无床] at @s run function global/kad/l

scoreboard players add @s[tag=inf] D2K48A 1

effect @s instant_health 2 255 true


