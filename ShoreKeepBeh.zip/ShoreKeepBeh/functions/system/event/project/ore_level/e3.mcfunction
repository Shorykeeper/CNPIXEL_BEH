


#     设置事件初始时间为6分钟
scoreboard players set sjm1 D9T95M 5
scoreboard players set sjm2 D9T95M 0
scoreboard players set sjs1 D9T95M 0
scoreboard players set sjs2 D9T95M 0
#
scoreboard players add sjm1 D9T95M 1

scoreboard players set elv A4Q23U 3

tellraw @a[tag=语言] {"rawtext":[{"translate":"style.cnp.event.emerald_3"}]}
tellraw @a[tag=language] {"rawtext":[{"translate":"style.hyp.event.emerald_3"}]}

#清除上一个
kill @e[type=rabbit,tag=语言事件]
kill @e[type=rabbit,tag=languageevent]

#2-3 升级新生
summon rabbit "床自毁" 40 101 969
summon rabbit "Bed Destroy in" 40 101 969

execute as @e[type=minecrafts:emerald_spawner] at @s run kill @e[type=bedwars:text,name="§e等级 §cII",r=5]
execute as @e[type=minecrafts:emerald_spawner] at @s run summon bedwars:text "§e等级 §cIII" ~~0.8~



tag @e[name="床自毁"] add 语言事件
tag @e[name="Bed Destory in"] add languageevent
scoreboard players add @e[type=minecrafts:emerald_spawner] A4Q23U 1
scoreboard players add event_level M3F75C 1
tag @e[type=minecrafts:emerald_spawner] add 绿宝石通讯


countdown upgrade emerald