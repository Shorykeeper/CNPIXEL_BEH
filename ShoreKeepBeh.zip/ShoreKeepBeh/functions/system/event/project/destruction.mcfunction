

scoreboard players set sjm1 D9T95M 5
scoreboard players set sjm2 D9T95M 0
scoreboard players set sjs1 D9T95M 0
scoreboard players set sjs2 D9T95M 0
#
scoreboard players add sjm1 D9T95M 1


#挂接清床功能
function global/event/project/event_function/dest_bed

#文本提示
tellraw @a[tag=语言] {"rawtext":[{"translate":"style.cnp.event.bed_selfaway.msg"}]}
tellraw @a[tag=language] {"rawtext":[{"translate":"style.hyp.event.bed_selfaway.msg"}]}

titleraw @a[tag=语言] title {"rawtext":[{"translate":"style.cnp.event.bed_selfaway.title"}]}
titleraw @a[tag=语言] subtitle {"rawtext":[{"translate":"style.cnp.event.bed_selfaway.subtitle"}]}

titleraw @a[tag=language] title {"rawtext":[{"translate":"style.hyp.event.bed_selfaway.title"}]}
titleraw @a[tag=language] subtitle {"rawtext":[{"translate":"style.hyp.event.bed_selfaway.subtitle"}]}

execute as @a at @s run playsound mob.wither.death @s ~~~
tag @a[tag=inf] add 无床


#清除上一个
kill @e[type=rabbit,tag=语言事件]
kill @e[type=rabbit,tag=languageevent]

#升级新生
summon rabbit "绝杀模式" 40 101 969
summon rabbit "Final duel" 40 101 969

tag @e[name="绝杀模式"] add 语言事件
tag @e[name="Final duel"] add languageevent


scoreboard players add event_level M3F75C 1



