
scoreboard players set sjm1 D9T95M 4
scoreboard players set sjm2 D9T95M 0
scoreboard players set sjs1 D9T95M 0
scoreboard players set sjs2 D9T95M 0
#
scoreboard players add sjm1 D9T95M 1

#清除上一个
kill @e[type=rabbit,tag=语言事件]
kill @e[type=rabbit,tag=languageevent]

#升级新生
summon rabbit "游戏结束" 40 101 969
summon rabbit "Game over" 40 101 969

tag @e[name="游戏结束"] add 语言事件
tag @e[name="Game over"] add languageevent

scoreboard players add event_level M3F75C 1

#这里没挂接功能
