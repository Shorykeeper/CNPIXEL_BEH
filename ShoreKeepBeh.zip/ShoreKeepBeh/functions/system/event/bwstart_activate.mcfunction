# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 游戏开始时 激活事件 引用一次

#记得加execute if score加模式区分
# 1 = bf  2 = speed   15分钟床自毁
execute if score mode O8P02W <= num_2 B7O14L run summon rabbit "床自毁" 40 101 969
execute if score mode O8P02W <= num_2 B7O14L run summon rabbit "Bed destory in" 40 101 969

execute if score mode O8P02W <= num_2 B7O14L run tag @e[name="床自毁"] add 语言事件
execute if score mode O8P02W <= num_2 B7O14L run tag @e[name="Bed destory in"] add languageevent

#  4-5-6 设置事件初始时间为6分钟
execute if score mode O8P02W <= num_2 B7O14L run scoreboard players set sjm1 D9T95M 4
execute if score mode O8P02W <= num_2 B7O14L run scoreboard players set sjm2 D9T95M 2
execute if score mode O8P02W <= num_2 B7O14L run scoreboard players set sjs1 D9T95M 0
execute if score mode O8P02W <= num_2 B7O14L run scoreboard players set sjs2 D9T95M 0
#
execute if score mode O8P02W <= num_2 B7O14L run scoreboard players add sjm1 D9T95M 1




# 3 = onexp
execute if score mode O8P02W = num_3 B7O14L run summon rabbit "资源生成点升至II级倒计时" 40 101 969
execute if score mode O8P02W = num_3 B7O14L run summon rabbit "Resource II in" 40 101 969

execute if score mode O8P02W = num_3 B7O14L run tag @e[name="资源生成点升至II级倒计时"] add 语言事件
execute if score mode O8P02W = num_3 B7O14L run tag @e[name="Resource II in"] add languageevent

# 3 设置事件初始时间为5分钟
execute if score mode O8P02W = num_3 B7O14L run scoreboard players set sjm1 D9T95M 4
execute if score mode O8P02W = num_3 B7O14L run scoreboard players set sjm2 D9T95M 0
execute if score mode O8P02W = num_3 B7O14L run scoreboard players set sjs1 D9T95M 0
execute if score mode O8P02W = num_3 B7O14L run scoreboard players set sjs2 D9T95M 0
#
execute if score mode O8P02W = num_3 B7O14L run scoreboard players add sjm1 D9T95M 1


# 4=xp 5=job 6=classic
execute if score mode O8P02W >= num_4 B7O14L run summon rabbit "钻石生成点II级" 40 101 969
execute if score mode O8P02W >= num_4 B7O14L run summon rabbit "Diamond II in" 40 101 969

execute if score mode O8P02W >= num_4 B7O14L run tag @e[name="钻石生成点II级"] add 语言事件
execute if score mode O8P02W >= num_4 B7O14L run tag @e[name="Diamond II in"] add languageevent

#  4-5-6 设置事件初始时间为6分钟
execute if score mode O8P02W >= num_4 B7O14L run scoreboard players set sjm1 D9T95M 5
execute if score mode O8P02W >= num_4 B7O14L run scoreboard players set sjm2 D9T95M 0
execute if score mode O8P02W >= num_4 B7O14L run scoreboard players set sjs1 D9T95M 0
execute if score mode O8P02W >= num_4 B7O14L run scoreboard players set sjs2 D9T95M 0
#
execute if score mode O8P02W >= num_4 B7O14L run scoreboard players add sjm1 D9T95M 1
