


execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_0 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/ore_level/1xp/resource_2

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_1 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/1xp/health_1

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_2 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/ore_level/1xp/resource_3

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_3 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/1xp/wither_bow

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_4 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/ore_level/1xp/resource_4

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_5 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/1xp/health_2

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_6 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/ore_level/1xp/resource_5

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_7 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/destruction

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_8 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/end



