

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_0 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/ore_level/d2

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_1 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/ore_level/e2

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_2 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/ore_level/d3

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_3 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/ore_level/e3

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_4 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/destruction

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_5 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/duel

#
execute if score start B7O14L = num_2 B7O14L if score event_level M3F75C = num_6 B7O14L if score sjm1 D9T95M = num_0 B7O14L if score sjs2 D9T95M = num_0 B7O14L if score sjs1 D9T95M = num_0 B7O14L run function global/event/project/end

