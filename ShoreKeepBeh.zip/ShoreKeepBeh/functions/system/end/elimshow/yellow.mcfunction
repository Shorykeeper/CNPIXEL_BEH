tellraw @a {"rawtext":[{"text":"§f"}]}

tellraw @a[tag=语言] {"rawtext":[{"translate":"style.cnp.yellow_eliminated"}]}
tellraw @a[tag=language] {"rawtext":[{"translate":"style.hyp.yellow_eliminated"}]}

tellraw @a {"rawtext":[{"text":"§f"}]}