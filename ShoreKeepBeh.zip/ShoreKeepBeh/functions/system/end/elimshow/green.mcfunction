tellraw @a {"rawtext":[{"text":"§f"}]}

tellraw @a[tag=语言] {"rawtext":[{"translate":"style.cnp.green_eliminated"}]}
tellraw @a[tag=language] {"rawtext":[{"translate":"style.hyp.green_eliminated"}]}

tellraw @a {"rawtext":[{"text":"§f"}]}