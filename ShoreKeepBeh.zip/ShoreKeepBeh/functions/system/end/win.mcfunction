# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 最终胜利效果
# @TeamCode: 1R 2B 3G 4Y

# 请先将获胜玩家添加标签"winn" 然后再选择中他
tag @a[tag=inf,tag=!观战] add winn


# all kill = nk + fk
execute as @a at @s run scoreboard players reset @s D9W45S
scoreboard players add @a D9W45S 0
scoreboard players add @a O3G20Q 0
scoreboard players add @a G2L41J 0
execute as @a at @s run scoreboard players operation @s D9W45S = @s O3G30Q
execute as @a at @s run scoreboard players operation @s D9W45S += @s G2L41J 



# 加生涯胜利场
scoreboard players add @a[tag=winn] T8R43H 1

##英原生
tellraw @a[tag=language,tag=winn] {"rawtext":[{"text":"§b+260 Bed Wars Experience! (victory)"}]}
tellraw @a[tag=language,tag=winn] {"rawtext":[{"text":"§6+30 Coins! (victory)"}]}
##中汉化
tellraw @a[tag=语言,tag=winn] {"rawtext":[{"text":"§b+260起床战争经验! (获得胜利)"}]}
tellraw @a[tag=语言,tag=winn] {"rawtext":[{"text":"§6+30硬币! (获得胜利)"}]}
#加硬币
scoreboard players add @a[tag=winn] Q0A59I 30
#加经验
scoreboard players add @a[tag=winn] E1B36G 260




# 全场播报结束音效
execute as @a at @s run playsound mob.enderdragon.death @s ~~12~

# Winner Effect
titleraw @a[tag=语言,tag=winn] title {"rawtext":[{"translate":"style.cnp.victory.title"}]}
titleraw @a[tag=language,tag=winn] title {"rawtext":[{"translate":"style.hyp.victory.title"}]}


# Winner To Others
titleraw @a[tag=语言,tag=!winn] title {"rawtext":[{"translate":"style.cnp.gameover.title"}]}
titleraw @a[tag=language,tag=!winn] title {"rawtext":[{"translate":"style.hyp.gameover.title"}]}

# MGE RULES
execute as @a[tag=winn,tag=!无床] run scoreboard players add @s 比赛 3
execute as @a[tag=winn,tag=无床] run scoreboard players add @s 比赛 6
#Timer
execute as @r[tag=inf,scores={A1T12P=1..4}] run tellraw @a[tag=语言] {"rawtext":[{"text":"§e§lCN§6PIXEL §f >> §r§7本场战斗总用时 - §e00§6:§e"},{"score":{"objective":"Z4T27M","name":"m2"}},{"score":{"objective":"Z4T27M","name":"m1"}},{"text":"§6:§e"},{"score":{"objective":"Z4T27M","name":"s2"}},{"score":{"objective":"Z4T27M","name":"s1"}}]}

execute as @r[tag=inf,scores={A1T12P=1..4}] run tellraw @a[tag=language] {"rawtext":[{"text":"§e§lCN§6PIXEL §f >> §r§7Total game timed - §e00§6:§e"},{"score":{"objective":"Z4T27M","name":"m2"}},{"score":{"objective":"Z4T27M","name":"m1"}},{"text":"§6:§e"},{"score":{"objective":"Z4T27M","name":"s2"}},{"score":{"objective":"Z4T27M","name":"s1"}}]}


execute as @a[tag=inf] at @s run summon fireworks_rocket
execute as @a[tag=inf] at @s run summon fireworks_rocket

# 启动红石-重置倒计时
setblock 9 101 972 redstone_block

tag @e[type=npc] remove canace

scoreboard players set start B7O14L 3


tag @e remove 语言地图
tag @e remove languagemap

effect @a[tag=winn] jump_boost 1 3 true
