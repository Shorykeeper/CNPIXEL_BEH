# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 后台自动计算队伍存活/结算
# @TeamCode: 1R 2B 3G 4Y



#  可显示团灭文本机会 tag = canace
#  空人队计分板条件 直接执行
execute if score rrs D1W04T = num_0 B7O14L if entity @e[name="§a✔",tag=canace] run function global/end/elimshow/red
execute if score rrs D1W04T = num_0 B7O14L if entity @e[name="§a✔",tag=canace] run tag @e[name="§a✔",tag=canace] remove canace

execute if score grs D1W04T = num_0 B7O14L if entity @e[name="§a2",tag=canace] run function global/end/elimshow/green
execute if score grs D1W04T = num_0 B7O14L if entity @e[name="§a2",tag=canace] run tag @e[name="§a2",tag=canace] remove canace

execute if score brs D1W04T = num_0 B7O14L if entity @e[name="§a1",tag=canace] run function global/end/elimshow/blue
execute if score brs D1W04T = num_0 B7O14L if entity @e[name="§a1",tag=canace] run tag @e[name="§a1",tag=canace] remove canace

execute if score yrs D1W04T = num_0 B7O14L if entity @e[name="§c✘",tag=canace] run function global/end/elimshow/yellow
execute if score yrs D1W04T = num_0 B7O14L if entity @e[name="§c✘",tag=canace] run tag @e[name="§c✘",tag=canace] remove canace


#  以下计算剩余队伍(已团灭数思路) 进行胜利判定
#  直接Unless计算 
#  To-do : NPC的代分数 必须在结束的时候清除 
execute unless entity @a[scores={A1T12P=1}] if score start B7O14L = num_2 B7O14L run function global/end/team_ace/r
execute unless entity @a[scores={A1T12P=2}] if score start B7O14L = num_2 B7O14L run function global/end/team_ace/b
execute unless entity @a[scores={A1T12P=3}] if score start B7O14L = num_2 B7O14L run function global/end/team_ace/g
execute unless entity @a[scores={A1T12P=4}] if score start B7O14L = num_2 B7O14L run function global/end/team_ace/y


#  再次计算NPC载体分数为0的数量
scoreboard players set allt D1W04T 0
execute if score start B7O14L = num_2 B7O14L as @e[type=npc,scores={D1W04T=0}] at @s run scoreboard players add allt D1W04T 1


#  已团灭队伍分数结果为三 == 若无人空队数为三 即为三队出局 剩下一队便是胜利队伍
# execute if score allt D1W04T = num_3 B7O14L run
execute if entity @e[name="未转变者",tag=canend] if score allt D1W04T = num_3 B7O14L run function global/end/win
execute if entity @e[name="未转变者",tag=canend] if score allt D1W04T = num_3 B7O14L run tag @e[name="未转变者",tag=canend] remove canend

