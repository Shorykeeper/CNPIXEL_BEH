# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 倒计时引用
# @PING : 20


# 各数值
execute if score start B7O14L = num_1 B7O14L if score count M3F75C matches 180 run function start/num/180
execute if score start B7O14L = num_1 B7O14L if score count M3F75C matches 120 run function start/num/120
execute if score start B7O14L = num_1 B7O14L if score count M3F75C = num_60 B7O14L run function start/num/60
execute if score start B7O14L = num_1 B7O14L if score count M3F75C = num_40 B7O14L run function start/num/40
execute if score start B7O14L = num_1 B7O14L if score count M3F75C = num_20 B7O14L run function start/num/20
execute if score start B7O14L = num_1 B7O14L if score count M3F75C = num_10 B7O14L run function start/num/10
execute if score start B7O14L = num_1 B7O14L if score count M3F75C = num_5 B7O14L run function start/num/5
execute if score start B7O14L = num_1 B7O14L if score count M3F75C = num_4 B7O14L run function start/num/4
execute if score start B7O14L = num_1 B7O14L if score count M3F75C = num_3 B7O14L run function start/num/3
execute if score start B7O14L = num_1 B7O14L if score count M3F75C = num_2 B7O14L run function start/num/2
execute if score start B7O14L = num_1 B7O14L if score count M3F75C = num_1 B7O14L run function start/num/1

# 倒计时成功归零 引用全局开局
execute unless entity @a[tag=inf] if score start B7O14L = num_1 B7O14L if score count M3F75C <= num_0 B7O14L run function global/start/bwstart



