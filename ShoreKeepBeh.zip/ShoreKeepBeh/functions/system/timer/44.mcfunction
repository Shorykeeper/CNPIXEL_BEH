# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ ShoreKeep ]
# @Function : 四位计时器. 对应关系: m2 m1 : s2 s1
# @PING : 20 
# 请注意: 该功能前提是没有玩家被胜出[tag=winn]的情况下执行

# 事件发生倒计时 sjss B7O14L
# 适用于多少多少秒的事件在这计时
#execute unless entity @a[tag=winn] if score start B7O14L = num_1 B7O14L run scoreboard players remove sjss B7O14L 1

#时间正正计时 每秒增加一 type= Z4T27M
execute unless entity @a[tag=winn] run scoreboard players add s1 Z4T27M 1

execute unless entity @a[tag=winn] run execute if score s1 Z4T27M >= num_10 B7O14L run scoreboard players add s2 Z4T27M 1
execute unless entity @a[tag=winn] run execute if score s1 Z4T27M >= num_10 B7O14L run scoreboard players set s1 Z4T27M 0

execute unless entity @a[tag=winn] run execute if score s2 Z4T27M >= num_6 B7O14L run scoreboard players add m1 Z4T27M 1
execute unless entity @a[tag=winn] run execute if score s2 Z4T27M >= num_6 B7O14L run scoreboard players set s2 Z4T27M 0

execute unless entity @a[tag=winn] run execute if score m1 Z4T27M >= num_10 B7O14L run scoreboard players add m2 Z4T27M 1
execute unless entity @a[tag=winn] run execute if score m1 Z4T27M >= num_10 B7O14L run scoreboard players set m1 Z4T27M 0


#倒序四位计时 每秒减少1 type= D9T95M
execute unless entity @a[tag=winn] run scoreboard players remove s1 D9T95M 1

execute unless entity @a[tag=winn] run execute if score s1 D9T95M < num_0 B7O14L run scoreboard players remove s2 D9T95M 1
execute unless entity @a[tag=winn] run execute if score s1 D9T95M < num_0 B7O14L run scoreboard players set s1 D9T95M 9

execute unless entity @a[tag=winn] run execute if score s2 D9T95M < num_0 B7O14L run scoreboard players remove m1 D9T95M 1
execute unless entity @a[tag=winn] run execute if score s2 D9T95M < num_0 B7O14L run scoreboard players set s2 D9T95M 5

execute unless entity @a[tag=winn] run execute if score m1 D9T95M < num_0 B7O14L run scoreboard players remove m2 D9T95M 1
execute unless entity @a[tag=winn] run execute if score m1 D9T95M < num_0 B7O14L run scoreboard players set m1 D9T95M 9


#事件倒序四位计时 每秒减少1 type= D9T95M
execute unless entity @a[tag=winn] run scoreboard players remove sjs1 D9T95M 1

execute unless entity @a[tag=winn] run execute if score sjs1 D9T95M < num_0 B7O14L run scoreboard players remove sjs2 D9T95M 1
execute unless entity @a[tag=winn] run execute if score sjs1 D9T95M < num_0 B7O14L run scoreboard players set sjs1 D9T95M 9

execute unless entity @a[tag=winn] run execute if score sjs2 D9T95M < num_0 B7O14L run scoreboard players remove sjm1 D9T95M 1
execute unless entity @a[tag=winn] run execute if score sjs2 D9T95M < num_0 B7O14L run scoreboard players set sjs2 D9T95M 5

execute unless entity @a[tag=winn] run execute if score sjm1 D9T95M < num_0 B7O14L run scoreboard players remove sjm2 D9T95M 1
execute unless entity @a[tag=winn] run execute if score sjm1 D9T95M < num_0 B7O14L run scoreboard players set sjm1 D9T95M 9

#神奇牛奶时间
execute unless entity @a[tag=winn] run execute if entity @a[scores={G6Y81S=0..}] run scoreboard players remove @a[scores={G6Y81S=0..}] G6Y81S 1
