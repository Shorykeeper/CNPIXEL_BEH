
function global/upgrade/haste_effect

