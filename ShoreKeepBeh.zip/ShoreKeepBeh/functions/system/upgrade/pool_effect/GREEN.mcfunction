# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ ShoreKeep ]
# @Function : 绿队治愈池

execute as @e[type=bedwars:text,name="§3"] run effect @a[r=15,scores={A1T12P=3}] regeneration 1 1 true


