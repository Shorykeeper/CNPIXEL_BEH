# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ ShoreKeep ]
# @Function : 蓝队治愈池

execute as @e[type=bedwars:text,name="§2"] run effect @a[r=15,scores={A1T12P=2}] regeneration 1 1 true


