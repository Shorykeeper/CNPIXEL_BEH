# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 治愈池统括执行 3s一次 <<- times

execute as @r[scores={Q7M04P=1..,A1T12P=1}] run function global/upgrade/pool_effect/RED

execute as @r[scores={Q7M04P=1..,A1T12P=2}] run function global/upgrade/pool_effect/BLUE

execute as @r[scores={Q7M04P=1..,A1T12P=4}] run function global/upgrade/pool_effect/YELLOW

execute as @r[scores={Q7M04P=1..,A1T12P=3}] run function global/upgrade/pool_effect/GREEN

scoreboard players set zyc B7O14L 0




