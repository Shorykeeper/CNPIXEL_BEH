

effect @a[tag=kg] haste 1 0 true
effect @a[tag=kg2] haste 1 1 true

