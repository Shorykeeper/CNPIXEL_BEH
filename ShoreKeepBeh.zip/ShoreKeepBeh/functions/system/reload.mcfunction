# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 向@s 初始化互通分数

scoreboard players add @s U2C44V 0
scoreboard players add @s T8R43H 0
scoreboard players add @s V5G28k 0
scoreboard players add @s C4D31J 0
scoreboard players add @s S0F06V 0
scoreboard players add @s Q0A59I 0
scoreboard players add @s E1B36G 0
scoreboard players add @s G7C23S 0
scoreboard players add @s Y5T96B 0
scoreboard players add @s V3P49H 0
scoreboard players add @s S8Q83P 0
scoreboard players add @s D2K48A 0
scoreboard players add @s K8T78F 0
