#道具 受指令管辖的总驱动fun


#搭桥蛋 控制生成颜色和时长 —— 泛用级
execute if entity @e[type=egg] run function global/toys/egg

#神奇牛奶 控制使用后持续倒计时 ——泛用级
function global/toys/milk

#炸药 控制时间和爆炸 ——泛用级
execute if entity @e[type=tnt] run function global/toys/tnt

#救援平台 有模式条件 ——经典和疾速没有
execute if score mode O8P02W matches 4..5 run function global/toys/save

#蠹虫
#execute if entity @e[type=silverfish] run function global/toys/silverfish

