# 蠹虫
# 时间计算借用牛奶计分板G6Y81S

scoreboard players add @e[type=silverfish] G6Y81S 1
execute as @e[scores={G6Y81S=600..},type=silverfish] at @s run kill @s
