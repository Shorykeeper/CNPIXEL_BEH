# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 商店-按队伍给羊毛

give @s[scores={A1T12P=1}] red_wool 16
give @s[scores={A1T12P=2}] blue_wool 16
give @s[scores={A1T12P=3}] lime_wool 16
give @s[scores={A1T12P=4}] yellow_wool 16

