# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 计算锋利增益升级

# 初始化 0
scoreboard players add @s A1B23C 0

# 先拦截处理1-2升级
execute if entity @s[scores={A1B23C=1}] run tag @s remove fengl
execute if entity @s[scores={A1B23C=1}] run tag @s add fengll
scoreboard players set @s[tag=fengll] A1B23C 2

# 最后惟余0-1升级
execute unless entity @s[scores={A1B23C=1..2}] run tag @s add fengl
scoreboard players set @s[tag=fengl] A1B23C 1

