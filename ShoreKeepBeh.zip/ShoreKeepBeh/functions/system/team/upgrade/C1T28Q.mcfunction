# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 计算保护增益升级

# ===== 初始化计分板（确保存在）=====
scoreboard players add @s C1T28Q 0

# ===== 清除所有旧的保护tag（准备更新状态）=====
tag @s remove 保护1
tag @s remove 保护2
tag @s remove 保护3
tag @s remove 保护4

# ===== 1. 处理：原分为 3 → 当前等级升为 4 =====
execute if entity @s[scores={C1T28Q=3}] run scoreboard players set @s C1T28Q 4

# ===== 2. 处理：原分为 2 → 当前等级升为 3 =====
execute if entity @s[scores={C1T28Q=2}] run scoreboard players set @s C1T28Q 3

# ===== 3. 处理：原分为 1 → 当前等级升为 2 =====
execute if entity @s[scores={C1T28Q=1}] run scoreboard players set @s C1T28Q 2

# ===== 4. 处理：原分为 0 → 当前等级升为 1 =====
execute if entity @s[scores={C1T28Q=0}] run scoreboard players set @s C1T28Q 1

# ===== 5. 兜底：所有不在 1~4 范围内的玩家设为 1（防异常）=====
execute unless entity @s[scores={C1T28Q=1..4}] run scoreboard players set @s C1T28Q 1

# ===== 根据最终 C1T28Q 添加对应的当前等级 tag =====
execute if entity @s[scores={C1T28Q=1}] run tag @s add 保护1
execute if entity @s[scores={C1T28Q=2}] run tag @s add 保护2
execute if entity @s[scores={C1T28Q=3}] run tag @s add 保护3
execute if entity @s[scores={C1T28Q=4}] run tag @s add 保护4

tag @s add 附魔
