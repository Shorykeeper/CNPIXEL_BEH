# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 计算急迫增益升级

# 初始化 0
scoreboard players add @s X5T99R 0

# 先拦截处理1-2升级
execute as @s[scores={X5T99R=1}] run tag @s remove kg
execute as @s[scores={X5T99R=1}] run tag @s add kg2
scoreboard players set @s[tag=kg2,scores={X5T99R=1}] X5T99R 2

# 最后惟余0-1升级
execute as @s[scores={X5T99R=0}] run tag @s add kg
scoreboard players set @s[tag=kg] X5T99R 1
