# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 计算治愈池升级


# 初始化 0
scoreboard players add @s Q7M04P 0

# 只有一级 直接升级
execute if entity @s[scores={Q7M04P=0}] run tag @s add 治愈池
execute if entity @s[scores={Q7M04P=0}] run scoreboard players set @s[tag=治愈池] Q7M04P 1

