# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 计算摔落保护增益升级

# 初始化：确保玩家有 C5H77S 计分板分数（避免空值）
scoreboard players add @s C5H77S 0

# 处理 1 → 2 升级：如果玩家当前分数为 1，则升级到 2，并将标签从「摔落1」改为「摔落2」
execute if entity @s[scores={C5H77S=1}] run tag @s remove 摔落1
execute if entity @s[scores={C5H77S=1}] run tag @s add 摔落2

# 将所有带有「摔落2」标签的玩家的分数设为 2（确保同步）
scoreboard players set @s[tag=摔落2] C5H77S 2

# 处理 0 → 1 升级：如果玩家分数不是 1 或 2，则视为 0，打上「摔落1」标签并设为 1
execute unless entity @s[scores={C5H77S=1..2}] run tag @s add 摔落1
scoreboard players set @s[tag=摔落1] C5H77S 1

tag @s add 附魔
