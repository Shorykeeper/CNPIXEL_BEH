# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 计算龙增益升级


# 初始化 0
scoreboard players add @s Z3K56L 0

# 只有一级 直接升级
execute if entity @s[scores={Z3K56L=0}] run tag @s add 龙增益
execute if entity @s[scores={Z3K56L=0}] run scoreboard players set @s[tag=龙增益] Z3K56L 1

