# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 计算铁锻炉(家里)增益升级

# ===== 初始化计分板（确保存在）=====
scoreboard players add @s Y9V88N 0

# ===== 清除所有旧的保护tag（准备更新状态）=====
tag @s remove 铁锻炉2
tag @s remove 铁锻炉3
tag @s remove 铁锻炉4
tag @s remove 铁锻炉5

# ===== 1. 处理：原分为 4 → 当前等级升为 5 =====
execute if entity @s[scores={Y9V88N=4}] run scoreboard players set @s Y9V88N 5

# ===== 2. 处理：原分为 3 → 当前等级升为 4 =====
execute if entity @s[scores={Y9V88N=3}] run scoreboard players set @s Y9V88N 4

# ===== 3. 处理：原分为 2 → 当前等级升为 3 =====
execute if entity @s[scores={Y9V88N=2}] run scoreboard players set @s Y9V88N 3

# ===== 4. 处理：原分为 0 → 当前等级升为 2 =====
execute if entity @s[scores={Y9V88N=1}] run scoreboard players set @s Y9V88N 2

# ===== 5. 兜底：所有不在 1~4 范围内的玩家设为 1（防异常）=====
execute unless entity @s[scores={Y9V88N=1..4}] run scoreboard players set @s Y9V88N 1

# ===== 6. 处理：将玩家分数同步同给基地生成器 =====
execute as @s[scores={A1T12P=1}] run scoreboard players operation @e[type=bedwars:text,scores={A1T12P=1}] = @s[type=player] Y9V88N
execute as @s[scores={A1T12P=2}] run scoreboard players operation @e[type=bedwars:text,scores={A1T12P=2}] = @s[type=player] Y9V88N
execute as @s[scores={A1T12P=3}] run scoreboard players operation @e[type=bedwars:text,scores={A1T12P=3}] = @s[type=player] Y9V88N
execute as @s[scores={A1T12P=4}] run scoreboard players operation @e[type=bedwars:text,scores={A1T12P=4}] = @s[type=player] Y9V88N

# ===== 根据最终 Y9V88N 添加对应的当前等级 tag =====
execute if entity @s[scores={Y9V88N=2}] run tag @s add 铁锻炉2
execute if entity @s[scores={Y9V88N=3}] run tag @s add 铁锻炉3
execute if entity @s[scores={Y9V88N=4}] run tag @s add 铁锻炉4
execute if entity @s[scores={Y9V88N=5}] run tag @s add 铁锻炉5

say ore success
