# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 商店-按队伍给黏土

give @s[scores={A1T12P=1}] red_terracotta 16 
give @s[scores={A1T12P=2}] blue_terracotta 16 
give @s[scores={A1T12P=3}] green_terracotta 16 
give @s[scores={A1T12P=4}] yellow_terracotta 16 

