

clear @s
tellraw @s {"rawtext":[{"text":"§b§lShory§fKeeper §7丨 §r§c你已退出当前加入的队伍"}]}


replaceitem entity @s slot.hotbar 1 air
