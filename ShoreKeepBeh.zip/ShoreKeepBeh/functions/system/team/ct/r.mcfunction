

tag @s add team_join_red

