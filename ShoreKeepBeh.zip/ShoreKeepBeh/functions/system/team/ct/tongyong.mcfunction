

tellraw @s {"rawtext":[{"text":"§b"}]}

playsound random.levelup @s

