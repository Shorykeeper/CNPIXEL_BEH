# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 商店/按队伍给玻璃

give @s[scores={A1T12P=1}] red_stained_glass 16
give @s[scores={A1T12P=2}] blue_stained_glass 16
give @s[scores={A1T12P=3}] lime_stained_glass 16
give @s[scores={A1T12P=4}] yellow_stained_glass 16

