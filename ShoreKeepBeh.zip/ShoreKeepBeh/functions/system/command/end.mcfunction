
execute as @s[tag=!candoend] run say 没有合适的时机结束游戏

execute as @s[tag=wtf,tag=!candoend] run function global/end/draw

execute as @s[tag=candoend] run function global/end/draw

tag @s remove candoend


