
scoreboard players add @a 比赛 0
execute as @a run tellraw @a {"rawtext":[{"text":"§e§l@PLAYER §f"},{"selector":"@s"},{"text":"§r§f 获得点数§7[RULES-MGE]: §a§l"},{"score":{"objective":"比赛","name":"@s"}}]}
scoreboard objectives remove 比赛
scoreboard objectives add 比赛 dummy

tag @a remove candoend

kill @e[type=minecrafts:diamond_spawner]
kill @e[type=minecrafts:emerald_spawner]

scoreboard players set start B7O14L -1

scoreboard players reset match_id B7O14L
scoreboard players reset @a B7O14L

tag @e[type=npc] remove 语言地图
tag @e[type=npc] remove languagemap

kill @e[type=rabbit,tag=语言事件]
kill @e[type=rabbit,tag=languageevent]

tag @a remove winn
tag @a remove rbw_chained
tag @a remove rbw_unt



# 丨 ----- 接入地图重置 Respond by YGN ----- 丨

# 若非rbw模式 则可随机任意地图
execute unless score mode O8P02W = num_5 B7O14L run scoreboard players random map F3Q58B 1 6

# 如果房间没有canrbw的人 还是rbw模式 则归化为普通模式
execute unless entity @r[tag=canrbw] if score mode O8P02W = num_5 B7O14L run tellraw @a {"rawtext":[{"text":"§c§l未检索到可使用rbw模式权限的玩家,已调回经典模式,若需要开启rbw模式请持有开启秘钥的玩家前来开启"}]}
execute unless entity @r[tag=canrbw] if score mode O8P02W = num_5 B7O14L run scoreboard players set mode O8P02W 6

# 若rbw模式可被正常开启 则只能在胜津城和铁索里选
# 介入临时计算变量
execute if entity @r[tag=canrbw] if score mode O8P02W = num_5 B7O14L run scoreboard players random comp B7O14L 1 2
execute if score comp B7O14L matches 1 run scoreboard players set map F3Q58B 3
execute if score comp B7O14L matches 2 run scoreboard players set map F3Q58B 6
scoreboard players reset comp B7O14L




execute as @a at @s run function join

tag @a remove inf

#在特定情况下地图建筑重置会有残留
fill 115 266 206 90 282 206 air
fill 92 270 206 114 280 206 air

tag @a remove fh

#队伍
scoreboard players reset @a A1T12P

tag @a remove fastbuild
tag @a remove shears

tag @a add 清除

tag @a remove 无床
tag @s remove 床保护

kill @e[type=pig]

kill @e[type=egg]

#清金五秒计时
scoreboard players reset gold_n Z4T27M 

#血量
scoreboard players set @a T2R10A 20
#击杀
scoreboard players reset @a O3G30Q
#盔甲
scoreboard players reset @a I3P77O
#最终击杀
scoreboard players reset @a G2L41J 
#破床
scoreboard players reset @a R4DO6T
#斧子
scoreboard players reset @e I0S08X
#镐子
scoreboard players reset @a X2C07R
#清牛奶
scoreboard players reset @a G6Y81S
#清铁锻炉
scoreboard players reset @a Y9V88N
#清矿物等级
scoreboard objectives remove A4Q23U
scoreboard objectives add A4Q23U dummy

scoreboard players reset @a O8P02W

#清队伍陷阱数 
scoreboard players reset @a W4G21E
#清救援平台 
scoreboard players reset @a N5L93G
#重置计算队伍机制
scoreboard players set allt D1W04T 0
#清复活
scoreboard players reset @a S2P10K
#清一堆增益计分板
scoreboard players reset @a C1T28Q
scoreboard players reset @a Y9V88N
scoreboard players reset @a A1B23C
scoreboard players reset @a X5T99R
scoreboard players reset @e Q7M04P
scoreboard players reset @e Z3K56L
scoreboard players reset @e M3F75C
scoreboard players reset resource A4Q23U 
scoreboard players reset @e A4Q23U
scoreboard players reset match_id B7O14L
scoreboard players reset @a C5H77S
scoreboard players reset @a H1G22F
scoreboard players reset @a FlyVl

#停止显示血量 
scoreboard objectives setdisplay belowname
scoreboard objectives remove T2R10A


#清保护和锋利等增益tag
tag @a remove 保护1
tag @a remove 保护2
tag @a remove 保护3
tag @a remove 保护4

tag @a remove fengl
tag @a remove fengll

tag @a remove kg
tag @a remove kgg

tag @a remove 摔落1
tag @a remove 摔落2


tag @a remove 治愈池

tag @a remove 龙增益

countdown reset

#清末影箱
execute as @a run function global/reset/reset_ender_chest

#清道具实体
kill @e[type=item]
kill @e[type=ender_dragon]
kill @e[type=iron_golem]
kill @e[type=tnt]
kill @e[type=hb:block]
kill @e[type=minecraft:fireball]


execute positioned 73 186 1824 run kill @e[rm=100,type=template:npc] 
execute positioned 73 186 1824 run kill @e[rm=100,type=bedwars:text] 

#设置初始事件为0  意为0个事件已发生
scoreboard players set event_level M3F75C 0

clear @a

tag @a add canmap

#开始重置之文字提示
titleraw @a[tag=语言] title {"rawtext":[{"translate":"style.cnp.reset_starting.title"}]}
titleraw @a[tag=语言] subtitle {"rawtext":[{"translate":"style.cnp.reset_starting.subtitle"}]}

titleraw @a[tag=language] title {"rawtext":[{"translate":"style.hyp.reset_starting.title"}]}
titleraw @a[tag=language] subtitle {"rawtext":[{"translate":"style.hyp.reset_starting.subtitle"}]}

tellraw @a[tag=语言] {"rawtext":[{"translate":"style.cnp.reset_starting.msg"}]}
tellraw @a[tag=language] {"rawtext":[{"translate":"style.hyp.reset_starting.msg"}]}

