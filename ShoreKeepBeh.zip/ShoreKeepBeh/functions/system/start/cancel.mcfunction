# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 取消倒计时


# 复原机制 
# 重置倒计时 = 60
# 重置游戏状态为 [等待 , 0]
scoreboard players set count M3F75C 60
scoreboard players set start B7O14L 0

# 播报文字效果
tellraw @a[tag=语言] {"rawtext":[{"translate":"style.cnp.need_more.msg"}]}
titleraw @a[tag=语言] title {"rawtext":[{"translate":"style.cnp.need_more.title"}]}
titleraw @a[tag=语言] subtitle {"rawtext":[{"translate":"style.cnp.need_more.subtitle"}]}

tellraw @a[tag=language] {"rawtext":[{"translate":"style.hyp.need_more.msg"}]}
titleraw @a[tag=language] title {"rawtext":[{"translate":"style.hyp.need_more.title"}]}
titleraw @a[tag=language] subtitle {"rawtext":[{"translate":"style.hyp.need_more.subtitle"}]}

# 消经验条
xp -1000L @a

clear @a

tp @a 73 186 1824

