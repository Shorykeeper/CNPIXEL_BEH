# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 游戏开始
# @TeamCode: 1R 2B 3G 4Y

# 如果房间没有canrbw的人 还是rbw模式 则归化为普通模式
execute unless entity @r[tag=canrbw] if score mode O8P02W = num_5 B7O14L run tellraw @a {"rawtext":[{"text":"\n§c§l未检索到可使用rbw模式权限的玩家,已调回经典模式,若需要开启rbw模式请持有开启秘钥的玩家前来开启"}]}
execute unless entity @r[tag=canrbw] if score mode O8P02W = num_5 B7O14L run scoreboard players set @a O8P02W 6
execute unless entity @r[tag=canrbw] if score mode O8P02W = num_5 B7O14L run scoreboard players set mode O8P02W 6

# 如果是rbw模式但是不是对应可用地图 则结束游戏重开
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 1..2 run function global/end/draw 
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B matches 4..5 run function global/end/draw 

# 非疾速模式清除床保护
execute unless score mode O8P02W = num_2 B7O14L run function global/reset/unless_speed_reset

# ======================================
#  设置游戏状态为 [对局中 , 2]
#  重置倒计时 = 60
scoreboard players set count M3F75C 60

# ======================================
#  设置悬浮生命值显示 [T2R10A , @s]
scoreboard objectives remove T2R10A
scoreboard objectives add T2R10A dummy "§c❤"
scoreboard objectives setdisplay belowname T2R10A

#  同步模式数据
execute as @a at @s run scoreboard players operation @s O8P02W = mode O8P02W 


# ======================================
#  默认分队 随机 - 随机队伍 非竞赛
# 调用AerMini的最终请求函数.
function global/start/apply


# ======================================
#清除
tag @a remove S2P10K
kill @e[name="§c保护你的床!"]
kill @e[name="§1"]
kill @e[name="§2"]
kill @e[name="§3"]
kill @e[name="§4"]
clear @a
kill @e[type=item]
xp -10000l @a
tag @a remove candoend
# 规则准备-分地图大部署

# 商店生成
function global/start/deploy_to_map/shop
# 出生点
execute as @a at @s run function global/start/deploy_to_map/spawnpoint
# 床底提示文字
function global/start/deploy_to_map/protect_your_bed_text
# 定位基地出生点
function global/start/deploy_to_map/located_base_entity

#重置末影箱
execute as @a at @s run function global/reset/reset_ender_chest

#钻石和绿宝石资源点
# 2 = speed
execute if score mode O8P02W = num_2 B7O14L run function global/start/deploy_to_map/diamond_point

# 3 = eternal experience
execute if score mode O8P02W = num_3 B7O14L run function global/start/deploy_to_map/onexp_gold_point

# 4 = experience
execute if score mode O8P02W = num_4 B7O14L run function global/start/deploy_to_map/diamond_point

# 5 = rbw
execute if score mode O8P02W = num_5 B7O14L run function global/start/deploy_to_map/diamond_point

# 6 = classic
execute if score mode O8P02W = num_6 B7O14L run function global/start/deploy_to_map/diamond_point




# 2 = speed
execute if score mode O8P02W = num_2 B7O14L run function global/start/deploy_to_map/emerald_point

# 3 = eternal experience
#execute if score mode O8P02W = num_3 B7O14L run function global/start/deploy_to_map/diamond_point

# 4 = experience
execute if score mode O8P02W = num_4 B7O14L run function global/start/deploy_to_map/emerald_point

# 5 = rbw
execute if score mode O8P02W = num_5 B7O14L run function global/start/deploy_to_map/emerald_point

# 6 = classic
execute if score mode O8P02W = num_6 B7O14L run function global/start/deploy_to_map/emerald_point






execute if score mode O8P02W = num_3 B7O14L run function global/start/deploy_to_map/onexp_diamond_point



tag @e[name="未转变者",tag=!canend] add canend
scoreboard players set @a O3G30Q 0
scoreboard players set @a R4DO6T 0
#scoreboard players set @a die 0
scoreboard players set @a G2L41J 0
scoreboard players set @a I3P77O 0


#播放音效
execute as @a at @s run playsound random.levelup @s 
execute as @a at @s run playsound mob.enderdragon.growl @s ~~12~


# 补时间正计时分分
scoreboard players set m1 Z4T27M 0
scoreboard players set m2 Z4T27M 0
scoreboard players set s2 Z4T27M 0
scoreboard players set s1 Z4T27M 0

# 设置初始时间
scoreboard players set m1 D9T95M 1
scoreboard players set m2 D9T95M 4
scoreboard players set s1 D9T95M 0
scoreboard players set s2 D9T95M 0
#
scoreboard players add m1 D9T95M 1
scoreboard players add @e[type=minecrafts:emerald_spawner] A4Q23U 1
scoreboard players add @e[type=minecrafts:diamond_spawner] A4Q23U 1



#  更新队伍状态显示
tag @e remove rtbeds
tag @e remove btbeds
tag @e remove gtbeds
tag @e remove ytbeds

tag @e[name="§a✔"] add rtbeds
tag @e[name="§a✔"] add btbeds
tag @e[name="§a✔"] add ytbeds
tag @e[name="§a✔"] add gtbeds


#给木剑
replaceitem entity @a[tag=inf] slot.hotbar 0 wooden_sword 

#自定义颜色盔甲挂接
execute as @a at @s run function global/start/armorWearing

#赋予团灭提示机会 借用NPC作为载体
tag @e[name="§c✘"] add canace
tag @e[name="§a1"] add canace
tag @e[name="§a2"] add canace
tag @e[name="§a✔"] add canace

#设置初始事件为0 开局 意为0个事件已发生
scoreboard players set event_level M3F75C 0


#启动脚本
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B = num_6 B7O14L run tag @a add rbw_chained
execute if score mode O8P02W = num_5 B7O14L if score mapp F3Q58B = num_3 B7O14L run tag @a add rbw_unt
tag @a add startgame


#刷新团灭
scoreboard players reset @e[type=npc] D1W04T 
scoreboard players add allt D1W04T 0

#清玻璃屋
fill 82 319 85 127 311 127 air


effect @a clear

#自定义颜色盔甲挂接
execute as @a at @s run function global/start/team_wear



# ======================================
#  基地矿石系统 [Y9V88N , type=bedwars:text]
#  初始刷新,生成家矿资源点
execute unless score mode O8P02W = num_1 B7O14L run function global/start/deploy_to_map/ore
#   以主城为中心rm选择标识基地资源点
execute positioned 73 186 1824 unless score mode O8P02W = num_1 B7O14L run tag @e[rm=100,type=bedwars:text,name="§b"] add iron_spawn
#   基地资源初始赋分 (初始等级)
execute as @e[tag=iron_spawn] at @s run scoreboard players set @s Y9V88N 1



#title提示
titleraw @a[tag=语言] title {"rawtext":[{"translate":"style.cnp.startgame.title"}]}
titleraw @a[tag=语言] subtitle {"rawtext":[{"translate":"style.cnp.startgame.subtitle"}]}

titleraw @a[tag=language] title {"rawtext":[{"translate":"style.hyp.startgame.title"}]}
titleraw @a[tag=language] subtitle {"rawtext":[{"translate":"style.hyp.startgame.subtitle"}]}

# 提示开始文字
function global/start/introduce

#队伍聊天提示
function global/reward/chatNoteInStart

#参与奖励
execute as @a[scores={A1T12P=1..4}] at @s run function global/reward/participationRewards



#激活事件
function global/event/bwstart_activate


kill @e[type=npc,name="§f"]
tag @a[scores={A1T12P=1..4}] add inf

gamemode 0 @a[tag=inf]

#进行传送
execute as @a at @s run function global/start/deploy_to_map/teleport

replaceitem entity @a[tag=inf] slot.hotbar 8 compass
replaceitem entity @a[tag=inf] slot.hotbar 0 wooden_sword
execute as @a[scores={A1T12P=1..4}] if score mode O8P02W = num_1 B7O14L run function mode/1_mode_bedfight
execute if score mode O8P02W = num_3 B7O14L run scoreboard players set resource A4Q23U 1

execute unless score mode O8P02W = num_1 B7O14L run tag @e[type=minecrafts:diamond_spawner] add diamond_spawn
execute unless score mode O8P02W = num_1 B7O14L run tag @e[type=minecrafts:emerald_spawner] add emerald_spawn

scoreboard players random match_id B7O14L 1 100000
scoreboard players operation @a[tag=inf] B7O14L = match_id B7O14L

scoreboard players set start B7O14L 2

execute unless score mode O8P02W = num_1 B7O14L unless score mode O8P02W = num_2 B7O14L run tag @a[tag=inf] add 床保护
execute unless score mode O8P02W = num_1 B7O14L unless score mode O8P02W = num_2 B7O14L run scoreboard players set 床保护 B7O14L 100

fill 92 270 206 114 280 206 air

# 疾速模式 满资源点
execute if score mode O8P02W = num_2 B7O14L run function global/start/deploy_to_map/speed

execute if score mode O8P02W = num_4 B7O14L run scoreboard players set @e[tag=iron_spawn] Y9V88N 5


give @a[tag=inf] cake

tellraw @a {"rawtext":[{"text":"\n§b§l3.3日小岸生日§f版本! §7全场已获得生日道具蛋糕\n\n§f"}]}
