# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 开幕文字介绍

# ===== 切床模式 =====
## 英原生
execute if score mode O8P02W = num_1 B7O14L run tellraw @a[tag=language] {"rawtext":[{"text":"§a§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n\n               §f§lBed Wars-BedFight\n\n§e   Protect your bed and destroy the enemy beds.\n   All armor, weapons, and blocks come with built-in supplies. \nWin with equal equipment go it!§a\n\n§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■"}]}
## 中汉化
execute if score mode O8P02W = num_1 B7O14L run tellraw @a[tag=语言] {"rawtext":[{"text":"§a§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n\n               §f§l起床战争-切床模式\n\n§e   保护你的床并摧毁敌人的床。所有盔甲、武器、方块\n      全部自带供应。使用平等的装备获胜吧。§a\n\n§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■"}]}

# ===== 疾速模式 =====
## 英原生
execute if score mode O8P02W = num_2 B7O14L run tellraw @a[tag=language] {"rawtext":[{"text":"§a§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n\n               §f§lBED WARS SPEED\n\n§e   All generators are maxed! Your bed has three\n   layers of protection! F click while holding\nwool to activate bridge building§a\n\n§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■"}]}
## 中汉化
execute if score mode O8P02W = num_2 B7O14L run tellraw @a[tag=语言] {"rawtext":[{"text":"§a§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n\n               §f§l起床战争疾速起床\n\n§e  所有资源生成点都为满级!你的床有三层保护!\n      手持羊毛F键点击开启建桥模式!§a\n\n§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■"}]}

# ===== 一经验模式 =====
## 英原生
execute if score mode O8P02W = num_3 B7O14L run tellraw @a[tag=language] {"rawtext":[{"text":"§a§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n\n               §f§lBED WARS ETERNAL\n\n§e   All items sold in the store have only one\n   experience enjoy the fun of props and battles§a\n\n§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■"}]}
## 中汉化
execute if score mode O8P02W = num_3 B7O14L run tellraw @a[tag=语言] {"rawtext":[{"text":"§a§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n\n               §f§l起床战争一经验模式\n\n§e  所有物品商店出售的物品都是一经验\n      享受道具和对战带来的乐趣吧!§a\n\n§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■"}]}

# ===== 无火经验模式 =====
## 英原生
execute if score mode O8P02W = num_4 B7O14L run tellraw @a[tag=language] {"rawtext":[{"text":"§a§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n\n               §f§lBED WARS XP\n\n§e   All resources will be converted into experience\n   The store sells more weapons and props, generating richer resources\n    The combat mechanism will become more complex and intense§a\n\n§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■"}]}
## 中汉化
execute if score mode O8P02W = num_4 B7O14L run tellraw @a[tag=语言] {"rawtext":[{"text":"§a§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n\n               §f§l起床战争无限火力\n\n§e  所有的资源都会转换为经验\n     商店出售更多的武器、道具,产生的资源更丰富\n战斗对战机制将会更复杂更激烈§a\n\n§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■"}]}

# ===== 排位起床模式 =====
## 中汉化
execute if score mode O8P02W = num_5 B7O14L run tellraw @a[tag=语言] {"rawtext":[{"text":"§a§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n\n               §f§l排位起床战争\n\n§e   保护你的床并摧毁敌人的床。按照排位起床规则击败对手\n     获取elo点数获胜。注意务必遵守排位起床赛季规则§a\n\n§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■"}]}


# ===== 经典模式 =====
## 英原生
execute if score mode O8P02W = num_6 B7O14L run tellraw @a[tag=language] {"rawtext":[{"text":"§a§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n\n               §f§lBED WARS\n\n§e   Protect your bed and destroy the enemy beds.\n   Upgrade yourself and your team by collecting\n   Iron,Gold,Emerald and diamond from generatiors\n       to access powerful upgrades.§a\n\n§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■"}]}
## 中汉化
execute if score mode O8P02W = num_6 B7O14L run tellraw @a[tag=语言] {"rawtext":[{"text":"§a§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n\n               §f§l起床战争\n\n§e   保护你的床并摧毁敌人的床。收集铁锭、金锭、钻石、\n      绿宝石来升级。使自身和队伍变得更强。§a\n\n§l■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■"}]}









