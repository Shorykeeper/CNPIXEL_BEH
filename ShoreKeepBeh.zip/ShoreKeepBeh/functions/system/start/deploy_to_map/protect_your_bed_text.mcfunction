# === 地图 1: Unturned ===
execute if score mapp F3Q58B = num_1 B7O14L run summon bedwars:text "§c保护你的床!" 105 276 27
execute if score mapp F3Q58B = num_1 B7O14L run summon bedwars:text "§c保护你的床!" 183 276 105
execute if score mapp F3Q58B = num_1 B7O14L run summon bedwars:text "§c保护你的床!" 105 276 183
execute if score mapp F3Q58B = num_1 B7O14L run summon bedwars:text "§c保护你的床!" 27 276 105

# === 地图 2: Pool Party ===
execute if score mapp F3Q58B = num_2 B7O14L run summon bedwars:text "§c保护你的床!" 22 274 100
execute if score mapp F3Q58B = num_2 B7O14L run summon bedwars:text "§c保护你的床!" 106 274 22
execute if score mapp F3Q58B = num_2 B7O14L run summon bedwars:text "§c保护你的床!" 184 274 106
execute if score mapp F3Q58B = num_2 B7O14L run summon bedwars:text "§c保护你的床!" 100 274 184

# === 地图 3: Katsu ===
execute if score mapp F3Q58B = num_3 B7O14L run summon bedwars:text "§c保护你的床!" 98 269 24
execute if score mapp F3Q58B = num_3 B7O14L run summon bedwars:text "§c保护你的床!" 172 269 98
execute if score mapp F3Q58B = num_3 B7O14L run summon bedwars:text "§c保护你的床!" 98 269 172
execute if score mapp F3Q58B = num_3 B7O14L run summon bedwars:text "§c保护你的床!" 24 269 98

# === 地图 4: Garden ===
execute if score mapp F3Q58B = num_4 B7O14L run summon bedwars:text "§c保护你的床!" 39 273 103
execute if score mapp F3Q58B = num_4 B7O14L run summon bedwars:text "§c保护你的床!" 104 273 35
execute if score mapp F3Q58B = num_4 B7O14L run summon bedwars:text "§c保护你的床!" 165 273 103
execute if score mapp F3Q58B = num_4 B7O14L run summon bedwars:text "§c保护你的床!" 104 273 171

# === 地图 5: Graveship ===
execute if score mapp F3Q58B = num_5 B7O14L run summon bedwars:text "§c保护你的床!" 167 275 90
execute if score mapp F3Q58B = num_5 B7O14L run summon bedwars:text "§c保护你的床!" 86 275 171
execute if score mapp F3Q58B = num_5 B7O14L run summon bedwars:text "§c保护你的床!" 33 275 119
execute if score mapp F3Q58B = num_5 B7O14L run summon bedwars:text "§c保护你的床!" 114 275 37

# === 地图 6: Picnic === 
execute if score mapp F3Q58B = num_6 B7O14L run summon bedwars:text "§c保护你的床!" 103 277 34
execute if score mapp F3Q58B = num_6 B7O14L run summon bedwars:text "§c保护你的床!" 172 277 103
execute if score mapp F3Q58B = num_6 B7O14L run summon bedwars:text "§c保护你的床!" 103 277 172
execute if score mapp F3Q58B = num_6 B7O14L run summon bedwars:text "§c保护你的床!" 34 277 103


