# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 设置基地资源点


# map1
execute if score mapp F3Q58B = num_1 B7O14L run summon bedwars:text "§b" 105 278 9
execute if score mapp F3Q58B = num_1 B7O14L run summon bedwars:text "§b" 201 278 105
execute if score mapp F3Q58B = num_1 B7O14L run summon bedwars:text "§b" 105 278 201
execute if score mapp F3Q58B = num_1 B7O14L run summon bedwars:text "§b" 9 278 105

# map2
execute if score mapp F3Q58B = num_2 B7O14L run summon bedwars:text "§b" 22 275 113
execute if score mapp F3Q58B = num_2 B7O14L run summon bedwars:text "§b" 93 275 22
execute if score mapp F3Q58B = num_2 B7O14L run summon bedwars:text "§b" 184 275 93
execute if score mapp F3Q58B = num_2 B7O14L run summon bedwars:text "§b" 113 275 184

# map3
execute if score mapp F3Q58B = num_3 B7O14L run summon bedwars:text "§b" 98 273 4
execute if score mapp F3Q58B = num_3 B7O14L run summon bedwars:text "§b" 192 273 98
execute if score mapp F3Q58B = num_3 B7O14L run summon bedwars:text "§b" 98 273 192
execute if score mapp F3Q58B = num_3 B7O14L run summon bedwars:text "§b" 4 273 98

# map4
execute if score mapp F3Q58B = num_4 B7O14L run summon bedwars:text "§b" 20 276 103
execute if score mapp F3Q58B = num_4 B7O14L run summon bedwars:text "§b" 104 276 16
execute if score mapp F3Q58B = num_4 B7O14L run summon bedwars:text "§b" 184 276 103
execute if score mapp F3Q58B = num_4 B7O14L run summon bedwars:text "§b" 104 276 190

# map5
execute if score mapp F3Q58B = num_5 B7O14L run summon bedwars:text "§b" 167 276 110
execute if score mapp F3Q58B = num_5 B7O14L run summon bedwars:text "§b" 106 276 171
execute if score mapp F3Q58B = num_5 B7O14L run summon bedwars:text "§b" 33 276 98
execute if score mapp F3Q58B = num_5 B7O14L run summon bedwars:text "§b" 94 276 37

# map6
execute if score mapp F3Q58B = num_6 B7O14L run summon bedwars:text "§b" 189 277 103
execute if score mapp F3Q58B = num_6 B7O14L run summon bedwars:text "§b" 103 277 17
execute if score mapp F3Q58B = num_6 B7O14L run summon bedwars:text "§b" 103 277 189
execute if score mapp F3Q58B = num_6 B7O14L run summon bedwars:text "§b" 17 277 103

