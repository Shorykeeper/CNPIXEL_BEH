# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 部署商店NPC2



# map1
execute if score mapp F3Q58B = num_1 B7O14L run summon template:npc 98 278 14
execute if score mapp F3Q58B = num_1 B7O14L run summon template:npc 196 278 98
execute if score mapp F3Q58B = num_1 B7O14L run summon template:npc 112 278 196
execute if score mapp F3Q58B = num_1 B7O14L run summon template:npc 14 278 112

# map2
execute if score mapp F3Q58B = num_2 B7O14L run summon template:npc 19 275 106
execute if score mapp F3Q58B = num_2 B7O14L run summon template:npc 100 275 19
execute if score mapp F3Q58B = num_2 B7O14L run summon template:npc 187 275 100
execute if score mapp F3Q58B = num_2 B7O14L run summon template:npc 106 275 187

# map3
execute if score mapp F3Q58B = num_3 B7O14L run summon template:npc 92 274 13
execute if score mapp F3Q58B = num_3 B7O14L run summon template:npc 183 274 92
execute if score mapp F3Q58B = num_3 B7O14L run summon template:npc 104 274 183
execute if score mapp F3Q58B = num_3 B7O14L run summon template:npc 13 274 104

# map4
execute if score mapp F3Q58B = num_4 B7O14L run summon template:npc 24 276 111
execute if score mapp F3Q58B = num_4 B7O14L run summon template:npc 96 276 20
execute if score mapp F3Q58B = num_4 B7O14L run summon template:npc 180 276 95
execute if score mapp F3Q58B = num_4 B7O14L run summon template:npc 112 276 186


# map5
execute if score mapp F3Q58B = num_5 B7O14L run summon template:npc 171 276 103
execute if score mapp F3Q58B = num_5 B7O14L run summon template:npc 99 276 175
execute if score mapp F3Q58B = num_5 B7O14L run summon template:npc 29 276 105
execute if score mapp F3Q58B = num_5 B7O14L run summon template:npc 101 276 33


# map6
execute if score mapp F3Q58B = num_6 B7O14L run summon template:npc 186 277 95
execute if score mapp F3Q58B = num_6 B7O14L run summon template:npc 95 277 20
execute if score mapp F3Q58B = num_6 B7O14L run summon template:npc 111 277 186
execute if score mapp F3Q58B = num_6 B7O14L run summon template:npc 20 277 111

execute positioned 73 186 1824 as @e[rm=100,type=template:npc,tag=!道具商店] at @s run summon bedwars:text "§e§l右键/长按点击" ~~1.6~

execute positioned 73 186 1824 as @e[rm=100,type=template:npc,tag=!道具商店] at @s run summon bedwars:text "§b升级" ~~2.0~

execute positioned 73 186 1824 as @e[rm=100,type=template:npc,tag=!道具商店] at @s run summon bedwars:text "§b团队模式" ~~2.4~


