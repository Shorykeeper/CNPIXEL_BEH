# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 传送至战场 需要exe @s引用



# map1
execute if score mapp F3Q58B = num_1 B7O14L if score @s A1T12P = num_1 B7O14L run spawnpoint @s 105 278 12
execute if score mapp F3Q58B = num_1 B7O14L if score @s A1T12P = num_2 B7O14L run spawnpoint @s 198 278 105
execute if score mapp F3Q58B = num_1 B7O14L if score @s A1T12P = num_3 B7O14L run spawnpoint @s 105 278 198
execute if score mapp F3Q58B = num_1 B7O14L if score @s A1T12P = num_4 B7O14L run spawnpoint @s 12 278 105

# map2
execute if score mapp F3Q58B = num_2 B7O14L if score @s A1T12P = num_2 B7O14L run spawnpoint @s 22 275 107
execute if score mapp F3Q58B = num_2 B7O14L if score @s A1T12P = num_3 B7O14L run spawnpoint @s 99 275 22
execute if score mapp F3Q58B = num_2 B7O14L if score @s A1T12P = num_4 B7O14L run spawnpoint @s 184 275 99
execute if score mapp F3Q58B = num_2 B7O14L if score @s A1T12P = num_1 B7O14L run spawnpoint @s 107 275 184

# map3
execute if score mapp F3Q58B = num_3 B7O14L if score @s A1T12P = num_1 B7O14L run spawnpoint @s 98 273 8
execute if score mapp F3Q58B = num_3 B7O14L if score @s A1T12P = num_2 B7O14L run spawnpoint @s 188 273 98
execute if score mapp F3Q58B = num_3 B7O14L if score @s A1T12P = num_3 B7O14L run spawnpoint @s 98 273 188
execute if score mapp F3Q58B = num_3 B7O14L if score @s A1T12P = num_4 B7O14L run spawnpoint @s 8 273 98

# map4
execute if score mapp F3Q58B = num_4 B7O14L if score @s A1T12P = num_1 B7O14L run spawnpoint @s 23 276 103
execute if score mapp F3Q58B = num_4 B7O14L if score @s A1T12P = num_2 B7O14L run spawnpoint @s 104 276 19
execute if score mapp F3Q58B = num_4 B7O14L if score @s A1T12P = num_3 B7O14L run spawnpoint @s 181 276 103
execute if score mapp F3Q58B = num_4 B7O14L if score @s A1T12P = num_4 B7O14L run spawnpoint @s 104 276 187


# map5
execute if score mapp F3Q58B = num_5 B7O14L if score @s A1T12P = num_1 B7O14L run spawnpoint @s 167 276 107
execute if score mapp F3Q58B = num_5 B7O14L if score @s A1T12P = num_2 B7O14L run spawnpoint @s 103 276 171
execute if score mapp F3Q58B = num_5 B7O14L if score @s A1T12P = num_3 B7O14L run spawnpoint @s 33 276 101
execute if score mapp F3Q58B = num_5 B7O14L if score @s A1T12P = num_4 B7O14L run spawnpoint @s 97 276 37


# map6
execute if score mapp F3Q58B = num_6 B7O14L if score @s A1T12P = num_1 B7O14L run spawnpoint @s 184 277 103
execute if score mapp F3Q58B = num_6 B7O14L if score @s A1T12P = num_2 B7O14L run spawnpoint @s 22 277 103
execute if score mapp F3Q58B = num_6 B7O14L if score @s A1T12P = num_3 B7O14L run spawnpoint @s 103 277 184
execute if score mapp F3Q58B = num_6 B7O14L if score @s A1T12P = num_4 B7O14L run spawnpoint @s 103 277 22

