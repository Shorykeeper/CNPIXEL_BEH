# map1 - Unturned 绿宝石生成点 (3个)
execute if score mapp F3Q58B = num_1 B7O14L run summon minecrafts:emerald_spawner 90 285 90
execute if score mapp F3Q58B = num_1 B7O14L run summon minecrafts:emerald_spawner 120 285 120
execute if score mapp F3Q58B = num_1 B7O14L run summon minecrafts:emerald_spawner 105 284 105

# map2 - Pool Party 绿宝石生成点 (2个)
execute if score mapp F3Q58B = num_2 B7O14L run summon minecrafts:emerald_spawner 103 286 103
execute if score mapp F3Q58B = num_2 B7O14L run summon minecrafts:emerald_spawner 103 278 103

# map3 - Katsu 绿宝石生成点 (2个)
execute if score mapp F3Q58B = num_3 B7O14L run summon minecrafts:emerald_spawner 117 277 117
execute if score mapp F3Q58B = num_3 B7O14L run summon minecrafts:emerald_spawner 79 277 79

# map4 - Garden 绿宝石生成点 (4个)
execute if score mapp F3Q58B = num_4 B7O14L run summon minecrafts:emerald_spawner 83 287 82
execute if score mapp F3Q58B = num_4 B7O14L run summon minecrafts:emerald_spawner 104 292 103
execute if score mapp F3Q58B = num_4 B7O14L run summon minecrafts:emerald_spawner 125 287 124
execute if score mapp F3Q58B = num_4 B7O14L run summon minecrafts:emerald_spawner 104 287 103

# map5 - Graveship 绿宝石生成点 (2个)
execute if score mapp F3Q58B = num_5 B7O14L run summon minecrafts:emerald_spawner 109 276 113
execute if score mapp F3Q58B = num_5 B7O14L run summon minecrafts:emerald_spawner 91 276 95

# map6 - Picnic 绿宝石生成点 (2个)
execute if score mapp F3Q58B = num_6 B7O14L run summon minecrafts:emerald_spawner 114 282 103
execute if score mapp F3Q58B = num_6 B7O14L run summon minecrafts:emerald_spawner 92 282 103

# 显示文本（相对坐标，无需修改）
execute as @e[type=minecrafts:emerald_spawner] at @s run summon bedwars:text "§l§2绿宝石" ~~0.4~
execute as @e[type=minecrafts:emerald_spawner] at @s run summon bedwars:text "§e等级 §cI" ~~0.8~


execute as @e[type=minecrafts:emerald_spawner] at @s run summon hb:block ~~-1.2~
execute as @e[type=minecrafts:emerald_spawner] at @s run event entity @e[r=3,type=hb:block] emerald

execute at @e[type=minecrafts:emerald_spawner] run structure load ShoreKeepBeh:emerald ~~1~
