# map1 - Unturned 钻石生成点 (4个)
execute if score mapp F3Q58B = num_1 B7O14L run summon minecrafts:diamond_spawner 56 288 56
execute if score mapp F3Q58B = num_1 B7O14L run summon minecrafts:diamond_spawner 154 288 56
execute if score mapp F3Q58B = num_1 B7O14L run summon minecrafts:diamond_spawner 154 288 154
execute if score mapp F3Q58B = num_1 B7O14L run summon minecrafts:diamond_spawner 56 288 154

# map2 - Pool Party 钻石生成点 (4个)
execute if score mapp F3Q58B = num_2 B7O14L run summon minecrafts:diamond_spawner 157 279 157
execute if score mapp F3Q58B = num_2 B7O14L run summon minecrafts:diamond_spawner 49 279 157
execute if score mapp F3Q58B = num_2 B7O14L run summon minecrafts:diamond_spawner 157 279 49
execute if score mapp F3Q58B = num_2 B7O14L run summon minecrafts:diamond_spawner 49 279 49

# map3 - Katsu 钻石生成点 (4个)
execute if score mapp F3Q58B = num_3 B7O14L run summon minecrafts:diamond_spawner 143 270 53
execute if score mapp F3Q58B = num_3 B7O14L run summon minecrafts:diamond_spawner 53 270 53
execute if score mapp F3Q58B = num_3 B7O14L run summon minecrafts:diamond_spawner 53 270 143
execute if score mapp F3Q58B = num_3 B7O14L run summon minecrafts:diamond_spawner 143 270 143

# map4 - Garden 钻石生成点 (4个)
execute if score mapp F3Q58B = num_4 B7O14L run summon minecrafts:diamond_spawner 43 280 167
execute if score mapp F3Q58B = num_4 B7O14L run summon minecrafts:diamond_spawner 161 280 167
execute if score mapp F3Q58B = num_4 B7O14L run summon minecrafts:diamond_spawner 161 280 39
execute if score mapp F3Q58B = num_4 B7O14L run summon minecrafts:diamond_spawner 43 280 39

# map5 - Graveship 钻石生成点 (4个)
execute if score mapp F3Q58B = num_5 B7O14L run summon minecrafts:diamond_spawner 164 282 40
execute if score mapp F3Q58B = num_5 B7O14L run summon minecrafts:diamond_spawner 36 282 40
execute if score mapp F3Q58B = num_5 B7O14L run summon minecrafts:diamond_spawner 36 282 168
execute if score mapp F3Q58B = num_5 B7O14L run summon minecrafts:diamond_spawner 164 282 168

# map6 - Chained 钻石生成点 (4个)
execute if score mapp F3Q58B = num_6 B7O14L run summon minecrafts:diamond_spawner 137 282 67
execute if score mapp F3Q58B = num_6 B7O14L run summon minecrafts:diamond_spawner 139 282 137
execute if score mapp F3Q58B = num_6 B7O14L run summon minecrafts:diamond_spawner 69 282 139
execute if score mapp F3Q58B = num_6 B7O14L run summon minecrafts:diamond_spawner 67 282 69


# 显示文本（相对坐标，无需修改）
execute as @e[type=minecrafts:diamond_spawner] at @s run summon bedwars:text "§l§b钻石" ~~0.4~
execute as @e[type=minecrafts:diamond_spawner] at @s run summon bedwars:text "§e等级 §cI" ~~0.8~

execute as @e[type=minecrafts:diamond_spawner] at @s run summon hb:block ~~-1.2~
execute as @e[type=minecrafts:diamond_spawner] at @s run event entity @e[r=3,type=hb:block] diamond

execute at @e[type=minecrafts:diamond_spawner] run structure load ShoreKeepBeh:diamond ~~1~
