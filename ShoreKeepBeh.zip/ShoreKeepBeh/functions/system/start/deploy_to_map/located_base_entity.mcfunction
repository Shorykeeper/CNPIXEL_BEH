# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 传送至战场 需要exe @s引用


# map1
execute if score mapp F3Q58B = num_1 B7O14L run summon bedwars:text "§1" 105 277 12
execute if score mapp F3Q58B = num_1 B7O14L run summon bedwars:text "§2" 198 277 105
execute if score mapp F3Q58B = num_1 B7O14L run summon bedwars:text "§3" 105 277 198
execute if score mapp F3Q58B = num_1 B7O14L run summon bedwars:text "§4" 12 277 105

# map2
execute if score mapp F3Q58B = num_2 B7O14L run summon bedwars:text "§1" 22 275 107
execute if score mapp F3Q58B = num_2 B7O14L run summon bedwars:text "§2" 99 275 22
execute if score mapp F3Q58B = num_2 B7O14L run summon bedwars:text "§3" 99 275 22
execute if score mapp F3Q58B = num_2 B7O14L run summon bedwars:text "§4" 99 275 22

# map3
execute if score mapp F3Q58B = num_3 B7O14L run summon bedwars:text "§1" 98 272 8
execute if score mapp F3Q58B = num_3 B7O14L run summon bedwars:text "§2" 188 272 98
execute if score mapp F3Q58B = num_3 B7O14L run summon bedwars:text "§3" 98 272 188
execute if score mapp F3Q58B = num_3 B7O14L run summon bedwars:text "§4" 8 272 98

# map4
execute if score mapp F3Q58B = num_4 B7O14L run summon bedwars:text "§1" 23 275 103
execute if score mapp F3Q58B = num_4 B7O14L run summon bedwars:text "§2" 104 275 19
execute if score mapp F3Q58B = num_4 B7O14L run summon bedwars:text "§3" 181 275 103
execute if score mapp F3Q58B = num_4 B7O14L run summon bedwars:text "§4" 104 275 187

# map5
execute if score mapp F3Q58B = num_5 B7O14L run summon bedwars:text "§1" 167 275 107
execute if score mapp F3Q58B = num_5 B7O14L run summon bedwars:text "§2" 103 275 171
execute if score mapp F3Q58B = num_5 B7O14L run summon bedwars:text "§3" 33 275 101
execute if score mapp F3Q58B = num_5 B7O14L run summon bedwars:text "§4" 97 275 37

# map6 (Picnic - Y already adjusted)
execute if score mapp F3Q58B = num_6 B7O14L run summon bedwars:text "§1" 184 276 103
execute if score mapp F3Q58B = num_6 B7O14L run summon bedwars:text "§2" 22 276 103
execute if score mapp F3Q58B = num_6 B7O14L run summon bedwars:text "§3" 103 276 184
execute if score mapp F3Q58B = num_6 B7O14L run summon bedwars:text "§4" 103 276 22
