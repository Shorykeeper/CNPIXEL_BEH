# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ ShoreKeep ]
# @Function : 部署商店NPC



# map1
execute if score mapp F3Q58B = num_1 B7O14L run summon template:npc 112 278 14
execute if score mapp F3Q58B = num_1 B7O14L run summon template:npc 196 278 112
execute if score mapp F3Q58B = num_1 B7O14L run summon template:npc 98 278 196
execute if score mapp F3Q58B = num_1 B7O14L run summon template:npc 14 278 98

# map2
execute if score mapp F3Q58B = num_2 B7O14L run summon template:npc 19 275 108
execute if score mapp F3Q58B = num_2 B7O14L run summon template:npc 98 275 19
execute if score mapp F3Q58B = num_2 B7O14L run summon template:npc 187 275 98
execute if score mapp F3Q58B = num_2 B7O14L run summon template:npc 108 275 187

# map3
execute if score mapp F3Q58B = num_3 B7O14L run summon template:npc 104 274 13
execute if score mapp F3Q58B = num_3 B7O14L run summon template:npc 183 274 104
execute if score mapp F3Q58B = num_3 B7O14L run summon template:npc 92 274 183
execute if score mapp F3Q58B = num_3 B7O14L run summon template:npc 13 274 92

# map4
execute if score mapp F3Q58B = num_4 B7O14L run summon template:npc 24 276 95
execute if score mapp F3Q58B = num_4 B7O14L run summon template:npc 112 276 20
execute if score mapp F3Q58B = num_4 B7O14L run summon template:npc 180 276 111
execute if score mapp F3Q58B = num_4 B7O14L run summon template:npc 96 276 186


# map5
execute if score mapp F3Q58B = num_5 B7O14L run summon template:npc 171 276 105
execute if score mapp F3Q58B = num_5 B7O14L run summon template:npc 101 276 175
execute if score mapp F3Q58B = num_5 B7O14L run summon template:npc 29 276 103
execute if score mapp F3Q58B = num_5 B7O14L run summon template:npc 99 276 33


# map6
execute if score mapp F3Q58B = num_6 B7O14L run summon template:npc 186 277 111
execute if score mapp F3Q58B = num_6 B7O14L run summon template:npc 111 277 20
execute if score mapp F3Q58B = num_6 B7O14L run summon template:npc 95 277 186
execute if score mapp F3Q58B = num_6 B7O14L run summon template:npc 20 277 95


#————————————————————————————————————————————————————
execute as @e[name=§f] at @s run tag @e[type=template:npc,r=350] add 道具商店
#——————————以上道具以下增益————以上道具以下增益——————————————————————
#————————————————————————————————————————————————————

execute positioned 73 186 1824 as @e[rm=100,type=template:npc,tag=道具商店] at @s run summon bedwars:text "§e§l右键/长按点击" ~~1.6~

execute positioned 73 186 1824 unless score mode O8P02W = num_1 B7O14L as @e[rm=100,type=template:npc,tag=道具商店] at @s run summon bedwars:text "§b道具商店" ~~2.0~

execute positioned 73 186 1824 if score mode O8P02W = num_1 B7O14L as @e[rm=100,type=template:npc,tag=道具商店] at @s run summon bedwars:text "§b装备补充" ~~2.0~

execute unless score mode O8P02W = num_1 B7O14L run function global/start/deploy_to_map/shop2

