
# map1 - Unturned 绿宝石点 → onexp_diamond_spawner (3个)
execute if score mapp F3Q58B = num_1 B7O14L run summon minecrafts:onexp_diamond_spawner 90 283 90
execute if score mapp F3Q58B = num_1 B7O14L run summon minecrafts:onexp_diamond_spawner 120 283 120
execute if score mapp F3Q58B = num_1 B7O14L run summon minecrafts:onexp_diamond_spawner 105 282 105

# map2 - Pool Party 绿宝石点 → onexp_diamond_spawner (2个)
execute if score mapp F3Q58B = num_2 B7O14L run summon minecrafts:onexp_diamond_spawner 103 282 103
execute if score mapp F3Q58B = num_2 B7O14L run summon minecrafts:onexp_diamond_spawner 103 274 103

# map3 - Katsu 绿宝石点 → onexp_diamond_spawner (2个)
execute if score mapp F3Q58B = num_3 B7O14L run summon minecrafts:onexp_diamond_spawner 117 275 117
execute if score mapp F3Q58B = num_3 B7O14L run summon minecrafts:onexp_diamond_spawner 79 275 79

# map4 - Garden 绿宝石点 → onexp_diamond_spawner (4个)
execute if score mapp F3Q58B = num_4 B7O14L run summon minecrafts:onexp_diamond_spawner 83 285 82
execute if score mapp F3Q58B = num_4 B7O14L run summon minecrafts:onexp_diamond_spawner 104 290 103
execute if score mapp F3Q58B = num_4 B7O14L run summon minecrafts:onexp_diamond_spawner 125 285 124
execute if score mapp F3Q58B = num_4 B7O14L run summon minecrafts:onexp_diamond_spawner 104 285 103

# map5 - Graveship 绿宝石点 → onexp_diamond_spawner (2个)
execute if score mapp F3Q58B = num_5 B7O14L run summon minecrafts:onexp_diamond_spawner 109 274 113
execute if score mapp F3Q58B = num_5 B7O14L run summon minecrafts:onexp_diamond_spawner 91 274 95

# map6 - Picnic 绿宝石点 → onexp_diamond_spawner (2个)
execute if score mapp F3Q58B = num_6 B7O14L run summon minecrafts:onexp_diamond_spawner 92 282 103
execute if score mapp F3Q58B = num_6 B7O14L run summon minecrafts:onexp_diamond_spawner 114 282 103

execute as @e[type=minecrafts:onexp_diamond_spawner] at @s run summon bedwars:text "§l§b钻石" ~~0.5~
execute as @e[type=minecrafts:onexp_diamond_spawner] at @s run summon bedwars:text "§e等级 §cI" ~~1~

