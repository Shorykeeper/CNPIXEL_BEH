# -*- coding: utf-8 -*-
# @Author : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 脚本向此发送购买请求

# 核心todo: TYPE -> Purchase
# 脚本购买成功后会给@s购买者添加种类tag
# 根据脚本的升级机制同步升级所有的以达到数额增长的目的
# 执行方向 @s

# 这是个陷阱G6Y81U 反击陷阱P4J90M 报警陷阱E3Q28N 挖掘疲劳陷阱F2W73J 迷幻陷阱H1G22F
title @a[tag=debug] title §a成功中转

execute if entity @s[tag=trap_G6Y81U] as @s run function global/trap/activate/blindness_G6Y81U

execute if entity @s[tag=trap_P4J90M] as @s run function global/trap/activate/buff_P4J90M

execute if entity @s[tag=trap_E3Q28N] as @s run function global/trap/activate/alarm_E3Q28N

execute if entity @s[tag=trap_F2W73J] as @s run function global/trap/activate/weakness_F2W73J

execute if entity @s[tag=trap_H1G22F] as @s run function global/trap/activate/illusion_H1G22F

