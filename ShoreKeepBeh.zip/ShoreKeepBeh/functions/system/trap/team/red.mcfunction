# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 红队陷阱判定

# W4G21E = 队伍陷阱数
# K5T30G = 陷阱队列排名
# F8P11C = 陷阱冷却
# W5B88J = 陷阱队伍所属



