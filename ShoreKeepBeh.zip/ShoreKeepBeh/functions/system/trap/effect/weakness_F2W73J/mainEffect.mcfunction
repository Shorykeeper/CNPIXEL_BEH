# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 挖掘疲劳陷阱 主效果(踩中触发)

# 请execute闯入者使用
execute as @s at @s run effect @s mining_fatigue 10 0 true


