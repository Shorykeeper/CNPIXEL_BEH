# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 反击陷阱 主效果(踩中触发)

# 请execute闯入者使用
execute as @s at @s run say 1


