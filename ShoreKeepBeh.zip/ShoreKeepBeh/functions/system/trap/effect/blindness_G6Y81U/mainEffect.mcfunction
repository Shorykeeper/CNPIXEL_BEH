# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 这是个陷阱 主效果(踩中触发)

# 请execute闯入者使用

execute as @s at @s run effect @s blindness 10 0 true

execute as @s at @s run effect @s slowness 10 0 true

