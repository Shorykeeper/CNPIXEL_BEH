# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 这是个陷阱 给同队的人


# title
titleraw @s[tag=语言] title {"rawtext":[{"translate":"style.cnp.trap_triggered.title"}]}
titleraw @s[tag=语言] subtitle {"rawtext":[{"translate":"style.cnp.trap_triggered.subtitle","with":{"rawtext":[{"translate":"trap.cnp.blindness_trap"}]}}]}

titleraw @s[tag=language] title {"rawtext":[{"translate":"style.hyp.trap_triggered.title"}]}
titleraw @s[tag=language] subtitle {"rawtext":[{"translate":"style.hyp.trap_triggered.subtitle","with":{"rawtext":[{"translate":"trap.hyp.blindness_trap"}]}}]}


# message
titleraw @s[tag=语言] title {"rawtext":[{"translate":"style.cnp.trap_triggered.message"}]}
titleraw @s[tag=语言] subtitle {"rawtext":[{"translate":"style.cnp.trap_triggered.message","with":{"rawtext":[{"translate":"trap.cnp.blindness_trap"}]}}]}

titleraw @s[tag=language] title {"rawtext":[{"translate":"style.hyp.trap_triggered.message"}]}
titleraw @s[tag=language] subtitle {"rawtext":[{"translate":"style.hyp.trap_triggered.message","with":{"rawtext":[{"translate":"trap.hyp.blindness_trap"}]}}]}





