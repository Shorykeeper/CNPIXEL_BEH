# -*- coding: utf-8 -*-
# @Author  : 柑云宫音. [ QID: ShoreKeep ]
# @Function : 迷梦陷阱陷阱 主效果(踩中触发)

# 请execute闯入者使用
execute as @s at @s run function global/start/deploy_to_map/teleport


