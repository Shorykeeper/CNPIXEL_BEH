
scoreboard objectives setdisplay sidebar A1T12P ascending
execute positioned 73 186 1824 run execute as @e[rm=100,name="§c保护你的床!"] run scoreboard players add @s A1T12P 0

